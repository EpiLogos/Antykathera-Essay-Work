---
title: A25 — Covenant / Mediating Office / Source Authority
record_id: A25
record_type: canonical-argument
register: episteme
claim_status: Argued
source_relation: Argued from
source_ids:
  - taylor-2026-revision-notes-trust
  - bratton-2026-agentworld-brief
  - ostrom-2009-beyond-markets-states-nobel-lecture
  - 42-techne-2026-sovereign-commons
---
# A25 — Covenant / Mediating Office / Source Authority

## #0

A derivative office can exercise real authority without becoming the source of the field it serves. The relation begins before the office: someone has standing, something has been entrusted, obligations have been acknowledged, and an order has become available for interpretation and action. **Primary arbitration precedes its mediators.** The mediator receives an arbitrated field; receiving it does not make the mediator the source of arbitration.

[A24 — Arbitration](submission-package/essay/symbolon/episteme/arguments/A24-Arbitration-and-the-Usurpation-of-Measure.md) **grounds** the pressure: an apportioned criterion can install itself as the ground of judgment. A25 develops the positive relation through which authority remains executable and answerable. [A23 — Trust](submission-package/essay/symbolon/episteme/arguments/A23-Trust-Faith-and-the-Formal-Limit.md) **grounds** its inherited commitment. The office needs confidence enough to act, and the people relying upon it need a determinate place at which a decision can be made. Their trust does not transfer ownership of the relation to that place.

## #1

Covenant gives this priority a binding form. It joins standing to obligation: the party who receives authority receives something to answer for. The source, the entrusted office and those affected by its decisions belong to one relation, while retaining different offices within it. [C28 — Covenant / Primary Arbitration](submission-package/essay/symbolon/episteme/concepts/C28-Covenant-Primary-Arbitration.md) **defines** this first granting of standing; [C29 — Mediating Office / Derivative Sovereignty](submission-package/essay/symbolon/episteme/concepts/C29-Mediating-Office-Derivative-Sovereignty.md) **defines** the authority exercised from within what has been granted.

A contract can specify an exchange between parties whose standing it presupposes. Covenant, in this argument's use, reaches that presupposition: what relation gives the parties standing to promise, decide and bind themselves? Its obligations concern the continuance of that relation as well as the product exchanged. [A01 — Faithful Definition](submission-package/essay/symbolon/episteme/arguments/A01-Subject-God-and-Faithful-Definition.md) **compares** the corresponding operation in definition: a finite form gives an account of its source without taking the source's place.

The [Fides / Topos / Logos / Nomos / Natio / Credere whole field](submission-package/essay/symbolon/episteme/etymologies/trust-place-logos-nomos-natio-credere/WHOLE-FIELD.md) **grounds** the distinctions among entrusting, position, account, rule and inherited belonging. Their relation here is an operational construction at evidence register 3. It does not require those words to descend from one root, or the different covenant traditions to instantiate one theology.

## #2

The [[working/final-argument-quilt-2026-08-23/COVENANT-ARBITRATION-AND-MEDIATING-OFFICES-SEAM|authorial covenant seam]] **sources** the sequence through priest, king and politician. Interpretation, memory, rite and transmission give a mediating office work to do. Judgment, distribution and protection give that work executable force. A king can person the unity of an order already received; a political office can receive standing through a constitution, electorate and institutional inheritance. What matters in this argument is the passage from prior standing into situated execution. These are differentiated offices through which to examine the operation, not a universal historical succession asserted for every society.

Repeated execution can conceal the passage. People encounter the office whenever a decision is needed; the authority to decide then looks like the power which originally gave the field its standing. The earlier image of the minister declaring himself king is sharpened by this recovery: **even the king receives an office**. Royal imagery alone cannot tell whether a source-relation has been usurped. The test concerns what the office does with its derivation.

[C27 — Protected Account](submission-package/essay/symbolon/episteme/concepts/C27-Protected-Account-Occupied-Zero-Source-Claim.md) **tests** the moment at which an interpretation becomes immune to correction because it is treated as indistinguishable from its source. Legitimate mediation retains its power to interpret and act. The failure begins when the people and relation from which that power comes can no longer address it except in terms it has already authorised.

## #3

The [Apportionment / Economy whole field](submission-package/essay/symbolon/episteme/etymologies/apportionment-and-economy/WHOLE-FIELD.md) **extends** this relation into the distribution of labour. An office acquires effective power through work done elsewhere: people carry out decisions, sustain infrastructure and encounter consequences that the deciding position does not experience directly. If only the completed product returns, the office can appear self-sufficient while its dependence grows. [C53 — Power / Delegated Labour](submission-package/essay/symbolon/episteme/concepts/C53-Power-Delegated-Labour.md) **defines** that dependency; [A29](submission-package/essay/symbolon/episteme/arguments/A29-Power-Delegated-Labour-Return.md) **extends** the obligation it places on the commissioning position.

The August 18 ratification makes the required return exact. Resistance, error, cost, dissent and unforeseen possibility must be able to alter the governing model, measure, instruction or purpose. An office which receives evidence only to grade the worker has closed this route at the decisive point. It must also be possible for the evidence to correct the commission.

This is the institutional consequence of the trust-development record's bifurcation. Knowledge can give trust provisional anchors, or project the uncertainty it will not hold onto an excluded object. The [revision-notes source house](submission-package/essay/symbolon/episteme/sources/internal-corpus/taylor/taylor-2026-revision-notes-trust/SOURCE.md) **sources** that authorial development. A returnable office supplies an anchor without requiring its subjects to make the office infallible. [C48 — Trust / Faith under Formal Limit](submission-package/essay/symbolon/episteme/concepts/C48-Trust-Faith-under-Formal-Limit.md) **qualifies** its reliance: a binding commitment is finite without becoming disposable whenever it meets difficulty.

## #4

Bratton's [institutional account](submission-package/essay/symbolon/episteme/sources/media-technology-philosophy/bratton/bratton-2026-agentworld-brief/SOURCE.md#bratton-2026-agentworld-brief-q026) **compares** an intelligence carried by rules, roles, precedents and feedback with the intelligence of particular occupants. An office can be occupied by different configurations while its institutional work persists. The [cultural-interoperability passage](submission-package/essay/symbolon/episteme/sources/media-technology-philosophy/bratton/bratton-2026-agentworld-brief/SOURCE.md#bratton-2026-agentworld-brief-q027) **qualifies** that persistence: institutions enter plural cultures and help change the cultures they inherit. These are **Paraphrased** venue propositions, carrying the brief's scenario standing. They do not establish that a particular institution is legitimate.

Ostrom's [participation and nested-governance principles](submission-package/essay/symbolon/episteme/sources/political-theory-institutions/ostrom/ostrom-2009-beyond-markets-states-nobel-lecture/SOURCE.md#ostrom-2009-beyond-markets-states-nobel-lecture-q001) **tests** the return relation against a distinct governance account: those affected participate in making and modifying rules, local rule-making has recognised standing, and governance can operate through nested levels. Her [warning against rigid transplantation](submission-package/essay/symbolon/episteme/sources/political-theory-institutions/ostrom/ostrom-2009-beyond-markets-states-nobel-lecture/SOURCE.md#ostrom-2009-beyond-markets-states-nobel-lecture-q002) **qualifies** any attempt to turn this into a universal institutional recipe. The essay's covenant relation is **Argued from** this comparison; the lecture does not validate a QL commons.

In delegated software agency the corresponding obligation is inspectable: the goal, permission and evaluation criterion must remain distinguishable from the intention they serve. An evaluator can judge a result without becoming the final author of that intention. A contested result must be able to return through the task interpretation to the criterion and, where necessary, the commission itself. [A28 — Authored Ground](submission-package/essay/symbolon/episteme/arguments/A28-Authored-Ground-Positional-Delegation.md) **extends** this positional relation; [A31 — Deferential Intelligence](submission-package/essay/symbolon/episteme/arguments/A31-Deferential-Intelligence.md) **extends** the possibility that fidelity requires objection, alternative or refusal. These are architectural requirements, not a claim that an implementation has already met them.

## #5→0

The [Symbol / Account / Trust whole-field — Trust keeps the return route active](submission-package/essay/symbolon/episteme/etymologies/symbol-account-and-trust/WHOLE-FIELD.md#trust-keeps-the-return-route-active) **qualifies** this operation at evidence register 3. An entrusted office makes authority executable while affected consequence can revise its commission. Reliance needs a bearer able to answer beyond the account’s present evidence. The resulting distinction **returns-to** that whole field with the consumer’s own source and evidential limits retained.

The mediating office **returns-to** [the whole Ares–Aphrodite relation](submission-package/essay/symbolon/mytheme/worlds/hellenic/ares-aphrodite-hephaestus-poseidon/WHOLE.md#ares-guarantee-release): Poseidon answers for a possible loss, and Hephaestus acts upon that undertaking. The bride-gifts claimed from Zeus, the spectators’ adulterer’s fine and Poseidon’s contingent payment keep their different speakers and offices. This mythemic relation gives mediation a specific bearer without collapsing the three claims into one historical legal instrument.

Authority returns with its consequence. The source-relation has acquired a determinate act; those affected can answer to it; the office can receive their answer as something capable of revising its terms. Covenant is renewed through this passage. Its fidelity consists in allowing the exercised authority to encounter the conditions it was entrusted to serve.

[A30 — Objective Co-Internality](submission-package/essay/symbolon/episteme/arguments/A30-Objective-Co-Internality.md) **extends** this into relations among distinct worlds without making one world's account sovereign over the others. [A35 — Compassion / Epi-Logos as Vocation](submission-package/essay/symbolon/episteme/arguments/A35-Compassion-Sensitivity-to-Origins-Epi-Logos-as-Vocation.md) **extends** the return upon an achieved institutional account. The [4:2 Technē source house](submission-package/essay/symbolon/episteme/sources/media-technology-philosophy/42-techne/42-techne-2026-sovereign-commons/SOURCE.md) **sources** an affiliated design proposal for that application; its implementation, evaluation and public bibliographic debts remain separate from this argued relation.

The page **returns-to** [A24](submission-package/essay/symbolon/episteme/arguments/A24-Arbitration-and-the-Usurpation-of-Measure.md) with the positive criterion its diagnosis requires: authority is derivative, real, and answerable through the labour and lives upon which its exercise depends.

[the Job whole](../../mytheme/worlds/biblical/job/WHOLE.md#job-measure-trust-return) **figures** received mediation in the ending's particular arrangement: the friends whose account has been rebuked must receive Job's prayer. His intercession has real consequence without making him the source of its authority. The office changes their relation through a bearer they had misjudged. This returns covenantal mediation to the difference between serving an originating relation and appropriating its authority; it does not turn Job into a general historical account of covenant.

[the Prisoner whole](../../mytheme/worlds/british-television/the-prisoner/WHOLE.md#prisoner-administered-world) **figures** an office whose successive occupants inherit authority without exposing its source to the governed. Number Two can change while the demand to know why Six resigned and the machinery of his confinement persist. Even Six's election leaves the governing relation intact. The negative case makes received mediation exact: holding an office must include answerability for its terms, rather than treating delegated power as a self-authorising title.

**Depth Restoration:** primary arbitration → entrusted office → executable judgment → affected consequence → revision of the office is restored from the authorial covenant seam, the trust-development record and the August 18 ratification. P1 consumers are M40 and M46; no Movement prose is changed. The reusable distinctions remain C28/C29's office.

**Unresolved Delta:** Jewish, Christian and Islamic covenant histories require differentiated source work; Peters remains an intended acquisition, not evidence consulted here. The priest/king/politician relation is the recovered authorial operation, not a proved single genealogy. The [Native 027 boundary](working/final-argument-quilt-2026-08-23/APHORISM-AND-PITHY-FORMULATION-LEDGER.md#5-title-disposition) removes `(no)name` as an essay-architecture obligation. Son retains its existing place in the native Name series; this page creates no King or Son identity. Concrete implementation cases remain Open.
