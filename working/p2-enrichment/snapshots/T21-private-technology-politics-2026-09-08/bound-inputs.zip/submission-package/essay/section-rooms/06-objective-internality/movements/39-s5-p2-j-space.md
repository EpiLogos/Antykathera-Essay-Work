---
title: "§5 · #2 — J-Space"
node_type: section
page_type: section-movement
station: "§5"
position: "#2"
sequence: 39
claim_status: Offered
evidence_status: operationally-specified
source_ids: [lecun-et-al-2006-energy-based-learning]
tags: [epi-logos/antikythera-essay, argument-map/live, argument-map/section, argument-map/agentworld, station/s5, position/p2]
---
# §5 · #2 — J-Space

## Claim
J-space is the relational field of an agent’s active judgments, affordances, uncertainties, values, tools, memories and interlocutors. Objective internality becomes measurable through transformations of this field.

## Warrant
Distances, attractors, contradictions, permissions, source authority and reachable actions can be compared across context changes. MEF can retain divergent world-models while disclosing the lenses and procedures through which those models were formed.

J-space therefore represents a **bounded articulation of world-for-agency**, not the agent's world in total. Prompt, memory, retrieval, permissions, policy, provenance, feedback and relations to other agents help determine what is near, salient, possible, authoritative or excluded for this locus. Changes to those conditions change the operative field even where the underlying model weights remain fixed.

This is where the tattvic meta-context remains active without being repeated as a second exposition. [[11-s0-p4-tattvic-compression|Māyā, the kañcukas and antaḥkaraṇa]] already make limitation, capacity, knowledge, desire, time, order and inner determination constitutive of an inhabitable finite world. J-space is an Offered technical representation for asking which analogous constraints and affordances can be measured in an artificial operative interior; it is not an identification of the two systems.

## Tension / limit
"Circumscription without circumstance" is the failure mode: a sharp boundary hides the horizon that produced it. A richer J-space can still fail in the same way if its representation is mistaken for the world or if the conditions that generated its distances and affordances disappear from view.

The wider world–agency research boundary is maintained in [[PRE-39-SIGNAL-LINK-TATTVA-WORLD-AGENCY-CONFORMANCE]].

## Anchor and transition
**Image:** a thrown landscape of nearer and farther possibilities whose horizon remains partly outside the map. Its socially occupied baseline becomes visible in [[40-s5-p3-preference-hidden-zero|§5 · #3 — Preference Models and the Hidden Zero]].

J-Space **returns-to** [Count-to-Account](../../../symbolon/episteme/etymologies/encounter-region-name-count/WHOLE-FIELD.md#count-to-account) as a proposed inspectable account of judgment formation. Source, representation, gauge and permission identify different possible causes of divergence; the record must say which changed and what followed. A narrated explanation alone cannot establish those transitions, and the subordinate research object does not exhaust Objective Internality.

A judgment position **returns-to** [Topos — situated return](../../../symbolon/episteme/etymologies/trust-place-logos-nomos-natio-credere/WHOLE-FIELD.md#topos-situated-return) with its source-field, gauge and inherited conditions. Two outputs occupying comparable coordinates can have different histories or permissions. The proposed J-Space record must retain those differences before a passage between positions counts as an accountable comparison; naming a space does not establish the research architecture’s operation.

