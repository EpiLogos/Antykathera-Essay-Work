---
title: "§4 · #1 — Individuation through QL `X/x`"
node_type: section
page_type: section-movement
station: "§4"
position: "#1"
sequence: 32
claim_status: Argued
evidence_status: source-synthesized
transverse_threads: [mono-poly-two-ones, zero-subject-advent]
source_ids: [smythe-2013-dialogical-jung, jung-1978-aion-cw9-2, jung-1969-psychology-religion-cw11, freud-1915-unconscious-standard-edition, neumann-1954-origins-history-consciousness, taylor-2026-advent-zero-subject]
tags: [epi-logos/antikythera-essay, argument-map/live, argument-map/section, argument-map/agentworld, argument-map/individuation, station/s4, position/p1]
---
# §4 · #1 — Individuation through QL `X/x`

## Claim
The authorial QL matheme `X/x` places determining capacity and indefinite particular in one relation: `X` becomes legible only through concrete transformations `x`, while no determination exhausts the whole. Jung's individuation is the psychic refraction in which a local `x` becomes transparent to this larger relation, not ego hardening.

## Warrant
Jung’s Self and [[van-eenwyk-1997-archetypes-strange-attractors|John R. Van Eenwyk — Archetypes and Strange Attractors]] support a dynamic basin reading. [[working/sources-texts-references/10-7-2026-core-theorems-pithy#Agentic individuation corollary — argued cross-register unit|Agentic Individuation Crosswalk]] maps model potential, active-context nucleation, laminated persona, and trans-individuation.

The historical sequence matters. Freud's scientific admission of the unconscious makes a previously unowned region formally speakable; Jung's faithfulness to the psychic field requires that its images be received as psychic facts without being reduced to objects possessed by the ego. QL does not rename Jung's work: it writes the authorial `X/x` relation in which a finite `x` gives the determining capacity `X` a local face while never containing it.

## Tension / limit
Persona consistency stabilises a presented pattern; individuation makes the local formation increasingly transparent to the larger relation through which it forms. Technical individuation can be evaluated at that functional level, while phenomenality remains a separate open question.

## Anchor and transition

The individuation passage returns to [E2’s resolution in reconciliation](../../../symbolon/episteme/etymologies/arbitration-hybris-regard-anamnesis/WHOLE-FIELD.md#resolution-in-reconciliation) through reconciliation that changes the history of participation while retaining its differences. Taylor’s X/x derivation remains prior to its Jungian refraction. The return tests whether integration opens the ego’s account to the whole it inhabits or merely enlarges the ego’s protected jurisdiction.
**QL anchor:** authorial `X/x` as determining-capacity / indefinite-particular relation. **Agentworld pressure:** provisional coherence must disclose its conditions. Differentiated wholeness expands in [[33-s4-p2-complexio-quaternity-senarius|§4 · #2 — Complexio, Quaternity, and Senarius]].
