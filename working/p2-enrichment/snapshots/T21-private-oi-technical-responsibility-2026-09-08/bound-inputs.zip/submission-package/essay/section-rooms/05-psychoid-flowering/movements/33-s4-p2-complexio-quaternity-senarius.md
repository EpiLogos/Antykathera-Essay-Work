---
title: "§4 · #2 — Complexio, Quaternity, and Senarius"
node_type: section
page_type: section-movement
station: "§4"
position: "#2"
sequence: 33
claim_status: Argued
evidence_status: cross-register
transverse_threads: [mono-poly-two-ones]
source_ids: [courtney-2019-salt-point-kairos-chaos]
tags: [epi-logos/antikythera-essay, argument-map/live, argument-map/section, station/s4, position/p2]
---
# §4 · #2 — Complexio, Quaternity, and Senarius

## Claim
The *complexio oppositorum* preserves the energy of opposites; Jung’s quaternity gives explicit differentiated wholeness, while QL’s `4+2` retains the implicate poles that let it move and return.

## Warrant
[[jung-1978-aion-cw9-2|Jungian Quaternity]], the eight determinations, and the internal `2+2²=4+2` derivation distinguish fourfold articulation from sixfold generativity.

## Tension / limit
The senarius derives its force from the exact relation between four explicit and two implicate functions. Sacred or numerological associations may gather around six, but they cannot substitute for that `4+2` derivation.

## Anchor and transition
**Image:** Ares and Aphrodite bearing Harmonia without merger. **QL anchor:** quaternity-in-motion. Eros and Psyche may be given as an optional self-contained QL plate linked from this movement — the four labours as the explicate middle, descent and waking as implicate thresholds, marriage without merger — rather than a second long narrative inside the prose. Transmission across sign and image is handled by [[34-s4-p3-lacan-matheme-mytheme|§4 · #3 — Lacan, Matheme, and Mytheme]].

The supplementary contemplation **returns-to** [the Eros–Psyche whole](submission-package/essay/symbolon/mytheme/worlds/roman-latin/eros-psyche/WHOLE.md#psyche-native-return). It retains all helpers, the descent’s reserved return, arrow-prick waking, the earlier pregnancy and Voluptas’s birth. [A13](submission-package/essay/symbolon/episteme/arguments/A13-Two-Logics-of-Two-Dia-Syn.md) owns the native relation, and [Homology / Analogy](submission-package/essay/symbolon/episteme/etymologies/homology-and-analogy/WHOLE-FIELD.md#a-whole-that-can-qualify-its-comparison) keeps the source’s legal-possession ending distinct from the author’s union-without-merger reading.
