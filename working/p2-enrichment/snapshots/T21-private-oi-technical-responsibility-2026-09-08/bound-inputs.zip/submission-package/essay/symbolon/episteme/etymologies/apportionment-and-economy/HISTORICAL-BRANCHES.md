---
title: "Apportionment / Economy — Historical Branches"
record_id: etymology-apportionment-and-economy-historical-branches
record_type: etymology-historical-companion
register: episteme
claim_status: Argued
source_relation: "Paraphrased primary witnesses and lexical entries; Argued from native consumer operations"
status: T21-developed-source-foldback-complete-consumer-integration-pending
---

# Apportionment / Economy — Historical Branches

## #0 — Distribution acquires a public history

A portion becomes effective through an arrangement: someone allocates it, someone can use it, and its use changes what remains available. The [Apportionment / Economy whole](WHOLE-FIELD.md) **grounds** this relational question. Its historical branches follow the different practices through which a share acquires a name, a measure, an office or a place in a household. Their relation is articulated at each encounter; they do not constitute one uninterrupted history from Greek vocabulary to contemporary computation.

The protected [HISTORY](HISTORY.md) **sources** the inquiry and its open philological leads. This companion develops those leads through identified witnesses without rewriting that authorial surface. Historical usage has evidence register 2; morphological descent has register 1; the consumer consequences developed here have register 3. No phonic resemblance is used as historical evidence. The recovered lexical, Aristotelian and Ephesians witnesses now resolve to canonical source houses with selected paraphrase cards. Their editions, acquisition provenance and remaining collation limits are recorded there.

## #1 — Allotment, possession and naming

<a id="e6-names"></a>
### E6-names — The name and the numbered share

LSJ's *νέμω* entry attests distributing portions, assigning honour or privilege, and, in the middle voice, holding something as one's portion. It supplies examples involving meat, property and land. These different uses establish a semantic field in which giving a share and possessing a share are related acts. They do not establish a single chronological transition from pastoral life to every later law. The [LSJ entry](../../sources/classical-philology/liddell-scott-jones/lsj-1940-greek-english-lexicon/SOURCE.md#lsj-1940-greek-english-lexicon-q009) **historicises** the allotment operation at the level of lexically attested senses.

The canonical [LSJ nomos card](../../sources/classical-philology/liddell-scott-jones/lsj-1940-greek-english-lexicon/SOURCE.md#lsj-1940-greek-english-lexicon-q003) **sources** the relation of νόμος to νέμω and its customary-practice and law senses, with differently accented νομός kept separate. This provides a housed lexical connection while leaving any compulsory pasture-to-state chronology unasserted.

A portion of meat is consumed; a privilege affects what one can do; a plot can be held and worked. Each example has a distributor, recipient and continuing field, but the terms of return differ. The lexical branch thus gives E6 an initial discrimination: apportionment alone does not settle whether a share is a gift, entrusted use, sale, inheritance or domination. Those relations require the practice's own account.

The mature field keeps Latin *nomen* and *numerus* separate. The protected HISTORY's comparative name-family reconstruction and proposed number/apportionment connection retain their dictionary-collation debt. No new Indo-European genealogy is asserted here. Their meeting in denomination has an independently intelligible operation: naming identifies the circulating unit; numbering specifies the amount claimed under it; an issuing and receiving practice makes that claim usable. A shared spelling or a sound cannot perform the work of the issuer and bearer.

This branch **returns-to** [A15](../../arguments/A15-Ratio-Rationality-Measure-Reckoning-Harmony-Account.md), where naming and counting meet without exhausting the addressed particular, and [C29](../../concepts/C29-Mediating-Office-Derivative-Sovereignty.md), where an office owes its standing to a source relation. The comparison concerns what a public mark authorises. It leaves the lexical question distinct from the authority exercised under a name.

## #2 — Exchange brings unlike work under a measure

<a id="e6-ratio"></a>
### E6-ratio — Reckoning, proportion and the criterion

Lewis and Short derives *ratio* from *reor/ratus* and gives reckoning, account, calculation and computation among its senses. Its examples include accounts of receipts and expenditure and the rendering of an account. This is a recoverable Latin semantic range, distinct from a proposed common ancestry for *ratio*, *arithmos* and harmony. The [dictionary entry](../../sources/classical-philology/lewis-short/lewis-short-1879-latin-dictionary/SOURCE.md#lewis-short-1879-latin-dictionary-q006) **historicises** the account's calculative office; the wider root braid remains unverified.

In *Nicomachean Ethics* V.3–5, Aristotle distinguishes distribution by proportion, rectification of injury and reciprocal exchange. Different participants' products must become comparable for exchange: a builder's house and a shoemaker's shoes are his concrete example. Money mediates their comparison through demand and convention. Aristotle connects *nomisma* to *nomos* and says that users can change it or make it useless. He also qualifies commensurability: radically different goods become sufficiently comparable relative to demand. These are claims in his philosophical treatment of exchange, not an archaeological account of the first coins. [Aristotle, V.3–5, W. D. Ross translation](../../sources/classical-premodern-philosophy/aristotle/aristotle-nicomachean-ethics-ross/SOURCE.md#aristotle-nicomachean-ethics-ross-q001) **historicises** the relation of measure, unlike work and convention.

The consumer consequence concerns the denominator. [A15](../../arguments/A15-Ratio-Rationality-Measure-Reckoning-Harmony-Account.md) **grounds** the exact result under a criterion; [A24](../../arguments/A24-Arbitration-and-the-Usurpation-of-Measure.md) **tests** that criterion's authority to govern the encounter. The fact that a price permits exchange does not make price adequate to every question about what is exchanged. A model's score has the corresponding register-3 burden: retain the criterion, comparison class and selecting office so that disagreement can reach the terms of evaluation. Aristotle's examples identify the historical comparison; the modern application is the essay's argument.

A15's finite-ratio kernel and its QL cross-comparison remain native derivations. The Latin attestation gives a history of uses of *ratio*; it neither derives those operations nor licenses arithmetic identities the operations do not claim. The branch **returns-to** [M40](../../../../section-rooms/06-objective-internality/movements/40-s5-p3-preference-hidden-zero.md) with a concrete question about evaluation: can the affected answer revise the selected measure, or only receive a new score under it?

## #3 — A household's provision and the accumulation of money

<a id="e6-house"></a>
### E6-house — Arrangement, use and dependence

In *Politics* I.8–10 Aristotle distinguishes acquiring provisions from using them in household management. A shoe can be worn or exchanged. He describes money arising in wider exchange and a stamp replacing repeated weighing; accumulation then becomes an end separable from the provision it first served. These are Aristotle's explanatory distinctions and origin narrative. They are not independently verified coinage chronology. His household also includes relations of master and enslaved person, husband and wife, parent and child; its distribution of authority cannot be redescribed as a modern equal commons. [Aristotle, *Politics* I, Benjamin Jowett translation](../../sources/classical-premodern-philosophy/aristotle/aristotle-politics-jowett/SOURCE.md#aristotle-politics-jowett-q002) **historicises** the relation between provision, purpose and acquisition while preserving that hierarchical setting.

The canonical [Lewis–Short credo card](../../sources/classical-philology/lewis-short/lewis-short-1879-latin-dictionary/SOURCE.md#lewis-short-1879-latin-dictionary-q002) **compares** another historically specific act of entrusting: its senses distinguish lending, committing something to another’s protection, confidence and belief. The cited Cato passage remains an independently uncollated primary context. That semantic witness gives delegation a Latin neighbour without equating every entrusted capacity with a loan.

The contemporary return separates the office from that hierarchy. [A29](../../arguments/A29-Power-Delegated-Labour-Return.md) **extends** provision into the commissioning relation: an output depends on work and capacities which its recipient did not originate. The question is where their consequences can return. An account that measures only the acquired product can omit the labour, constraints and depleted conditions that made it possible. This is E6's argued diagnosis, with actual costs requiring their own records.

The ancient household and modern commons therefore meet at a specified problem of distribution, with a material difference in who may govern. [Ostrom's source house](../../sources/political-theory-institutions/ostrom/ostrom-2009-beyond-markets-states-nobel-lecture/SOURCE.md#ostrom-2009-beyond-markets-states-nobel-lecture-q001) **compares** institutions in which most affected participants can make and modify resource rules, local rule-making is recognised and governance can be nested. Her q002 **qualifies** rigid transplantation and distinguishes social from ecological conditions. These selected passages provide an evidenced institutional relation rather than a universal historical successor to *oikonomia*.

The branch **returns-to** [C54](../../concepts/C54-Commons-Non-Monopoly.md) and [A30](../../arguments/A30-Objective-Co-Internality.md): shared ordering must preserve consequential local authority and refusals. A federation's local Bimba can remain an actual reference for its downstream comparisons while remaining answerable to wider sources. The nested relation does not require all communities to surrender their grounds to one completed account.

## #4 — Administration, fullness and differentiated restoration

Ephesians 1:9–10 places *οἰκονομίαν τοῦ πληρώματος τῶν καιρῶν* within the disclosure of divine purpose: the administration concerns the fullness of times and the gathering of things in heaven and on earth in Christ. The verbal movement connects an arrangement to a temporal fulfilment and gathering. It is a Christological claim in the letter, not a general theorem that every economy necessarily returns to plenitude. The [SBL Greek text with reverse interlinear, Ephesians 1:9–10, PDF page 2](../../sources/biblical-studies/pauline-corpus/ephesians-sbl-reverse-interlinear/SOURCE.md#ephesians-sbl-reverse-interlinear-q001) **historicises** this theological use. The Greek phrase has now been retrieved; a complete translation and reception history has not been supplied by that retrieval.

A patristic comparison already has a canonical evidence home. In *Against Heresies* I.10.3, Irenaeus describes the work of exposition as explaining God's dispensation in human salvation, including differences among temporal and eternal things, successive covenants and the timing of the Son's advent. In I.1–8 he reports a different, Valentinian distribution of powers and restoration, which he opposes. His I.7 distinguishes Achamoth's union with the Soter, the Demiurge's intermediate destination and matter's destruction. The [Irenaeus source house](../../sources/classical-premodern-philosophy/irenaeus/irenaeus-1885-against-heresies-book-1/SOURCE.md) **sources** these selected passages in the Roberts–Rambaut ANF translation, with Irenaeus's hostile testimony kept distinct from his own rule of faith.

That difference is load-bearing. A vocabulary of fullness can organise sharply different accounts of creation, mediation and completion. The shared word does not establish that everything returns in the same way or that all historical participants speak for one doctrine. The [complete Valentinian whole](../../../mytheme/worlds/late-antique-gnostic/valentinian-sophia-horos-achamoth/WHOLE.md) **figures** the differentiated telling; its jointly contributed Soter and unequal destinations retain their distinct offices within that whole.

The theological branch **returns-to** the [whole field's commons operation](WHOLE-FIELD.md#commons-preserves-the-wider-economy) as a comparison of arrangement and differentiated consequence. E6's argument for answerable local power is its own register-3 operation. Neither Ephesians nor Irenaeus certifies a QL institution, and the modern institutional argument does not retrospectively change either theological witness.

## #5→0 — Name and power return through vocation

A historical account can recover an institution's purpose while leaving the lives affected by it abstract. [A35](../../arguments/A35-Compassion-Sensitivity-to-Origins-Epi-Logos-as-Vocation.md) **extends** source-return into loving sensitivity to origins: the recovered relation must be capable of changing how its particular other is treated. [Taylor's Draft 3](../../sources/internal-corpus/taylor/taylor-2026-definition-god-draft3/SOURCE.md#taylor-2026-definition-god-draft3-q023) **sources** the devotion to whole and aperture; its terminal vocation releases the achieved work into other lives. This is native authorial development, with ancient theological and Egyptian attributions retaining their own source obligations.

The branch **returns-to** [A18′'s Name/Power face](../../conjugate/A18-prime-Traversal-Run-in-Code.md#a18p-name-power) through the four already developed consequences: expenditure committed, course authorised, affected other retained and work returned with costs and correction rights. It **returns-to** [A29](../../arguments/A29-Power-Delegated-Labour-Return.md) through the distinction between delivery of a product and revision of the governing commission. It **returns-to** [C62](../../concepts/C62-Planetary-Computation.md) through material and institutional dependencies exceeding the interface. These applications retain E6's two terms and five operations.

**Remaining source work:** comparative entries for *nomen/numerus*, the proposed *nem-* reconstruction, nomenclature/denomination formation and the *arithmos/harmony* braid remain uncollated. The selected Aristotle and Ephesians passages are now housed as bounded paraphrases; the recovered νέμω and ratio entries are now admitted beside nomos and credo in the LSJ and Lewis–Short houses; these selected textual witnesses do not constitute print-edition or complete reception-history collation. Irenaeus's selected ANF witness and Ostrom's selected pages retain their existing source-house boundaries. A complete history of coinage, theological reception, AI labour or planetary material chains is not claimed. These debts qualify historical attribution and empirical application; the mature operational claims retain their Argued standing.
