---
title: "Whole Field — Apportionment / Economy"
record_id: etymology-apportionment-and-economy
record_type: etymology-whole
register: episteme
claim_status: Argued
source_relation: "Argued from native relational field; Paraphrased historical branches; operational homology distinguished from descent"
status: T21-developed-parent-consumer-integration-pending
---

# Whole Field — Apportionment / Economy

**Standing:** mature T09 dyadic field, developed through its five existing operations. Apportionment and Economy remain the terms; Name/Power and vocation enter through their declared consumers. The six sections organise this account without generating a sixth operation. The protected [HISTORY](HISTORY.md) retains the authorial lexical inquiry; [HISTORICAL-BRANCHES](HISTORICAL-BRANCHES.md) **historicises** the field through separately identified witnesses.

## #0 — The share within its sustaining order

<a id="whole-field-claim"></a>
### Whole-field claim

**Apportionment** names the act of distributing a finite share, capacity, role or measure within a wider field. **Economy** names the ordering/management of a relational whole through which such distributions become operative. The canonical relation is not that these words share one root or one political theory. It is that finite agency repeatedly appears as a distribution of powers inside an order that no single share exhausts.

An allotment changes what someone can do. It sets aside time for a task, entrusts an office with authority, or establishes the unit under which unlike things can be compared. The share acquires a determinate boundary; the relations sustaining it continue across that boundary. Economy follows those relations through use, consequence and renewed distribution. An account of the allotted product therefore owes an account of the powers and conditions through which it became available.

The five operations below follow this pressure from finite capacity to planetary consequence. Historical descent belongs to evidence register 1; attested usage to register 2; the essay's operational homologies to register 3; a phonic or poetic re-entry to register 4. A movement between registers requires its own warrant. The field's Argued standing does not depend on settling a conjectural Latin reconstruction, and a verified Greek word does not establish the justice of a distribution.

## #1 — A capacity takes a finite office

<a id="canonical-operations"></a>
### Canonical operations

### Power becomes finite by apportionment

**A09 Tattvic Differential Field** and **C14 Māyā / Operative Measure** consume this operation: unbounded capacities become locally workable as finite knowledge, desire, time, order and agency. This is an operational homology; *Māyā* and *kañcuka* are not etymologically derived from apportionment/economy.

[A09](../../arguments/A09-Tattvic-Differential-Field.md) **grounds** the full descent: luminosity and self-articulating power differentiate through inverse universal orientations, a subject/object seam, contracted capacities and an inner instrument. [C14](../../concepts/C14-Maya-Operative-Measure.md) **defines** the operative horizon within that movement. A finite agent can know and act because its knowledge and power have a determinate reach. Recognition returns through those effective distinctions to their source; it preserves the apparatus through which a world is encountered.

E6 follows what contraction makes available. A permission, a period of time and a selected field of relevance distribute different capacities; increasing one does not automatically enlarge the others. [A14](../../arguments/A14-Computational-Process-Ontology.md) **extends** this relation into computational process. A system's formal ability, permission to execute and capacity to answer for an effect need distinct accounts. The source of each allotment becomes consequential when an obstacle requires the terms of action to change.

## #2 — A measure makes differences actionable

### Measure is an apportioned criterion

**A15 Ratio / Rationality** and **A24 Arbitration** consume the insight that a criterion is situated within an economy of relation. Hybris begins when the local measure treats its apportioned office as the source of measure itself.

[A15](../../arguments/A15-Ratio-Rationality-Measure-Reckoning-Harmony-Account.md) **grounds** the exactness of the comparison. Its terms must be distinguished and brought under a stated unit before their ratio becomes usable. A denomination joins a named token to an amount recognised in circulation. Its efficacy depends on an issuer, a bearer and practices which let its claim be honoured. Name and number meet here by public operation; the separate lexical histories remain in the [naming branch](HISTORICAL-BRANCHES.md#e6-names), which **qualifies** their historical relation.

A disputed price, rank or score can concern the calculation, the selected unit, the comparison class or the authority to use the result. Correcting arithmetic answers only the first dispute. [A24](../../arguments/A24-Arbitration-and-the-Usurpation-of-Measure.md) **extends** the return to the deciding office, while [C29](../../concepts/C29-Mediating-Office-Derivative-Sovereignty.md) **defines** its derivative authority. A decision remains effective while its criterion becomes answerable. What the measure excludes can then change a subsequent judgment without making every earlier calculation meaningless.

The [ratio branch](HISTORICAL-BRANCHES.md#e6-ratio) **historicises** Latin accounting and Aristotle's differentiated kinds of proportion. A15's native ratio operations retain their own derivation. Neither a dictionary entry nor the success of a monetary comparison turns the QL cross-reading into ordinary fraction equality.

## #3 — Commission, expenditure and returned work

### Delegated labour distributes capacity and return

**A25, A28, A29** and **C28, C29, C53** consume the field as a grammar of delegated power: a source relation apportions authority, labour is performed under bounded office, and effects/evidence/value must be returned.

[A25](../../arguments/A25-Covenant-Mediating-Office-Source-Authority.md) **grounds** the entrusted office, and [A28](../../arguments/A28-Authored-Ground-Positional-Delegation.md) **defines** the distinction between intention, formulated commission and situated agency. The delegate meets circumstances which the commission has not exhausted. Its fidelity includes the capacity to bring back an obstacle, objection or changed possibility. [A29](../../arguments/A29-Power-Delegated-Labour-Return.md) **extends** this into the distribution of product and cost: the commissioner, performer, beneficiary and bearer of consequence can be different participants. [C53](../../concepts/C53-Power-Delegated-Labour.md) **defines** the relation their separate accounts must retain.

A product received while its encountered resistance is discarded leaves the next commission insulated from the work it commands. Return therefore includes a route to revise purpose, evaluator, permission or institutional terms. The difference concerns governing power as well as information. A refusal that can only be logged while the same act proceeds has not yet changed the commission's reach.

[A18's complete Name/Power field](../../arguments/A18-Primordial-Symbolon-and-Its-Eight-Determinations.md) **grounds** the coequal series **Truth, Mind, Word, Logos, Son, Image** and **Play, Need, Sacrifice, Decision, Love, Work**. Their relation gives articulation its power, expenditure and consequence. E6 receives this already established office through A18′; it does not rename itself after it. The native traversal remains `/ = −/−, 0/1, ?/!, −/+, X/x, AM/IS, ∞/dx, 1/0`, with parent and return bracketing the six determinations. Taylor's `X/x` retains determining capacity and indefinite particular; its psychological refractions have no authority to replace that provenance.

### Liability and release

The delegated-office operation **returns-to** [the whole Ares–Aphrodite relation](submission-package/essay/symbolon/mytheme/worlds/hellenic/ares-aphrodite-hephaestus-poseidon/WHOLE.md#ares-guarantee-release). An undertaking apportions a possible loss to Poseidon and enables Hephaestus to release the lovers; the song leaves payment unreported. [A25](../../arguments/A25-Covenant-Mediating-Office-Source-Authority.md) receives the responsible office, while [A23](../../arguments/A23-Trust-Faith-and-the-Formal-Limit.md) receives committed reliance beyond the completed display. This is an evidence-register-3 relation, preserving the different claims of marriage gifts, fine and contingent surety rather than deriving one legal history from their narrative succession.

### The technological act’s Name/Power return

[A18′ — the Name/Power face](../../conjugate/A18-prime-Traversal-Run-in-Code.md#a18p-name-power) **returns-to** this whole with four connected consequences: committed expenditure, an authorised selected course, an affected other able to change the terms, and a result returned with costs and correction rights. **Delegated labour distributes capacity and return** supplies the local office; **commons preserves the wider economy** keeps the achieved result answerable to its generative field. These are register-3 applications within the existing five-operation field, not new lexical derivations or additional generated E6 positions. Their implementation requires actual execution evidence.

## #4 — The economy exceeds its owner and its interface

### Commons preserves the wider economy

**C54 Commons / Non-Monopoly** and **A35** consume the inverse: local shares can remain real and even privately governed while no share is permitted to claim ownership of the whole generative field.

[C54](../../concepts/C54-Commons-Non-Monopoly.md) **defines** governed plurality. Participants require authority over their interiors and ways to share without losing the ability to revise, refuse, leave and reconnect. [A30](../../arguments/A30-Objective-Co-Internality.md) **extends** that distribution into reciprocal world-constitution: another's contribution can change the local conditions from which action proceeds. A shared store becomes consequential through permissions and correction routes; possession of the store alone does not provide them.

The recursive Bimba office remains real here. A locally governed reference field can be original for downstream comparisons while itself remaining a produced reflection relative to its wider source. [A28's local reference operation](../../arguments/A28-Authored-Ground-Positional-Delegation.md) **grounds** that recursion. It allows disputes about source, lens, gauge or permission to alter the appropriate level. It gives neither a federating centre nor a local custodian ownership of the ultimate ground.

[Ostrom's selected passages](../../sources/political-theory-institutions/ostrom/ostrom-2009-beyond-markets-states-nobel-lecture/SOURCE.md#ostrom-2009-beyond-markets-states-nobel-lecture-q001) **compare** affected participants' rule-making, recognised local rights and nested governance with this proposed institutional return. Her next passage **qualifies** transplantation across differing social and ecological conditions. The comparison gives E6 concrete governance questions while leaving an implemented QL commons to its own evidence.

### Planetary computation exposes hidden economy

**C62 Planetary Computation** returns computation to the planetary distribution of energy, labour, networks, data, standards and institutions that make local model outputs possible. The operation is explanatory and political-economic, not a lexical derivation.

[C62](../../concepts/C62-Planetary-Computation.md) **extends** the account beyond the visible session. Hardware has material conditions; deployment assigns permissions; standards determine circulation; subsequent uses distribute benefit and burden. The analysis must follow each consequential relation far enough to identify who can change it. An energy total cannot alone settle labour attribution, and a provenance record cannot alone grant those affected the power to contest use.

The [household and governance branch](HISTORICAL-BRANCHES.md#e6-house) **historicises** the distinction between provision, use and accumulation. Its institutional witnesses give finite cases through which the broader question becomes legible. A measured supply chain and its actual redress remain empirical work; planetary scale supplies no inference to one planetary Subject.

## #5→0 — The achieved share becomes a condition of further life

<a id="relational-return"></a>
### Relational return

```text
whole field / economy
        ↓ apportion
finite office / capacity / share
        ↓ act
labour / judgment / transformation
        ↓ return
consequence / evidence / value
        ↺
wider field revised
```

This circuit makes economy a first-class relation rather than an after-the-fact “resource” note.

[A35](../../arguments/A35-Compassion-Sensitivity-to-Origins-Epi-Logos-as-Vocation.md) **extends** the circuit through compassion as loving sensitivity to origins. Its vocation concerns how the source is approached: genealogy can enable care or supply a more effective means of possession. Returned knowledge must leave the other capable of answering and changing the act. Taylor's [Draft 3, terminal vocation](../../sources/internal-corpus/taylor/taylor-2026-definition-god-draft3/SOURCE.md#taylor-2026-definition-god-draft3-q024) **sources** the double devotion to whole and particular aperture, followed by release into use. The achieved work becomes available beyond its maker while its provenance and consequences remain answerable. Release carries forward the product; it does not cancel the costs through which it arrived.

The consumer return is differentiated. The field **returns-to** [M11](../../../../section-rooms/01-differentiating-mind/movements/11-s0-p4-tattvic-compression.md) with contraction as effective capacity; [M40](../../../../section-rooms/06-objective-internality/movements/40-s5-p3-preference-hidden-zero.md) with the criterion and its selecting office retained; [M46](../../../../section-rooms/07-instrument-returns/movements/46-s50-p3-4-2-mono-poly.md) with shared governance and local refusal; and [M48](../../../../section-rooms/07-instrument-returns/movements/48-s50-p5-ahi-planetary-return.md) with labour, material consequence and vocation carried into the next act. These returns preserve each movement's own burden.

[C28](../../concepts/C28-Covenant-Primary-Arbitration.md) **defines** the undertaking through which delegated capacity becomes an entrusted office. The field **returns-to** it with consequence able to reach that undertaking, alongside C29's derivative exercise of authority. [C55](../../concepts/C55-Reflective-Field-Mirror-That-Moves-First.md) **extends** the return where a model changes the conditions it represents: the institution holding the mirror must expose its own allocation of power to correction. [C57](../../concepts/C57-Agentworld.md) **extends** the same question through durable roles and artifacts, where an inherited result becomes another agent's condition of action.

The field also **returns-to** [M37](../../../../section-rooms/06-objective-internality/movements/37-s5-p0-math-moves-meaning.md) through the constituted means of an actionable world, and [M45](../../../../section-rooms/07-instrument-returns/movements/45-s50-p2-antikythera-attunement.md) through the instrument's dependence on craft, inherited measure and a situated observer. [C59](../../concepts/C59-Cultural-Individuation-Epi-Logos-as-Culture.md) **extends** these operations into culture: inherited names and measures can change without a new collective owner claiming the field which made their revision possible.

**Source and completion boundary:** all five mature operations are developed here. The companion distinguishes retrieved historical witnesses, existing source-house evidence and remaining lexical/edition debts. External acquisition does not change native claim standing. Reciprocal consumer additions outside this page are supplied for parent integration in the private E6 packet; this two-file development does not certify that those additions have landed.

The [meal epistemic metabolism whole](../../../mytheme/worlds/frank-taylor/meal-epistemic-metabolism/WHOLE.md#meal-shared-table) **figures** the whole apportionment circuit at register 3. A sustaining economy gives a share and office; preparation and serving put it to work; labour, cost, evidence and value return to the field that can revise the next allocation. A companion can question both the portion and the terms of the table. The commons preserves that power to answer while the contribution remains attributable to its giver.
