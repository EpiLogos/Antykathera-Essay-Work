---
title: "Whole Field — Arbitration / Hybris / Regard / Anamnesis"
record_id: etymology-arbitration-hybris-regard-anamnesis
record_type: etymology-whole
register: episteme
claim_status: Argued
claim_status_scope: "Ratified authorial conjugate field and its consequential relations; lexical, historical and implementation claims retain their own evidence standing."
source_relation: "Argued authorial relational construction; source-specific semantic, historical and comparative branches distinguished."
field_id: E2
cardinalities:
  operative_face: 6
  conjugate_face: 6
  generated_relations: 6
  evidence_registers: 4
source_ids:
- taylor-2026-core-theorems-pithy
- taylor-2026-definition-god-draft3
- taylor-2026-symbolon-dynamics
- gebser-1985-ever-present-origin
- watson-1998-resonance-of-emptiness
- van-eenwyk-1997-archetypes-strange-attractors
- mcgoohan-markstein-1967-the-prisoner
- homer-1919-odyssey-murray
- ostrom-2009-beyond-markets-states-nobel-lecture
- bratton-2026-agentworld-brief
protected_history: HISTORY.md
historical_development: HISTORICAL-BRANCHES.md
---

# Whole Field — Arbitration / Hybris / Regard / Anamnesis

**Standing:** mature T09 Etymology whole-field. [HISTORY.md](HISTORY.md) remains the protected lexical/historical carrier; [Historical branches](HISTORICAL-BRANCHES.md) develops the source distinctions and the questions returned by use. This page governs the relational operations generated from the whole field and their canonical Argument/Concept consumption.

## Evidence discipline

The field does **not** claim that *arbitration*, *hybris*, *regard* and *anamnesis* descend from one root. Historical derivation and attested senses belong to registers **1 Philological descent** and **2 Attested semantic field** and must be warranted term by term in the historical/source branch. The conjugate generation below is register **3 Operational homology / authorial relational construction**. Any later sound-play is register **4 Poetic / phonic re-entry** and may never borrow philological warrant.

## Conjugate field

```text
6                                  6′

Continuity                         Indeterminacy
Criterion                          Distinction
Delineation                        Difference
Arbitration                        Crisis
Con-text                           Diaphaneity
Resolution                         Reconciliation
```

The two sixfolds are not lists to be merged. They are conjugate determinations whose relation generates a third articulated field:

```text
Continuity-in-Indeterminacy
→ Origin / unmeasurable

Criterion-through-Distinction
→ Measure / Limit

Delineation-through-Difference
→ Perspective / Frame

Arbitration-in-Crisis
→ Decision / Hybris

Con-text-through-Diaphaneity
→ Regard

Resolution-in-Reconciliation
→ Anamnesis / Recognition / Return
```

The left-hand expression on each pair is the **generated relation**. The right-hand term is a **semantic flowering** or operation that becomes available there. These offices must never be collapsed. In particular, `Arbitration-in-Crisis` is not a decorative way of spelling *hybris*. It names a decision-bearing relation between finite arbitration and the indeterminacy/crisis that calls for decision; *hybris* flowers when the deciding office forgets that crisis and treats its local measure as source measure.

Likewise, `Con-text-through-Diaphaneity` is the generated relation; *Regard* is the operation in which the context and Other can become visible through the determination instead of remaining hidden behind it. `Resolution-in-Reconciliation` is generated before *anamnesis/recognition/return* flowers as recollective re-situation of an achieved settlement.


## The six generated relations in operation

<a id="continuity-in-indeterminacy"></a>

### #0 — Continuity-in-Indeterminacy

A judgment enters a field already carrying relationships, purposes and consequences. Its conditions remain active through the act of judging, including conditions its criterion cannot yet state. Continuity therefore exceeds the repetition of a previous result. It allows this determination and a later correction to belong to one history without making the earlier account the measure of everything that can follow.

Origin / unmeasurable flowers here as the continuing source relation of finite measure. The field's native [QL source](../../sources/internal-corpus/taylor/taylor-2026-core-theorems-pithy/SOURCE.md) governs that relation. It is not an inference from a Latin or Greek root, and a missing lexical citation does not suspend it. At the same time, an unspecified origin cannot take over the concrete work of showing which witness, rule, inheritance or permission made an actual decision possible. The whole lets those histories become determinate without exhausting origin in their inventory.

<a id="criterion-through-distinction"></a>

### #1 — Criterion-through-Distinction

A criterion establishes an according-to-which by making a distinction effective. Evidence can now be relevant or irrelevant to a question; a comparison can be adequate for one task and inadequate for another. Measure has a real competence because its limit makes an operation possible. Calling every limit hybris would erase the very achievement that later needs to return.

The affected field matters before a verdict. Who selected the alternatives, which differences count, and what warrants this standard for these circumstances? A stable measure can survive a challenge when its warrant survives examination. A protected criterion prevents that examination from reaching its authority. [C27's discrimination](../../concepts/C27-Protected-Account-Occupied-Zero-Source-Claim.md) **qualifies** this generated relation at register 3: warranted retention and warranted revision are both possible, whereas immunity from either is source-claim.

<a id="delineation-through-difference"></a>

### #2 — Delineation-through-Difference

The criterion receives a situated edge. A question has a frame; some witnesses become legible within it, and others fall outside the account. Delineation is therefore distinct from the criterion itself. A system can use a consistent standard over a field whose boundaries already exclude the evidence that would expose its inadequacy.

[C08](../../concepts/C08-Context-Context-Frame.md) **returns** the distinction between a context and a bounded Context Frame. The frame selects conditions sufficient to proceed; the world includes conditions the selection has not captured. [A04](../../arguments/A04-Diaphaneity-Contextual-Transparency.md) and [C09](../../concepts/C09-Diaphaneity.md) **return** the inverse reading: the view discloses a world and also the placement of the viewer. This is the register-3 operation that prepares Regard. It does not turn a contextual frame into an observer outside all frames.

<a id="arbitration-in-crisis"></a>

### #3 — Arbitration-in-Crisis

A decision gives consequence to a distinction when the differentiated claims require settlement. Arbitration is this deciding office; judgment is the account of what is warranted; valuation gives something weight or worth within it. Selection, discrimination and orientation have helped constitute the situation in which the cut can act. Their participation does not make them interchangeable names for the decision.

The ratified hybris theorem remains exact: **the local determination occupies the place of its own determining condition**. A score replaces the person, an office claims the people who grant its standing, or a psychic formation dictates the meaning of every encounter. The deciding act can be useful before and after its jurisdiction is corrected. The error is the source-office it claims.

[A24](../../arguments/A24-Arbitration-and-the-Usurpation-of-Measure.md) **consumes** the whole six-relation field and **returns** the hidden-criterion test: can the governed person question what makes the judgment authoritative, or do they receive another result inside the same criterion? Its [Prisoner source](../../sources/media-technology-philosophy/mcgoohan-markstein/mcgoohan-markstein-1967-the-prisoner/SOURCE.md) gives a specific dramatic event. Six asks who One is; the administrator answers by naming him Six. Number Two persists as an office across incumbents, while Six is fixed as the administrable captive. That scene figures office-confusion in a television work; it does not establish the history of legal arbitration.

[A19](../../arguments/A19-Complex-as-Local-Arbitration-Regime.md) and [C31](../../concepts/C31-Complex.md) **return** a different, psychic discrimination. An established complex can order affect and response competently while mistaking its local jurisdiction for the whole life. Its return changes jurisdiction without requiring the complex's extermination. A technical policy can perform a comparable selection without thereby being a psychic complex.

<a id="con-text-through-diaphaneity"></a>

### #4 — Con-text-through-Diaphaneity

Regard flowers when the determining form lets its bearing relations become visible and consequential. Naming the evaluator is a beginning. The affected person, excluded source or returning cost must also be able to reach an office authorised to reconsider the frame, criterion or commission. Additional disclosure which cannot make that journey leaves the deciding office protected.

[Gebser's source](../../sources/phenomenology-continental-philosophy/gebser/gebser-1985-ever-present-origin/SOURCE.md) contributes a mapped historical account of perspective becoming transparent to its conditions and co-presence; the field's contextual and institutional continuation is authorial. The [Watson–Gans–Levinas source chain](../../sources/psychology/watson/watson-1998-resonance-of-emptiness/SOURCE.md) gives the encounter a distinct ethical pressure: the Other exceeds the image held of them and can change the economy through which the encounter is valued. Gans remains nested through Watson's thesis, and the primary Levinas passages retain selected-edition collation. Regard here is neither a French etymological proof of Levinas nor a translation of every tradition's ethical term.

[A31](../../arguments/A31-Deferential-Intelligence.md) and [C47](../../concepts/C47-Deferential-Intelligence.md) **return** five possible sites of correction: answer, task interpretation, world-model, evaluator/gauge and terms of commission. An improved answer under an unchanged evaluator does not establish correction of the evaluator. [C56](../../concepts/C56-Compassion-Sensitivity-to-Origins.md) **qualifies** the manner of the return: disclosed origins must not become another means of possession. Refusal, withholding and a maintained boundary can preserve the Other when demanded reconciliation would suppress their response.

<a id="resolution-in-reconciliation"></a>

### #5→0 — Resolution-in-Reconciliation

A settlement becomes recollective when its achievement returns with its history, exclusions and source relations available. Anamnesis / Recognition / Return flowers from this generated relation. The settlement can be retained, narrowed, withdrawn or revised; whichever result is warranted becomes a condition of the next encounter. Reconciliation preserves the differences through which the history occurred.

[A21](../../arguments/A21-Individuation-Recognition.md), [C19](../../concepts/C19-Pratyabhijna-Recognition.md) and [C34](../../concepts/C34-Individuation.md) **return** the distinction between remembering an object and changing the relation through which a formation knows its source. Greek anamnesis, Śaiva recognition and Jungian individuation have separate histories. The authorial known→unknown→known movement recovered through [Van Eenwyk's protected encounter](../../sources/psychology/van-eenwyk/van-eenwyk-1997-archetypes-strange-attractors/SOURCE.md) and [Symbolon Dynamics](../../sources/internal-corpus/taylor/taylor-2026-symbolon-dynamics/SOURCE.md) receives a changed interpreter, not a pristine beginning or a larger complex promoted to sovereign. The copied note quotations remain leads; the native `X/x` relation remains Taylor's.

[A33](../../arguments/A33-Epistemic-Cultivation-Operational-Parity.md) and [C46](../../concepts/C46-Epistemic-Cultivation.md) **return** the second-circuit test. The next inquiry must be able to do something different because of what the prior encounter disclosed: admit the excluded witness, revise a category, change a permission, alter a gauge or recommission the task. Keeping a log without changing its use does not complete this return. [Draft 3's authorial return](../../sources/internal-corpus/taylor/taylor-2026-definition-god-draft3/SOURCE.md) keeps devotion to the exceeding whole together with devotion to this particular aperture. That obligation retains the local work through its correction. The technical experimental programme is Offered; the generated relation is already ratified.

## A determination carried into a second circuit

The following is an **Offered analytic test case**, not a report of an implemented system. A commissioned evaluation compares two answers using a criterion of agreement with an approved reference. The reference has a known date and scope; agreement is a legitimate question within those limits. The frame nevertheless excludes a later primary correction. One answer repeats the reference and receives the better score; the other incorporates the correction and is penalised for disagreement.

Regard requires the excluded correction to reach the maintainer authorised to revise the reference and evaluator. Changing only the second answer would leave the disputed criterion intact. The maintainer checks the primary passage, records the earlier reference's legitimate scope, and changes the criterion to assess warranted use of the corrected evidence. If the correction proves irrelevant, retaining the earlier criterion with that finding recorded is also an answerable outcome.

In the second circuit both answers are assessed under the declared criterion and its retained history. The formerly penalised answer can now be recognised as source-faithful, and the earlier high score remains intelligible as a result of its old frame. This sequence separates measure, exclusion, decision, challenge, authorised revision and provenance-bearing return. An actual implementation owes paired runs, the identified source correction, the responsible office, the changed evaluator and the consequential outcome; prose describing those objects cannot stand in for them.

[Agentworld](../../sources/media-technology-philosophy/bratton/bratton-2026-agentworld-brief/SOURCE.md) **compares** the institutional setting through q026–q027 and the shared procedural grammar with divergent world-models through q029. Its p. 53 scenario rider remains active. [Ostrom](../../sources/political-theory-institutions/ostrom/ostrom-2009-beyond-markets-states-nobel-lecture/SOURCE.md) **qualifies** the institutional design through the participation of affected users in modifying rules and the recognition of local rule-making, while warning against rigidly transplanting principles. These sources do different work: neither verifies this Offered evaluator test, the QL derivation, nor a universal history of arbitration.

## Argument consumption

- **[A04 Diaphaneity / Contextual Transparency](../../arguments/A04-Diaphaneity-Contextual-Transparency.md)** consumes `Con-text-through-Diaphaneity → Regard`: contextual transparency becomes answerability to the conditions visible through the view.
- **[A19 Complex as Local Arbitration Regime](../../arguments/A19-Complex-as-Local-Arbitration-Regime.md)** consumes `Arbitration-in-Crisis → Decision / Hybris`: a complex can become a local criterion that forgets its derivation.
- **[A21 Individuation / Recognition](../../arguments/A21-Individuation-Recognition.md)** consumes `Resolution-in-Reconciliation → Anamnesis / Recognition / Return`: return re-situates a local settlement without deleting the differentiated history.
- **[A24 Arbitration and the Usurpation of Measure](../../arguments/A24-Arbitration-and-the-Usurpation-of-Measure.md)** consumes the **whole `6 / 6′ → 6+6′` conjugate field**. It is the primary Argument consumer and does not replace this Etymology office.
- **[A27 Self and Other](../../arguments/A27-Self-and-Other-Unity-without-Possession.md)**, **[A31 Deferential Intelligence](../../arguments/A31-Deferential-Intelligence.md)**, **[A33 Epistemic Cultivation](../../arguments/A33-Epistemic-Cultivation-Operational-Parity.md)** and **[A35 Compassion](../../arguments/A35-Compassion-Sensitivity-to-Origins-Epi-Logos-as-Vocation.md)** consume Regard/Anamnesis as revision and origin-sensitive return.

## Concept consumption

The primary Concept routes retain different burdens, all at operational register 3:

| Consumer | Consumed relation and returned distinction |
|---|---|
| [C08 Context Frame](../../concepts/C08-Context-Context-Frame.md) | Delineation-through-Difference and Con-text-through-Diaphaneity: a frame remains a bounded act inside its world; expose which selection changes. |
| [C09 Diaphaneity](../../concepts/C09-Diaphaneity.md) | Con-text-through-Diaphaneity: mediation becomes readable through its effects; additional visibility must be able to bear on judgment. |
| [C19 Recognition](../../concepts/C19-Pratyabhijna-Recognition.md) | Resolution-in-Reconciliation: distinguish recollection from recognition of source-relation; preserve each tradition's evidence. |
| [C27 Protected Account](../../concepts/C27-Protected-Account-Occupied-Zero-Source-Claim.md) | Criterion-through-Distinction and Arbitration-in-Crisis: distinguish a justified stable measure from criterion immunity. |
| [C28 Covenant](../../concepts/C28-Covenant-Primary-Arbitration.md) | Arbitration-in-Crisis: distinguish received standing from the finite decision authorised by it. The Fides bridge keeps its separate field. |
| [C29 Mediating Office](../../concepts/C29-Mediating-Office-Derivative-Sovereignty.md) | Arbitration-in-Crisis and Con-text-through-Diaphaneity: interpretation and execution have real but derivative authority; return must reach the commission. |
| [C31 Complex](../../concepts/C31-Complex.md) | Arbitration-in-Crisis: local psychic competence can survive a change of jurisdiction; technical selection alone is not a complex. |
| [C34 Individuation](../../concepts/C34-Individuation.md) | Resolution-in-Reconciliation: preserve differentiated life, history and responsibility through changed integration. |
| [C46 Epistemic Cultivation](../../concepts/C46-Epistemic-Cultivation.md) | Con-text-through-Diaphaneity and Resolution-in-Reconciliation: show what the next inquiry can do differently, not merely what it now records. |
| [C47 Deferential Intelligence](../../concepts/C47-Deferential-Intelligence.md) | The same two generated relations: distinguish correction at the answer, task, world-model, evaluator and commission. |
| [C56 Compassion](../../concepts/C56-Compassion-Sensitivity-to-Origins.md) | The same two generated relations: make return non-devouring, including the other's power to refuse or withhold. |

C27, C28 and C29 distinguish criterion immunity, received standing and derivative execution. Their distinct Symbol/Account/Trust, Fides and Economy relations remain in their own fields.

Each consumer must state the operation it takes. A bare term-link to *Hybris* or *Regard* does not satisfy the field contract.

## Relational form growth

The field is the canonical worked example of `N / N′ → N+N′`: here `6 / 6′` generates six earned relations. The result is **not twelve merged nouns**, a compromise between lists, or arithmetic addition. Its fullness comes from articulation and recursive return: generated relations can become seeds for later arguments, and those arguments return new discriminations to this field without changing the historical warrant of its words.

At the encompassing scale, `6 : (6+6′) : 6′` can be read as `0 : / : 1`: two complete faces and their articulated relation become one named Symbolon. This compression is earned only while all lower determinations remain recoverable. `3:3` makes conjugate traversal legible; `4:2` makes the complete six-body legible. Neither is an arithmetic identity with a growth mode. Distributive `6×6` would require a complete local sixfold at every parent position; none is manufactured here.

## Movement and historical return

The exact Movement routes retain their separate publication offices. [M03](../../../../section-rooms/00-integral-threshold/movements/03-s01-p2-definition-cut-gift-danger.md) receives productive distinction before source-usurpation; [M05](../../../../section-rooms/00-integral-threshold/movements/05-s01-p4-gebser-diaphaneity.md) and [M35](../../../../section-rooms/05-psychoid-flowering/movements/35-s4-p4-gebser-apollo-dionysus.md) receive perspective's disclosure of its conditions. [M23](../../../../section-rooms/03-two-logics/movements/23-s2-p4-complex-dynamism.md) receives the difference between a stable basin and a transformed regime, while [M32](../../../../section-rooms/05-psychoid-flowering/movements/32-s4-p1-jung-individuation.md) receives native `X/x` before the psychic refraction. [M40](../../../../section-rooms/06-objective-internality/movements/40-s5-p3-preference-hidden-zero.md) receives the finite evaluator's hidden conditioning, distinguished from metaphysical Zero and from trust. [M42](../../../../section-rooms/06-objective-internality/movements/42-s5-p5-research-vectors.md) receives an Offered gauge/return experiment; [M43](../../../../section-rooms/07-instrument-returns/movements/43-s50-p0-theory-vocation-compassion.md) receives the loving manner of return; [M46](../../../../section-rooms/07-instrument-returns/movements/46-s50-p3-4-2-mono-poly.md) receives contestable local rule and common consequence without an infallible master reference field. Each Movement receives the relation at its own scale: the field keeps the generated operation recoverable through those differences.

The [historical branches](HISTORICAL-BRANCHES.md) keep the arbiter's witness/decision field, Greek crisis and excess, French/English regard, distinct remembrance traditions and the exact Fides bridge available. They also route institutional questions to the existing historical wholes. A source question returns with a concrete object: the witness admitted, the criterion selected, the jurisdiction exercised, the consequence borne, or the document through which the account changed.

[Avatar · image · mask · idol](../../../mytheme/worlds/frank-taylor/avatar-image-mask-idol/WHOLE.md) **figures** all six generated relations at register 3. Continuity-in-Indeterminacy retains what presentation cannot finish; Criterion-through-Distinction makes its measure available; Delineation-through-Difference locates the frame; Arbitration-in-Crisis brings a consequential decision; Con-text-through-Diaphaneity receives the other and the conditions of framing; Resolution-in-Reconciliation returns the settlement with its history. Regard and anamnesis flower through these distinct relations, allowing correction, refusal or withdrawal to change the next use of the form.

## Returns through the developed consumers

[A15-Ratio-Rationality-Measure-Reckoning-Harmony-Account](../../arguments/A15-Ratio-Rationality-Measure-Reckoning-Harmony-Account.md) **extends** Criterion-through-Distinction at evidence register 3. Criterion-through-Distinction makes finite comparison exact and keeps its jurisdiction visible; sum, division of terms and ratio remain separate acts.

[A25-Covenant-Mediating-Office-Source-Authority](../../arguments/A25-Covenant-Mediating-Office-Source-Authority.md) **extends** Arbitration-in-Crisis at evidence register 3. Arbitration-in-Crisis gives a mediator real power to settle while returned labour and consequence can revise the received commission.

[C14-Maya-Operative-Measure](../../concepts/C14-Maya-Operative-Measure.md) **extends** Criterion-through-Distinction at evidence register 3. Criterion-through-Distinction compares finite horizon formation with productive measure; recognition retains bounded capacity and its source-relation without deriving Śaiva terms from this field.

## Return

```text
whole lexical/historical field
        ↓
conjugate generated relations
        ↓
A24 and distributed A/C consumers
        ↓
operational consequences: measure / frame / decision / regard / return
        ↺
new questions returned to HISTORY / source restoration
```

**Depth Restoration:** philological and historical branches remain pending wherever `HISTORY.md` has not yet been source-verified at passage level. The relational field itself is materially current for T09.

At operational register 3, Taylor's world-parent reading gives Criterion-through-Distinction and Delineation-through-Difference a mythemic body: an oriented field makes measure and jurisdiction possible. Con-text-through-Diaphaneity returns that measure to its conditions; the story's source sequence remains recoverable in its own whole. The relation **returns-to** [the complete Neumann whole](../../../mytheme/archetypal-ground/neumann-images/WHOLE.md#neumann-world-parent-separation). The serpent's settlement returns through Arbitration-in-Crisis, Con-text-through-Diaphaneity and Resolution-in-Reconciliation at operational register 3; receiving must be able to change the deciding office. This **returns-to** [the uroboros whole](../../../mytheme/archetypal-ground/uroboros-trickster/WHOLE.md#uroboros-return).

[the Job whole](../../../mytheme/worlds/biblical/job/WHOLE.md#job-measure-trust-return) **figures** Arbitration-in-Crisis through Job's demand that judgement hear the particulars of his life. Con-text-through-Diaphaneity receives the whirlwind's change of the field of judgement; Resolution-in-Reconciliation receives the rebuke of the friends and their dependence on Job's intercession. Regard and anamnesis carry renewed attention and return within this complete operation. This is an authored relation at evidence register 3: neither the biblical text nor its vocabulary is being credited with the etymology field's generated construction.

At evidence register 3, [the Prisoner whole](../../../mytheme/worlds/british-television/the-prisoner/WHOLE.md#prisoner-account-answerability) **figures** Arbitration-in-Crisis when Six contests the Village's right to supply the meaning of his answer. Con-text-through-Diaphaneity receives the election's disclosure that occupying an office does not change its governing field. Resolution-in-Reconciliation remains tested by the escape and the return home: an exit has occurred, but no final sovereign settlement is earned. Regard and anamnesis must therefore reopen the relation rather than ratify a new throne. These are generated authorial operations, not an etymology attributed to the screenplay.

The [Latin arbitration witness](../../sources/classical-philology/lewis-short/lewis-short-1879-latin-dictionary/SOURCE.md#lewis-short-1879-latin-dictionary-q004), [Greek decision and excess senses](../../sources/classical-philology/liddell-scott-jones/lsj-1940-greek-english-lexicon/SOURCE.md#lsj-1940-greek-english-lexicon-q004), and [French regard history](../../sources/language-literary-studies/atilf/atilf-tlfi-regard/SOURCE.md#atilf-tlfi-regard-q001) **source** the lexical branches. The exact *fidem alicui arbitrari* dictionary witness now carries its Plautus locator; a full primary dramatic collation remains separate from this recovered lexical evidence.

The [meal epistemic metabolism whole](../../../mytheme/worlds/frank-taylor/meal-epistemic-metabolism/WHOLE.md#meal-logos-health-return) **figures** Con-text-through-Diaphaneity through the table whose preparation, sustaining conditions and participants become available within the account; Regard flowers as renewed attention to those relations. Resolution-in-Reconciliation receives satiety through the history of what has been assimilated; Anamnesis, Recognition and Return let the next question begin from that changed ground. This is a register-3 authored return, preserving the difference between the generated relations and their semantic flowerings.

The [mirror that moves first whole](../../../mytheme/worlds/frank-taylor/mirror-that-moves-first/WHOLE.md#mirror-return) **figures** Arbitration-in-Crisis when the person’s resistance reaches the image’s governing measure. Con-text-through-Diaphaneity discloses how that measure was formed and lets Regard receive the affected world. Resolution-in-Reconciliation resituates the account through its history so Anamnesis, Recognition and Return can change the next act. These are register-3 appointments within Taylor’s three motions, not lexical evidence for an AI mechanism.
