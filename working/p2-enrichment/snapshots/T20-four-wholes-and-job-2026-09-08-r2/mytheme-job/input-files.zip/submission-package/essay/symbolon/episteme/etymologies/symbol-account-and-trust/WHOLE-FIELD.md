# Whole Field — Symbol / Account / Trust

**Standing:** mature T09 Etymology whole-field. `HISTORY.md` preserves the historical symbol/account/trust material; this page states the canonical relational office consumed throughout A01–A36 and C01–C64.

## The relation

A **Symbol** is a determinate form that discloses a relation beyond what the form exhausts. An **Account** is the articulated reckoning/report by which that disclosure becomes answerable and transmissible. **Trust** is the committed reliance by which an account can guide action without being confused with possession of its source.

The field is not a common-descent claim. Historical senses of *symbol*, *account* and *trust* remain individually warranted. Canonically, their growth is operational:

```text
source / relation
        ↓
Symbol — determinate disclosure
        ↓
Account — articulated, inspectable relation
        ↓
Trust — committed use under non-possession
        ↓
encounter / consequence / revision
        ↺
Symbol and Account transformed
```

## Canonical operations

### Symbol answers to source

Consumed by **A01 Faithful Definition**, **A18 Primordial Symbolon**, **A20 Image/Valuation**, **C21 Living Symbol/Idol**, **C22 Counterfeit Symbolon**. A form becomes idolatrous when its source-relation is replaced by source-occupation.

### Account does not replace source

Consumed by **A15 Ratio/Rationality**, **A22 World-Atlas**, **A27 Self/Other**, **A33 Operational Parity**, **C39 MEF**, **C40 Model Internality**. The model or account can be exact and consequential without becoming the world.

### Trust keeps the return route active

Consumed by **A23 Trust/Faith**, **A25 Covenant**, **A31 Deferential Intelligence**, **C48 Trust/Faith**. Trust is strongest where grounds and revision conditions are explicit; it degenerates where the account becomes protected against the source that could revise it.

### Account re-enters source-field

Consumed by **A32 Reflective Field / Mirror That Moves First** and **C55 Reflective Field**. Once an account changes attention, action or infrastructure, later source conditions may themselves include effects of the prior account. This does not erase `world ≠ world-model`; it makes their causal relation recursive.

## Evidence registers

**1–2:** historical lexical descent and attested semantic fields remain in `HISTORY.md` and supporting source pages.

**3:** the Symbol → Account → Trust → Return relational circuit is Operational Homology / authorial relational construction.

**4:** any graphic or phonic return around *symbolon*, *account*, zero or other marks is explicitly poetic/authorial unless separately historically warranted.

## Relation to Primordial Symbolon

A18 is the substantive Argument and the eightfold traversal. C61 is routing architecture. This Etymology field neither replaces A18 nor proves it. It supplies the lexical/operational reasoning office by which historical symbol-language, accountable representation and trust can be consumed without office-collapse.

**Depth Restoration:** historical branches remain pending where detailed source verification has not yet been completed; T09 relational routing is current.

### Whole-mytheme returns

At evidence register 3, [the whole Ares–Aphrodite relation](submission-package/essay/symbolon/mytheme/worlds/hellenic/ares-aphrodite-hephaestus-poseidon/WHOLE.md#ares-guarantee-release) **figures** the difference between an account of capture and the undertaking which makes release possible; [A23](../../arguments/A23-Trust-Faith-and-the-Formal-Limit.md) and [A25](../../arguments/A25-Covenant-Mediating-Office-Source-Authority.md) return its named bearer of liability. [the complete Apollo–Eros–Daphne–Peneus whole](submission-package/essay/symbolon/mytheme/worlds/roman-latin/apollo-eros-daphne-peneus/WHOLE.md#apollo-appropriation-after-withdrawal) **figures** a different consequence: an emblem can remain culturally effective after the failed encounter, so [A20](../../arguments/A20-Image-Valuation-Possession.md) returns efficacy to source-answerability. [the Eros–Psyche whole](submission-package/essay/symbolon/mytheme/worlds/roman-latin/eros-psyche/WHOLE.md#psyche-native-return) **figures** disclosure and injury followed by a changed continuation; its legal ending qualifies any attribution of the author’s non-possession philosophy to Apuleius. These returns retain the three-term field and its four operations. Each source tells its own sequence; no shared lexical descent follows from the comparison.
