---
title: Encounter / Region / Name / Count / Countenance / Account
record_id: etymology-encounter-region-name-count
record_type: etymology-whole
register: episteme
claim_status: Argued
source_relation: Argued from
source_ids: [taylor-2026-encounter-region-name-count, taylor-2026-core-theorems-pithy, taylor-2026-symbolon-dynamics]
---
# Whole Field — Encounter / Region / Name / Count / Countenance / Account

**Standing:** mature six-term field, developed through four generated operations. The established directory retains its provenance. [HISTORY.md](HISTORY.md) **sources** the inherited historical and relational branches; [the historical companion](HISTORICAL-BRANCHES.md) **qualifies** their independently checked witnesses and remaining acquisition tasks. Historical descent, attested use, authorial operation and poetic re-entry retain separate warrants.

## #0 — Encounter before its completed account

<a id="what-holds-the-field-together"></a>
An encounter gives an account something to answer to. What arrives is already situated, yet the descriptions, names and measures available here do not decide everything it can disclose. A person can answer a question by changing what the question asks. A source can correct the category under which it was retrieved. A consequence can expose a condition omitted from the decision that produced it. Encounter names this relation before its possible reduction to the report of what happened.

The priority is operative, not a claim that people first met without language and only later invented it. An inherited name can make the meeting possible. Its use nevertheless takes place within a relation which can exceed and revise that use. [Taylor's encounter synthesis](../../sources/internal-corpus/taylor/taylor-2026-encounter-region-name-count/SOURCE.md) **grounds** the whole-field proposition: the with-relation is prior to treating its opposed terms as independently complete. Opposition remains real; it takes place within the facing relation it articulates.

The historical lines make this priority exact by resisting a false single ancestry. *Encounter* comes through forms of meeting toward or against; numerical *count* through reckoning; *countenance* through holding and bearing; titled *count* through companionship and office. Their convergence is a work performed by this field. The [four distinct histories](HISTORICAL-BRANCHES.md#four-con-histories) **source** the lexical differences which the authorial construction must retain. Neither hostility nor companionship supplies the essence of every meeting. Both show that being against and going with already require a relation.

The six terms therefore grow as Encounter → Region → Name → Count ↔ Countenance → Account → Encounter. The return arrow is as necessary as the forward ones. A report becomes an inherited condition of another meeting: it directs attention, grants credibility, authorises action or forecloses a possibility. If its effects cannot reach back into its terms, an account of encounter becomes a means of preventing encounter.

<a id="canonical-operations"></a>
The four generated operations are **Encounter-in-Region**, **Name-through-Count**, **Count-through-Countenance**, and **Count-to-Account**. They are relational form growth at evidence register 3. They neither add four new primitive terms nor assert that the six words developed historically in this order.

## #1 — Region makes the meeting consequential

### Encounter-in-Region

A relation is situated before it is abstracted. Region holds the conditions through which this person, mark or event can appear as something and admit a response. Language, memory, bodily capacities, material arrangements and permissions are active in the meeting. Removing a permission changes which act is possible; changing a remembered source changes what can count as warranted. These conditions are not scenery placed around an otherwise finished encounter.

[Conditions of Worldhood](../../concepts/C07-Conditions-of-Worldhood.md) **defines** that constituting office. [Context / Context Frame](../../concepts/C08-Context-Context-Frame.md) **qualifies** its bounded investigation: a frame temporarily holds conditions together, while what it excludes can still affect the act. A frame is useful because it lets an inquiry proceed and its conditions become readable. Its finite inventory does not exhaust the region in which it works.

The region branch forks between a directed line and a facing expanse. The Latin *regio/regere* history supports direction and delineation; the *country/contra* history retains what lies opposite. Taylor's reading of *Gegend/Gegnet* asks after an openness which lets things gather and abide. [The region companion](HISTORICAL-BRANCHES.md#region-direction-and-open-expanse) **qualifies** that reception: the philosophical Country Path passage requires its own collation, and the proposed German calque history requires lexical evidence. The operative claim survives those distinct tasks. Rule is one office within a relation; an account of the rule cannot substitute for the field it orders.

[A22 — World-Picture to World-Atlas](../../arguments/A22-World-Picture-to-World-Atlas.md) **extends** this consequence into representation. Different maps can disclose different relations, and an obstruction to translation can be a finding. The return must identify which source, object, lens, gauge or permission changed rather than resolve every disagreement into a common picture. [A26 — Objective Internality](../../arguments/A26-Objective-Internality-Mind-as-Worldhood.md) **grounds** the stronger reversal: the notational, nomological and exclusion-constituted world participates in producing the agent who models it. [C41](../../concepts/C41-Objective-Internality.md) **defines** the inspectable interior without reducing it to a device boundary or mistaking functional agency for a finding of phenomenality.

The region also has a history. A saved judgment enters what a later participant inherits, while that participant's action can change the available field. [A30 — Objective Co-Internality](../../arguments/A30-Objective-Co-Internality.md) **extends** the relation across independently grounded worlds. [C42](../../concepts/C42-Objective-Co-Internality.md) **defines** the differences among revising a local map, changing a relation between maps and changing the rule of circulation. [Agentworld](../../concepts/C57-Agentworld.md) **tests** durable inheritance: exchanged messages become stronger evidence of world-constitution where a returned record or permission alters what can next be done. Shared containment alone does not establish reciprocal authority.

## #2 — Name becomes addressable through distinction

### Name-through-Count

A name reaches something through an achieved distinction. Two people can bear one name; repeating the word does not individuate its bearers. One person can be addressed under different descriptions; multiplying descriptions does not automatically multiply persons. Count here includes the prior discrimination which makes a bearer available as this one. Naming makes that distinction portable and repeatable, while the region retains the circumstances in which it was made.

[A15 — Ratio, Reckoning and Account](../../arguments/A15-Ratio-Rationality-Measure-Reckoning-Harmony-Account.md) **grounds** this pre-nominal counting operation. It is Taylor's authorial development from the problem of name, instance and circumstance. It does not depend on a common root for *nomen* and *numerus*, and it is not a doctrine attributed wholesale to Kripke. [Determination](../../concepts/C03-Determination.md) **defines** the positive act: a distinction lets something recur as another instance while retaining the capacity and circumstances by which it is recognised.

Selection also gives the name a field of non-application. [A08 — Apoha](../../arguments/A08-Apoha-Constitutive-Exclusion.md) **qualifies** the semantic comparison through the exclusion constituting a referent. [C18 — Apoha](../../concepts/C18-Apoha.md) **sources** its exact boundary: a thing qualified by preclusion differs from mere preclusion, and nominally bound exclusion differs from denying a proposition. The field's whole-first claim does not become a Buddhist historical attribution. What E1 receives is the precise demand to retain the materially relevant exclusion through which a positive term applies.

[Vikalpa–Saṃkalpa](../../concepts/C17-Vikalpa-Samkalpa.md) **extends** the movement from differentiated alternatives into a gathered course. A selection narrows the field and makes action possible. Its account must retain enough of the alternatives to explain why this course was formed and how it can be reconsidered. Storing every imaginable alternative is neither required nor possible; retaining a consequential excluded condition is a definite obligation.

[A10 — Advent of Zero](../../arguments/A10-Advent-of-Zero.md) **tests** another transformation of addressability. A place-mark, an arithmetic operand and a boundary expression have different offices. Giving an empty position a sign does not settle every operation in which zero appears. The admission of a mark changes what can be reckoned, but the account must say which operation changed. E1 receives that distinction rather than deriving a history of mathematics from a word's sound.

The Chinese branch gives naming an adjacent limit. Laozi 25 names an otherwise unnamed way and places the ruler among four greats; 32 joins the arrival of names to a capacity to stop; 28 places formed vessels and offices beside a return to the unworked. [The selected textual witnesses](HISTORICAL-BRANCHES.md#chinese-facing-and-non-severing-return) **compare** these distinct acts. Their relation here is naming which retains its source and limit, not an ancient derivation of QL's count.

## #3 — Count makes a relation repeatable

Counting makes a difference usable across instances. It requires a unit or criterion, a field in which the unit applies, and a way of retaining what the result means. The same people can be counted by attendance, entitlement or affected consequence and yield different accounts. The arithmetic can be correct in each case while a conclusion transfers the result illegitimately from one criterion to another. Exactness therefore includes the relation counted, not only the numeral obtained.

The inherited history preserves six ways of reckoning: fitting into an order; straightening or ruling by a measure; pruning and selecting together; telling a succession; gathering and laying out; declaring together in enumeration. [The six counting branches](HISTORICAL-BRANCHES.md#six-ways-of-counting) **qualify** their separate linguistic standing. They are six recovered research routes, not six universal headings imposed on all counting. Their operational differences matter: ordering establishes comparability, pruning selects, telling retains sequence, and gathering gives the result a relation to what it gathers.

The distinction between a present field and its actual passage is developed in [Taylor's Symbolon Dynamics](../../sources/internal-corpus/taylor/taylor-2026-symbolon-dynamics/SOURCE.md), which **grounds** the configuration/trajectory relation. A census of present positions cannot replace the history of how those positions became operative. Equally, a narrative of arrival does not specify every current transition. An account needs the relevant two temporalities where the history has changed what is now possible.

[Dia-Ballein, Movement 20](../../../../section-rooms/03-two-logics/movements/20-s2-p1-dia-ballein.md) **defines** the productive analytic cut and its failure when the common operation disappears. E1 returns its count with the criterion and excluded alternative still recoverable. [Sym-Ballein, Movement 21](../../../../section-rooms/03-two-logics/movements/21-s2-p2-sym-ballein.md) **extends** the combine-phase: the achieved branch carries the problem it answered and the wider state it changes. Retaining a seam lets a result become answerable; fusion would remove the differences that recomposition must hold.

[Heidegger's Memorial Address](../../sources/phenomenology-continental-philosophy/heidegger/heidegger-1966-discourse-on-thinking/SOURCE.md) **compares** calculative and meditative thinking, both explicitly legitimate in their own offices. [His Logos essay](../../sources/phenomenology-continental-philosophy/heidegger/heidegger-1975-early-greek-thinking/SOURCE.md) **compares** gathering as letting what is gathered lie together. The connection to counting's return is Taylor's Argued construction. These philosophical readings do not certify the six lexical branches, and the Memorial Address does not stand in for the separate Country Path dialogue.

## #4 — Countenance lets the counted answer

### Count-through-Countenance

Countenance returns the counted participant as address, face and bearing. The person described can answer the description from a situation which it has not enclosed. This is an operation within a shared field: the other does not have to become another world outside reality in order to exceed my account. [A27 — Self and Other](../../arguments/A27-Self-and-Other-Unity-without-Possession.md) **grounds** the distinction between being within Mono and being within my model. Common reality enables encounter while conferring no possession of the other.

The historical *continentia* line concerns holding and bearing; *facies* and *prosōpon* open separately sourced questions of formed appearance, face, presence and role. [The countenance branch](HISTORICAL-BRANCHES.md#countenance-bearing-face-and-role) **qualifies** their different histories. Their juxtaposition makes the philosophical pressure visible: an appearance can disclose someone without becoming the whole of that person's address. The title or mask under which someone is recognisable can organise a real meeting and still prevent their response from reaching the terms of recognition.

The native `AM/IS` relation carries this operation through first-person presence, third-person sayability and the second-person slash through which they meet. A statement about someone can be exact; the one addressed can nevertheless change its use or expose what it omits. This is Taylor's native QL language. Levinas, the Watson–Gans reception and the lexical history of person remain independent philosophical and historical routes, not sources of that notation.

[A31 — Deferential Intelligence](../../arguments/A31-Deferential-Intelligence.md) **extends** address into model-revising encounter. An objection can change the answer, task, world-model, evaluator or commission; those are different scopes of revision. [C47](../../concepts/C47-Deferential-Intelligence.md) **defines** the offered contrast between choosing a better output under a fixed evaluation and changing the representation or evaluator itself. Its formal inscription is a design proposal, not a borrowed machine-learning theorem or an experiment already performed. Deference remains discriminating: an unsupported objection can be rejected with reasons, while an established correction must be able to reach its actual cause.

[Anthropomorphization](../../concepts/C58-Anthropomorphization.md) **qualifies** the extension to artificial agents. A recognisable voice, retained memory and changed conduct establish different things. None alone settles phenomenal subjectivity; unfamiliar substrate supplies no contrary proof. Countenance here keeps the attribution revisable through encounter and evidence. It grants neither a human essence on sight nor a prior exemption from accounting for actual powers and effects.

Count ↔ Countenance is therefore reciprocal. Counting permits someone to enter an account as a distinct participant; address tests whether the criterion has counted what matters. Revising the criterion does not abolish number. It restores the field of relation in which a count can be right and its application answerable.

## #5→0 — Account returns its conditions to encounter

### Count-to-Account

Reckoning becomes an account when its criterion, provenance and consequence become available for challenge and revision. The history genuinely connects numerical *count* and *account*; the passage from a tally to ethical answerability is a further authorial operation. A fluent explanation can still conceal which source, exclusion or permission actually caused a result. An account must preserve those distinctions if it is to return to their causes.

[MEF](../../concepts/C39-Meta-Epistemic-Framework.md) **defines** the lens and gauge discipline: different perspectives change questions, evidence or judgments while retaining their warrants. [Model Internality / Judgment Field](../../concepts/C40-Model-Internality-Judgment-Field.md) **defines** the inspectable production of a determination. A source correction, an altered gauge and a revoked permission act at different sites. Relative scores, a distribution and a selected output likewise preserve different information; the apoha comparison does not make those operations one Buddhist doctrine. Etymology provides their Account relation at register 3, not evidence that a system implements it.

[A33 — Operational Parity](../../arguments/A33-Epistemic-Cultivation-Operational-Parity.md) **tests** the promotion to implementation. If a distinction is claimed as a functioning feature, a relevant comparison must discriminate its consequence. [C45](../../concepts/C45-Operational-Parity.md) **qualifies** the result: a failed comparison returns to the implementation, mapping or test, with those failures distinguished. No test reported here has been run. The Argued relation of account and answerability remains precise while the technical proposal retains its own empirical task.

<a id="native-field-return"></a>
The complete native field prevents this return from being read as a new name for unqualified inclusion. [The core theorem spine](../../sources/internal-corpus/taylor/taylor-2026-core-theorems-pithy/SOURCE.md) **grounds** parent `/ = −/−`; conscious circumstance `0/1`; question/assertion `?/!`; withdrawal/extension `−/+`; recurrence `X/x`; personed context `AM/IS`; unbounded/local exactness `∞/dx`; inverse return `1/0`. [Movement 25](../../../../section-rooms/04-mathematical-substrate/movements/25-s3-p0-eight-determinations.md) **defines** their complete ordering. The six terms developed on this page do not rename those determinations one by one. Naming works through answerable determination; counting involves recurrence; countenance makes context personed; account exposes its differential horizon. Each office implicates the whole relation.

The inherited history's naming/gathering inversion is active here. The name selects from the region; the account gathers the selected distinction back with the relation it could not contain. Recognition changes the next beginning without cancelling the achieved distinction. [Movement 47](../../../../section-rooms/07-instrument-returns/movements/47-s50-p4-idealism-horizon.md) **qualifies** the last promotion: even an exhaustive inspectable account of a model would not make that model the metaphysical Original. Epistemic source, appearing condition and ultimate dependence keep their own registers.

<a id="evidence-registers"></a>
### Evidence registers

**1 — Documented descent and morphology** supports particular lexical or graphic lines. **2 — Attested senses and historical uses** supports what a word or text does in a specified witness. **3 — Operational homology and relational construction** carries all four generated operations and the native/consumer returns. **4 — Poetic, phonic or morphological re-entry** carries explicit returns such as the sounding proximity of count/countenance and the proposed 域/遇 encounter. Register 4 can reopen attention; it cannot retroactively establish descent. Register 1 can establish a connection; it cannot establish the ethical or technical consequence by itself.

<a id="return"></a>
### Return

An account enters the next encounter with the authority it has earned and the conditions under which it earned it. If a source changes, the corresponding conclusion must be available for revision; if someone contests their classification, the criterion must be reachable; if a consequence exposes an omitted relation, the field must admit it as a condition of the next act. Account is complete locally through this capacity to return, not through an assertion that nothing remains outside it.

At evidence register 3, [the Prisoner whole](../../../mytheme/worlds/british-television/the-prisoner/WHOLE.md#prisoner-account-answerability) **figures** the Encounter–Region–Name–Count–Countenance–Account circuit through a captured arrival into a world whose names and counts are already operative. Number Six is publicly recognisable within that region, yet recognition can make his reply into the administration's account of him. The opening source-question and the election test whether Count-to-Account can return to an encounter able to change the region's terms. The operation keeps all six terms distinct and asserts no shared lexical ancestry with the programme's language.

**Depth Restoration:** the six-term circuit, four exact generated operations, four distinct con-histories, region fork, six counting routes, countenance/personed address, Chinese branch and complete native return are developed. Historical and experimental debts remain specified in the companion; they do not dilute the Argued field. Reciprocal consumer integration retains its separate owners.

The [meal epistemic metabolism whole](../../../mytheme/worlds/frank-taylor/meal-epistemic-metabolism/WHOLE.md#meal-shared-table) **figures** all four operations at register 3. Encounter-in-Region situates the shared table; Name-through-Count makes participants and portions addressable; Count-through-Countenance receives the counted guest as someone who can challenge the reckoning; Count-to-Account exposes preparation, allocation and consequence. The revised account returns to another encounter with those companions still able to contest its terms.

The [travelling jigsaw atlas whole](../../../mytheme/worlds/frank-taylor/travelling-jigsaw-atlas/WHOLE.md#jigsaw-blue-marble-hinge) **figures** the planetary hinge through all four register-3 relations. Encounter-in-Region situates the view; Name-through-Count discloses its selected units and exclusions; Count-through-Countenance lets the addressed participant answer that scale; Count-to-Account exposes the criterion, provenance and effects. The changed Account returns as another situated encounter whose local participants retain their authority to question it.
