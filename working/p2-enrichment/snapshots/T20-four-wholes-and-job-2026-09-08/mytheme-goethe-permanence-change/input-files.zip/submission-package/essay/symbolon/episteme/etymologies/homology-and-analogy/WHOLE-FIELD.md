# Whole Field — Homologia / Analogia

**Standing:** mature T09 Etymology whole-field. `HISTORY.md` remains the historical/philological carrier; this page governs how agreement, correspondence and proportion may be used across the essay's distinct registers.

## Why this field exists

The essay moves among mathematics, Śaiva metaphysics, Jungian psychology, language, topology, music and technical computation. Without a disciplined relational vocabulary, similarity quickly becomes false identity. **Homologia / Analogia** provides the grammar by which forms can answer to one another while remaining source-distinct.

Historical Greek meanings and morphology belong to evidence registers **1–2** where documented in `HISTORY.md`. Canonical cross-register use is normally **3 Operational homology**.

## Operations

### Homological agreement

Two fields are homological when a materially relevant **operation or relational structure** can be shown to correspond while each field retains its own object and evidence. A visual resemblance is insufficient. The comparison must state what is transformed, preserved, generated or returned in both cases.

Consumers include **A02 Copula**, **A12 Mono/Poly**, **A13 Dia/Syn**, **C06 Copula**, **C36 Complexio Oppositorum**, **C50 Dia/Syn**.

### Analogical proportion

Analogy relates different terms through a proportion, focal orientation or qualified respect without asserting univocal sameness. It is the natural Etymology office for **C63 Pros Hen / In Quantum**, where Aristotle and Eckhart remain source-distinct even though both can discipline cross-register predication.

Consumers include **A34 Idealism**, **A36 Integral Zero**, **C60 Idealism**, **C63 Pros Hen / In Quantum**, **C64 Paradox**.

### Research boundary

**C30 Psychoid Number** depends upon this field as a guardrail. Numerical, geometric or archetypal correspondences may be philosophically fertile while remaining only operational analogy until independent evidence raises their standing. Cross-domain recurrence is never a covert proof of common cause or common descent.

## Evidence law

```text
same operation across fields
≠ common historical descent
≠ doctrinal identity
≠ causal proof
```

A relation may remain important at register **3** without being demoted. The discipline is not sceptical reduction; it protects the relation from claiming a kind of warrant it has not earned.

## Relational growth

Homologia and Analogia themselves can generate new distinctions. When a comparison reveals both correspondence and irreducible difference, the achieved relation becomes a **seed/new participant** for another inquiry. This is Relational Form Growth rather than forced synthesis.

**Depth Restoration:** exact Greek lexical/source histories and tradition-specific uses remain pending where `HISTORY.md` is not passage-complete. T09 operational discipline is current.

The full eightfold Neumann refraction is an operational crossing at register 3. Its source morphology, native derivation, geographical tellings and temporal histories retain different offices; the whole returns the exact operation by which they become comparable. The relation **returns-to** [the complete Neumann whole](submission-package/essay/symbolon/mytheme/archetypal-ground/neumann-images/WHOLE.md#neumann-paper-eightfold). The mathematical lift, digestive image and psychic return preserve retained difference at operational register 3, with their counted objects and source warrants kept exact. This **returns-to** [the uroboros whole](submission-package/essay/symbolon/mytheme/archetypal-ground/uroboros-trickster/WHOLE.md#uroboros-interposition).

### A whole that can qualify its comparison

The retained-difference operation **returns-to** [the Eros–Psyche whole](submission-package/essay/symbolon/mytheme/worlds/roman-latin/eros-psyche/WHOLE.md#psyche-native-return). The four labours have their own helpers and nested return; waking uses an arrow-prick; the pregnancy precedes the ordeals; the public marriage uses a possession idiom. [A13](../../arguments/A13-Two-Logics-of-Two-Dia-Syn.md) and [A27](../../arguments/A27-Self-and-Other-Unity-without-Possession.md) receive the author’s union-without-merger relation with those source differences active. Register 3 establishes the particular operational comparison; it cannot turn four narrated tasks into proof of the native two-plus-four derivation or historical identity between traditions.
