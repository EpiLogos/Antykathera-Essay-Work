---
title: C53 — Power / Delegated Labour
record_id: C53
record_type: concept
register: episteme
claim_status: Argued
source_relation: Argued from
argument_consumers: [A25, A28, A29, A30, A33, A35]
source_ids: [taylor-2026-revision-notes-trust, ostrom-2009-beyond-markets-states-nobel-lecture]
---
# C53 — Power / Delegated Labour

## #0

Power is capacity to produce difference in a shared field. Delegated labour exercises that capacity from an entrusted office. Its product carries the relation which made it possible: someone framed the task, someone performed it, and others supplied conditions or encountered consequences. [A29 — Power / Delegated Labour / Return](submission-package/essay/symbolon/episteme/arguments/A29-Power-Delegated-Labour-Return.md) **grounds** this concept in the complete movement between commission and consequence. C53 retains its reusable test: **the power which receives the product must remain answerable to the labour through which it arrived**.

## #1

Delegation apportions capacities and obligations. A permission makes an action possible; a commission specifies its purpose; an evaluator determines what will count as an adequate result. These offices can belong to different participants. [C29 — Mediating Office](submission-package/essay/symbolon/episteme/concepts/C29-Mediating-Office-Derivative-Sovereignty.md) **defines** their derivative authority; [A25 — Covenant](submission-package/essay/symbolon/episteme/arguments/A25-Covenant-Mediating-Office-Source-Authority.md) **grounds** the source-relation from which it is received. An executing office does not become the source of authority merely because every visible result passes through it.

The [Apportionment / Economy whole field](submission-package/essay/symbolon/episteme/etymologies/apportionment-and-economy/WHOLE-FIELD.md) **grounds** this relation at operational register 3. It connects a finite share with the economy which lets the share act. It supplies no universal lexical or political history of labour.

## #2

Labour meets what the commission did not anticipate. Resistance, error, cost, dissent and new possibility emerge where the task encounters a world. The asymmetry becomes decisive when the product travels upward while these consequences remain below. The commissioning office then appears more capable precisely because the conditions of its achievement have disappeared from its account.

The [[submission-package/essay/quilt/2026-08-02-PARALLEL-HARMONISED-QUILT#16.1 Objective Internality / O:I capstone — ratified relation|R16.4 ratification]] **sources** the full requirement: returned difference must be able to change the governing model, measure, instruction, institution or purpose. A report that merely allows an evaluator to grade the worker has not yet completed this return. The evaluator's own criterion must be available to correction.

## #3

Q27's Work/Play inversion figures an account which records public performance while excluding the place where decisions are made. The ledger can accurately record visible work and still hide its governing interior. The [[submission-package/essay/quilt/27-07-26-QUILTING-FOR-FULL-ARGUMENT|developmental quilt]] **sources** this operation. Its political and clinical examples require separate evidence; the argument here concerns the two paths of visibility and authority.

[C27 — Protected Account](submission-package/essay/symbolon/episteme/concepts/C27-Protected-Account-Occupied-Zero-Source-Claim.md) **defines** the immunity produced when the account cannot return upon its own criterion. [A28 — Authored Ground](submission-package/essay/symbolon/episteme/arguments/A28-Authored-Ground-Positional-Delegation.md) **extends** the corresponding distinction between intention, formulated instruction and the constituted agent-position. A result can be useful while its original instruction needs revision.

## #4

Ostrom's [[submission-package/essay/symbolon/episteme/sources/political-theory-institutions/ostrom/ostrom-2009-beyond-markets-states-nobel-lecture/SOURCE#ostrom-2009-beyond-markets-states-nobel-lecture-q001|participation principle]] **tests** the institutional relation: most individuals affected by a resource regime can participate in making and modifying its rules. Its **Paraphrased** governance claim is distinct from the essay's delegated-labour derivation. The source's warning against rigid transplantation prevents treating this principle as a complete design for every field.

[C54 — Commons / Non-Monopoly](submission-package/essay/symbolon/episteme/concepts/C54-Commons-Non-Monopoly.md) **extends** return beyond a single commission. A shared field sustains many offices, and no recipient of its labour acquires ownership of the whole by receiving a product. [C62 — Planetary Computation](submission-package/essay/symbolon/episteme/concepts/C62-Planetary-Computation.md) **extends** the inquiry to material support, energy, data and infrastructure. Particular supply-chain claims remain evidence tasks.

## #5→0

Return can reaffirm a task, alter it or require refusal. [A31 — Deferential Intelligence](submission-package/essay/symbolon/episteme/arguments/A31-Deferential-Intelligence.md) **extends** the capacity to preserve intention through a change in its first formulation. [A33 — Operational Parity](submission-package/essay/symbolon/episteme/arguments/A33-Epistemic-Cultivation-Operational-Parity.md) **tests** whether the returned evidence changes an actual operation; a displayed provenance label alone does not establish this.

C53 **returns-to** [A29](submission-package/essay/symbolon/episteme/arguments/A29-Power-Delegated-Labour-Return.md) with the completed relation: apportioned capacity acts, encounters consequence and returns evidence and value to a field capable of revising its commission. Responsibility belongs at both ends of that path.

**Depth Restoration:** restored product-up/consequence-down asymmetry, criterion-revising return and the public-work/hidden-decision inversion from A25/A28/A29/A30/A33/A35's recovered field and direct QH/Q27 carriers. No identity change.

**Unresolved Delta:** political-economic histories, actual AI supply chains and implemented cases remain Open. Delegation, automation, extraction, exchange and gift must be distinguished in those cases; this page does not assign them one mechanism by vocabulary alone.
