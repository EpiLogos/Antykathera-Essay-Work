# Independent Wilson edition attribution review

Accepted exact candidate `62abec340459e2e24ae10b4a409f718763316da3041e77c4b461929f76e4475d` after complete original/final SOURCE and diff, fixed-article head/publication/footer and entire dynamic citation/history page. The2020 archive credits Wilson and Foglia; the official generator currently lists all four names and records the Shapiro/Spaulding rewrite in2021. The repair preserves that conflict while restoring edition-specific attribution.

Both selected passage cards and metadata register remain byte-identical. No new whole article, quotation/readiness, receiver-body, historical or runtime acceptance follows. The first mistaken raw-footer location was reopened at actual3490–3518 before acceptance. No native or protected edit.
