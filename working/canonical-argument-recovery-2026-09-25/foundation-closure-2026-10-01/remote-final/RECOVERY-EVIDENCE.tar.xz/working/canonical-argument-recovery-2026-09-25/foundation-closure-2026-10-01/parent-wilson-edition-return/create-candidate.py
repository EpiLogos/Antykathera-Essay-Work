from pathlib import Path
import hashlib,json,difflib,urllib.request
D=Path(__file__).parent; ROOT=Path.cwd(); F=Path('submission-package/essay/symbolon/episteme/sources/analytic-philosophy/wilson/wilson-et-al-2020-embodied-cognition-sep/SOURCE.md')
sha=lambda b:hashlib.sha256(b).hexdigest()
old=(D/'SOURCE-before.md.txt').read_text(); assert sha(F.read_bytes())==sha(old.encode());assert (D/'effects-before.json').exists()
sources=[('official-fixed-archive.html','https://plato.stanford.edu/archives/spr2020/entries/embodied-cognition/'),('official-current-archive-citation.html','https://plato.stanford.edu/cgi-bin/encyclopedia/archinfo.cgi?archive=spr2020&entry=embodied-cognition')]
provenance=[]
for name,url in sources:
    with urllib.request.urlopen(url,timeout=30) as response: data=response.read()
    (D/name).write_bytes(data);provenance.append({'path':str(D/name),'url':url,'sha256':sha(data),'actual_semantic_scope':'Fixed article header and author footer; complete citation metadata and change-history page. Byte-retained HTML is not claimed as a whole article read.'})
new=old.replace('- Lawrence Shapiro\n- Shannon Spaulding\n','').replace('Robert A. Wilson, Lucia Foglia, Lawrence Shapiro, and Shannon Spaulding,','Robert A. Wilson and Lucia Foglia,').replace('Wilson, Robert A., Lucia Foglia, Lawrence Shapiro, and Shannon Spaulding.','Wilson, Robert A., and Lucia Foglia.').replace('**Shortened note:** Wilson et al.,','**Shortened note:** Wilson and Foglia,').replace('Wilson et al. supplies a fixed account','Wilson and Foglia supply a fixed account').replace("Robert A. Wilson et al., ‘Embodied Cognition,’","Robert A. Wilson and Lucia Foglia, ‘Embodied Cognition,’")
addition='''## Edition and author attribution

The fixed Spring 2020 article credits Robert A. Wilson and Lucia Foglia in its author footer. Its content was first published in 2011 and substantively revised in 2015. The encyclopedia’s presently generated [archive citation page](https://plato.stanford.edu/cgi-bin/encyclopedia/archinfo.cgi?archive=spr2020&entry=embodied-cognition) lists four names for this older archive, while its own change history assigns Lawrence Shapiro and Shannon Spaulding to the completely rewritten entry of 25 June 2021. The bibliographic forms above follow the authors of the fixed article actually consulted. The generator’s four-name output is retained as a conflicting metadata carrier in the recovery evidence, rather than attributed to authorship of the 2020 text. This edition distinction changes neither the two selected §2.2 passages nor their existing quotation verification.

'''
new=new.replace('## Essay use\n',addition+'## Essay use\n'); assert old!=new
(D/'SOURCE-candidate.md.txt').write_text(new)
(D/'SOURCE.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(F),tofile='nonlive-edition-author-return')))
m={'owner':'parent /root','native':str(F),'preimage':str(D/'SOURCE-before.md.txt'),'preimage_sha256':sha(old.encode()),'candidate':str(D/'SOURCE-candidate.md.txt'),'candidate_sha256':sha(new.encode()),'effects':str(D/'effects-before.json'),'effects_sha256':sha((D/'effects-before.json').read_bytes()),'depth':4,'primary_provenance':provenance,'actual_whole_native_source_read':True,'operation':'Restore edition-specific authorship; retain exact conflicting dynamic citation output and historical correction provenance. No source id, passage id, quote text, locator, consumer, verification, readiness or semantic enaction claim changed.','cold_review':'Pending independent complete source operation.'}
(D/'CANDIDATE-MANIFEST.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'candidate_sha256':m['candidate_sha256'],'primary_sources':len(provenance),'native_write':False}))
