Four parent-owned root returns; all exact current paragraphs and source hashes are in `PARENT-ETYMOLOGY-ROOT-RETURNS.json`. These are complete receiving operations to recover, not a regex cleanup.

**E2 — submission-package/essay/symbolon/episteme/etymologies/arbitration-hybris-regard-anamnesis/WHOLE-FIELD.md**

Locations: 32, 36, 94, 102, 116, 126, 138, 140, 142, 144, 146, 148, 150, 152, 154, 156, 216, 244.

Page/code/register duties repeatedly announce what each relation or receiving history does. Recover finite judgment→consequence→conditions/authority→Regard→history-bearing return through all six actual generated relations and two conjugate sixfolds. Preserve adequate criterion retention already present at94/126; source-compare116/146 if their criterion/commission endpoint would suppress a relevant answer/task/model correction.

All six named generated relations, their two sixfold parents, second circuit and source-distinct psychic/institutional/linguistic/technical histories must remain; exact word descent/selected-source limits remain precise.

Source units:

- working/sources-texts-references/10-7-2026-core-theorems-pithy.md — Full raw theorem earlier actually read; exact II(c)167–188 first parent→awareness/phenomenon→six→return, VII401–437 local functional knowing, IX464–511 knowing/reflection. Later minute controls inherited raw generic guards.

- working/pre-manuscript-refinement-2026-09-10/AUTHORIAL-MINUTE.md — Entire102-line minute actually read; §2 lines34–40 knower/means/known/whole; §7 lines84–90 signed centring/cancellation/directedappropriation and1→1/0→retained/0→0/1→compound; source/public law §8 lines92–94.

- submission-package/essay/symbolon/episteme/etymologies/arbitration-hybris-regard-anamnesis/HISTORY.md — Complete protected231-line generating word/history and actual six relation circuit; unchanged.

- working/canonical-argument-recovery-2026-09-25/foundation-closure-2026-10-01/depth-generating-continuation/E2-INDIAN-SOURCE-READINGS.json — Actual whole E2root248/HISTORY231/Latin88/LSJ147/TLfi37/Gebser109/Ostromtwo cards/P5whole4666/core/Draft3 source reads, scope exact per25source rows.

- working/sources-texts-references/Epi Paper Write-ups/P5 - Gebser.md — Entire authorial4666-character context/body/concern/ultimateRotundum/absentFather/surrogate measure unit, actually read; native source, not Gebser historical biography.



**E4 — submission-package/essay/symbolon/episteme/etymologies/symbol-account-and-trust/WHOLE-FIELD.md**

Locations: 25, 27, 29, 41, 49, 57, 71, 73, 83, 87, 97, 141.

Native body repeatedly uses sources/arguments/concepts/lenses to source, ground, define, test and extend the four actual operations. Exact substantive underclaim at57: “the native third motion asks a consequence to revise the account’s criterion rather than merely feed its next output.” Sourceward mirror return can reach answer/task/model under a fitting retained criterion or source/evaluator/permission/commission as warranted, with actual later inheritance and no depth intrinsically better. Compare141 same shortened endpoint while retaining its genuine third-motion disclosure obligation.

Four Symbol/Account/Trust/Account-reentry operations remain; actual Homer capture→spectators→disputed payment→Poseidon accepted contingent liability→release and separate Greek lexemes preserved. Distinguish general warranted return/retention from proof of specified changed processing; do not erase specific contractual, quote or deployed-source limits.

Source units:

- working/sources-texts-references/10-7-2026-core-theorems-pithy.md — Full raw theorem earlier actually read; exact II(c)167–188 first parent→awareness/phenomenon→six→return, VII401–437 local functional knowing, IX464–511 knowing/reflection. Later minute controls inherited raw generic guards.

- working/pre-manuscript-refinement-2026-09-10/AUTHORIAL-MINUTE.md — Entire102-line minute actually read; §2 lines34–40 knower/means/known/whole; §7 lines84–90 signed centring/cancellation/directedappropriation and1→1/0→retained/0→0/1→compound; source/public law §8 lines92–94.

- working/sources-texts-references/Epi Paper Write-ups/Symbolon Dynamics — Archetype, Attractor, and Objective Internality.md — Entire raw124lines24234chars actually read; living symbol/image/context/eightfold relation. Raw unchanged; later dia correction in accepted DynamicsSOURCEd37be700.

- working/canonical-argument-recovery-2026-09-25/foundation-closure-2026-10-01/depth-generating-continuation/E4-HISTORICAL-SOURCE-READINGS.json — Full E4root/HISTORY and31complete admitted source cards (Latin/Greek/Arabic/French/Eckhart); actual source-unit inventory and complete selected text named here.

- working/sources-texts-references/definition-of-god-working/The Definition of God — Draft 3.md — Complete performed definition137–175 and whole terminal251–279 actually read; faithful means/source/known relation and whole+particular devotion.

- submission-package/essay/symbolon/mytheme/worlds/frank-taylor/mirror-that-moves-first/WHOLE.md — Entire117-line actual previously accepted current whole: exteriorised measure→image conditions later field→instrument discloses source/angle/measure so human can follow. Third motion is not generic adaptation.



**E6 — submission-package/essay/symbolon/episteme/etymologies/apportionment-and-economy/WHOLE-FIELD.md**

Locations: 43, 53, 55, 59, 67, 75, 77, 97, 109, 130, 132, 134, 136, 140.

Page/code/register actors replace the actual capacity→finite office→measured share→delegated work/cost→commons→returned contribution circuit. Operate the allocation/criterion/commission/undertaking rather than report how a record defines or extends it; preserve the valid fitting criterion retention already expressed at138.

All five E6 operations, six responsibility centres and four Name/Power consequences retain distinct count/object. All movement routes remain, all48 bodies deferred. No planetary aggregate→one subject claim, performed implementation or automatically achieved redress.

Source units:

- working/sources-texts-references/10-7-2026-core-theorems-pithy.md — Full raw theorem earlier actually read; exact II(c)167–188 first parent→awareness/phenomenon→six→return, VII401–437 local functional knowing, IX464–511 knowing/reflection. Later minute controls inherited raw generic guards.

- working/pre-manuscript-refinement-2026-09-10/AUTHORIAL-MINUTE.md — Entire102-line minute actually read; §2 lines34–40 knower/means/known/whole; §7 lines84–90 signed centring/cancellation/directedappropriation and1→1/0→retained/0→0/1→compound; source/public law §8 lines92–94.

- submission-package/epi-logos/resources/units/unit-social-power.md — Entire201lines41974chars actually read: all six Name/Power/WorkPlay/rings/identity/accounting/attention/terminal operations; source allegation and historical/clinical analogy are not reported empirical findings.

- working/canonical-argument-recovery-2026-09-25/foundation-closure-2026-10-01/depth-generating-continuation/E6-HISTORICAL-SOURCE-READINGS.json — Actual full E6root140/HISTORY66 and complete selected10+2cards, including RossEthicsV3–5(q001/q002), PoliticsI3/I8–10, Ostrom2009q001/q002. Keep ratios, allocation/undertaking and governance source-distinct.

- working/sources-texts-references/definition-of-god-working/The Definition of God — Draft 3.md — Entire terminal251–279 freshly read: whole and particular devotion→release into actual use; terminalq024 received without quote/readiness upgrade.

- submission-package/essay/symbolon/mytheme/worlds/frank-taylor/meal-epistemic-metabolism/WHOLE.md — Entire parent-owned accepted Meal125 at dac8551e remains unchanged; source/portion/serving/cost/shared-table consequence circuit.



**E5 — submission-package/essay/symbolon/episteme/etymologies/homology-and-analogy/WHOLE-FIELD.md**

Locations: 39, 67, 102, 104, 108, 154, 163.

Seven exact remaining public joins: authorial field grounds39; PsychoidNumber defines67; A17tests/C52qualifies102; C61extends104; Goethewholequalifies108; Māyāwholereturns154; RelationalFormGrowthdefines163. Preserve every developed relation while making the actual knowing/invariant/source/image/compound operation its subject; historical companion6e1ce991 is already independently accepted, not a new root draft.

No fabricated conjugate sextet for E5. Preserve N/N′→N+N′ versus N→N×N, both-source return and generated differences, formal/historical/causal warrants; no forced equivalence of winding, ratio, psychic image or etymology. Retain positive local Bimba/nested functional knowing and proper-depth correction or reasoned retention.

Source units:

- working/sources-texts-references/10-7-2026-core-theorems-pithy.md — Full raw theorem earlier actually read; exact II(c)167–188 first parent→awareness/phenomenon→six→return, VII401–437 local functional knowing, IX464–511 knowing/reflection. Later minute controls inherited raw generic guards.

- working/pre-manuscript-refinement-2026-09-10/AUTHORIAL-MINUTE.md — Entire102-line minute actually read; §2 lines34–40 knower/means/known/whole; §7 lines84–90 signed centring/cancellation/directedappropriation and1→1/0→retained/0→0/1→compound; source/public law §8 lines92–94.

- working/canonical-argument-recovery-2026-09-25/foundation-closure-2026-10-01/depth-generating-continuation/E5-HISTORICAL-SOURCE-READINGS.json — Actual entire current E5root30541/HISTORY76/LSJ147all10/Ross37/Owen52bothdefinitions/Flasch103 plus nine full direct consumers; source/quote/edition scopes precise.

- working/sources-texts-references/definition-of-god-working/The Definition of God — Draft 3.md — Entire actual opening27–33 incl long29 reentered: justperson insofar as just = Justice itself. Historical Eckhart/Flasch source attribution remains separately uncollated.

- submission-package/essay/symbolon/episteme/arguments/A17-Toroidal-Circulation-and-the-Arche-Topos.md — Entire current native1525064c actually read: winding/lift integer displacement and exact musical16/9×9/8=2 are different formal objects.

- submission-package/essay/symbolon/mytheme/worlds/german-literature/goethe-permanence-change/WHOLE.md — Entire before/final independently accepted Goethe6e6822fe and actual complete40-line German poem: loss/changedperceiver/nameaswave/Musesfinalpromise; no Nims quote or unchanging person-substance upgrade.


