from pathlib import Path
import json,hashlib,re,dataclasses,importlib.util,sys
R=Path('.').resolve();B=R/'working/canonical-argument-recovery-2026-09-25/foundation-closure-2026-10-01';D=B/'depth-generating-continuation'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
s=importlib.util.spec_from_file_location('recoveryaudit',R/'tools/audit-canonical-argument-recovery.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
# Each row answers the protocol's three questions for one complete, exact passage.
E4={
7:('All ancient dictionary citations and five traditions were independently primary-collated and share ancestry.','Opening places the lexical witnesses beside five religious practices.','Witness office and retained consultation date; no invented common genealogy.'),
11:('One abstract token sense exhausts every cited Greek use.','Corresponding pieces, guarantee and civic payments occur together.','LSJ differentiates uses and warrants lexical senses, not all primary contexts.'),
13:('An authentic token certifies just obligation and future conduct.','Inspectable physical fit establishes correspondence.','Recognition is effective while justice and conduct are further judgments.'),
15:('Herodotus, Medea and Symposium were newly primary-collated; symbol morphology and accusation chronology already verified.','Precise ancient locators follow the Greek token definition.','Dictionary-mediated contexts and separate lexical/history debts remain visible.'),
17:('Every earlier arithmetic sign and psychic history already possessed the final native Symbol.','Integral return is compared with the zero–subject history.','Achievements remain dated and differentiated rather than retrojected.'),
21:('Account means cut together etymologically, and every telling is financial.','Counting and narrative senses meet the retained earlier quoted gloss.','Actual English descent and sense range rather than a fabricated root.'),
23:('Bank tally borrowed from Greek recognition tokens.','Split physical records are directly compared.','Documented1694 object and unestablished borrowing route remain distinct.'),
25:('The one tally proves all money history, Exchequer procedure and moral legitimacy.','Identity/debt integrity is explained through matched records.','Museum object supports a determinate practice, not full institutional or ethical history.'),
27:('Every wider account-related term and heart/credit theory has an admitted common genealogy.','Many semantic neighbours and circulating claims are named.','Separate unattested lexical/reconstruction routes remain precise.'),
29:('All reference, rule, address and suspended assumption descend from one linguistic source.','Different language practices are placed in one later account.','Different conditions and institutional histories retain their office.'),
31:('Baudrillard threeorders=fourphases and symbolic reversibility guarantees benign reconciliation.','Native adaptation is compared with his explanatory frame.','Counts and interpretive consequence remain distinct; fitting frame can be retained.'),
35:('Trust has certain Scandinavian transmission and one undifferentiated sense.','Its lexical origins and reliance/custody/credit are joined.','Dictionary probability and differentiated historical-language offices.'),
37:('Dictionary trust derives theologicalfaith/covenantarchitecture or knowledge dependence.','Reliance is followed by Taylor’s commitment argument.','Actual lexical sense versus further philosophical undertaking.'),
39:('Formal limitingconditions by themselves perform trust and reliance.','Formation/derivability/elucidation/predication lead toward use.','A further undertaking remains necessary beyond shared limit vocabulary.'),
49:('Akin is a complete derivational demonstration for holy.','Lexicaltable presents hālig/hāl kinship.','The exact lexicographer’s qualified wording remains intact.'),
54:('Lexical soundness proves closed-integrity doctrine or holiness=clinicalhealth.','Whole/holy/health are historically related.','Attested sense and institutions cannot be reduced to one contemporary doctrine.'),
56:('Hole and whole are historically cognate.','The retained chiasm gives their homophony structural force.','Poetic crossing depends on independent hol/hāl descent.'),
60:('English homophony proves a torus theorem, universalholy genealogy or clinicalhealth theory.','Opening-integrity relation is developed beside formal geometry.','Lexical, poetic, mathematical and clinical warrants remain different.'),
66:('The five traditions provide hidden roots for the three English terms.','Five source-return comparisons are grouped.','Independentlexical/textual/material practices retain their own soils.'),
71:('Sanskrit terms are ancestors of English Symbol/Account/Trust.','Enumeration is introduced as a philosophical source-return comparison.','The comparative reception is positive without a transmission claim.'),
76:('The uncertain ancient date is exact, electronicrecension is1837witness, or causal descriptions merely count identical items.','Date, edition,25 and4causaloffices are in one paragraph.','Separate1998/1837 witnesses and produced/productive/inactive offices.'),
78:('Puruṣa25 means oneperson, or25=36Trika=8QL.','Precise seven/sixteen causal grouping is compared with native determinations.','Verse18 plurality and independent causal/cognitive classifications.'),
80:('Sāṃkhya testimony and TaylorTrust have identical full scope.','Perception/inference/testimony follow the enumeration.','Specific epistemic means versus broader committed use.'),
82:('Inactivepuruṣa becomes agent of mutualrevision; isolation=recursiveanswerability.','Practised discrimination changes appropriation and is followed by a native return.','Wheel/dispositions/bodilydissolution and isolation keep source’s direction.'),
84:('Any testifiedteaching permits correction and Sāṃkhya release implements Taylor’s entire norm.','Four native operations are compared with its classification/knowledge/practice.','Attributedteaching and isolatingrelease keep their difference from recursive answerability.'),
86:('Lexicalkinship alone proves ontology or language transmission.','Exactcount/knowledgewarrant are compared.','Criterion, knowledge means, ontology and historicaltransmission require distinct warrant.'),
88:('Online transcription establishes physicalprintcollation, exact ancientdate and fullpracticehistory.','PreciseSanskritrecensions supply paraphrase.','Scoped online witnesses and edition/date/reception limits remain explicit.'),
93:('HebrewSPR derivesEnglishterms or names their whole native relation.','Counting/writing/telling grouped into SymbolAccountTrust.','Actualforms/offices versus unsupported ancestry/nativeidentity.'),
95:('One primordial tally certainly produced all Hebrewwriting.','Sāfar/sōfēr/sēfer/mispār are related with proposed roots.','BDB probable derivations and differentiated stem/sense offices.'),
97:('SPR,ʾMN,ḤŠB are one root or narratedKingsdate=textcompositiondate.','Genesis joins count,belief and reckoning in one passage.','Distinct lexicalroots/edition/narratedchronology/composition.'),
100:('WomancorrectedGehazi and restorationorder proves execution.','Her directaccount changes practicaloffice of remembereddeed.','Confirmation,consequential commission and absent execution proof.'),
102:('Moreaccounting sufficiently causestrust orSPR supplieseverycount/reckonverb.','Repairchest/materialfunds/faithfulworkers are in one sequence.','No reckoning with faithfulmen and differentMNH/ḤŠB/ʾMN roots.'),
104:('Foundbook’s compositiondate or unlimitedcurrent speakingauthority established.','Shaphan/Hilkiah/Josiah/Huldah convey writtenauthority.','Narrated entrustedoffices versus unverifiedcomposition/currentauthority.'),
106:('Biblicalfaithfulness already prescribes Taylor’s entire revisability norm.','Four operations relate countedfunds/materialrepair/answeredperson.','Historicalpraise and newnorm remain separately warranted.'),
108:('Restorationorder equals implementedrepair.','Operationalparity and resource/record/criterion are linked.','Execution unproved restricts next permissible assertion.'),
110:('OnlineBDB provesprintcollation,regnal datesprovecomposition/archaeology/execution.','Exactbiblicalchronologies support consequences.','Qualifiedderivations and textual/historical evidence boundaries.'),
115:('Appointment sense is hiddenmeaning ofAnalects13.3; Chinese derivesEnglish terms.','Lexicalactuality/office openscomparison.','SeparateMOEsenses and independent language ancestry.'),
117:('Confuciuspoliticalsequence wasimplemented/empiricallyverified.','Names→speech→affairs→rites/music→punishments→people’sorientation is complete.','Receivednormative argument versus actual governmental evidence.'),
119:('名 means everytoken/model/ledger and passage is QLderivation.','Four nativeoffices interpret politicalspecificity.','Designation/role/consequence remain actual but lexical scope retained.'),
121:('Allunopposedcounsel isbad,one sentence mechanically ruinsstate,or modern rightdissent instituted.','13.15 warning follows answerability.','Good/badcounsel distinction and source’s own political office.'),
123:('Trust is Chinese lexicaltranslation and everyfailure forcescriterionchange.','Counselauthority and correctionroute are joined.','Adequatecounselretention versus failedcounselrevision and Taylor’s additionalnorm.'),
126:('SelectedLegge/museumonline provescriticalmanuscript,Wei context,implementation/reception.','Measure/office/counselconsequence have precise links.','Scoped witnessednorm and separatehistoricalcollation.'),
132:('ḥisāb and aḥṣā are one root orEnglishcountingdecides their operation.','TwoLanesenses are placed nextto invocation.','Distinctroots and passage-specific enumeration/registration/memory/knowledge.'),
134:('Qur’anicdivinejudgment is a humaninstitutionledger whosecriterion judgedpersoncanrevise.','Life/book/reckoning is compared with answerability.','Religiousoffice and native institutional comparison keep distinct agency.'),
136:('Qur’an supplies99list and beadprotocol,orKhanmemorisation exhaustsaḥṣāhā.','Invocation and hadithcount placed together.','Separateverse/report/compilerdate/translatedinterpretation and unobserveddevotionalpractice.'),
138:('Hadith prescribesTayloranswerability orproposeduse provespsychologicalexperiment/afterlifefulfilment.','Four operations relate religiouscount/address/undertaking and laterinvocation.','Finitecount preservesobject/act/attribution/promise; additionalnorm and actualresult remain distinct.'),
140:('Arabic/Egyptian religiousobjects are identical or English derivesfromArabic.','Counterpartsfollow invocation/reckoning.','Separatecountedobject/act/attribution/promise and historicalperiods.'),
142:('99formula derivesnativeA15/A23 orcompleteNames/recitation/datehistory admitted.','Countandundertaking receivecomparison.','Independentnativewarrants and exact selectedwitness scope.'),
147:('LexiconattestationdatesReripapyrus orDemoticrelation makesallperiodssame.','rn gloss and continuedpersonhood introducematerialpractice.','Lexical noun/corpusspan versus identifiedobject/language/period.'),
149:('305–30 is exactproductionyear orReriname demonstratesuniversalsoulpart inventory.','Spell25column3 linkedwith neighbouringrestoredcapacities.','Museum daterange and particular funeraryperson/provision.'),
151:('Papyrussurvival empiricallyprovesafterlife,orAnitranslation isRerispell25text.','Prospectivewrittenprovisionexplainsnamedcontinuity.','Madeprovision versus promisedresult; museumidentifiedpurpose versus fullhieratictext.'),
153:('Everyreader remembersReri,riteachievedafterlife,orritualequalsnativeformallimit.','Four operationsconnectmaterialsurvivaland laterencounter.','Namedparticular,attributedpromise and presentverification remain separate.'),
155:('Historicaldeceased cananswercurator now orrn=ArabicDivineName/commonroot.','Livinganswerability adapted to survivingname.','Presentaccount bearscorrectionduty while historicalperson/wordidentityunclaimed.'),
157:('Materialsurvival alone determineslivingsymbol/idol and fullspell25translation admitted.','Preservedsign linksLivingSymbolconcept.','Person/objectpurpose distinctpossession; absenthieratictranslation notmanufactured.'),
159:('Thefivepractices provideuniversalgenealogy orfullyverifiedreception/efficacy.','Theircompletepositivecomparison is concluded.','Precise source-specificcollation/chronology/result scope.'),
161:('Physics,1975dialogue,handout,SEED areonepractice and suspensionforcesrevision.','Bohmcomparisoncarrieslaterquestion.','Distinctpractices/sourceauthority and reasonedfittingretention.'),
163:('Record=livedduration,self-editing=autopoiesis and everyreturnchangescriterion.','Fivegeneratingtransformations arejoined.','Eachspecificoperation receives relevant transformationorretention.'),
165:('Processscience is onesingleinfluencechain.','Continuations share nextinquiry relation.','Independent editions/practices/instruments and actualsourceobject.'),
}
E6={
15:('Greekvocabulary→computation is onecontinuoushistory.','Arrangementfollows share/name/measure/office/house.','Differentpractices retain publichistories.'),
17:('Soundlikeness proveslexicaldescent and allprintcollation accomplished.','Earlierlexicalinquiryopensshare/name/measure.','Descent,usage,comparison and selectededition boundaries.'),
24:('Alllaterlaw obligatorilydescendsfrompastoral life.','LSJdistribute/assign/hold examples listmeat/property/land.','Attestedsenses versus compulsorychronology.'),
26:('Nomosfromnemo proves universalpastureoriginofstate oraccentednomosidenticalentry.','Lexicalconnection andlawsenses directly asserted.','Separateentries and historicalinstitutionalorigin.'),
28:('Anyapportionmentdetermines gift/entrusteduse/sale/inheritance/domination.','Distributor/recipient/field sharedacrossportions.','Concretepractice determines terms ofreturn.'),
30:('Nomen/numerus shareprovenIndoEuropeangenealogy orsound performsissuer/bearer.','Denominationjoinsnameandnumber.','Unadmittedcomparativeentries versus independentlyintelligibleissuingpractice.'),
32:('Amarkexhaustsparticular and lexiconsettles institutionalpermission.','Publicmarklinkedwithderivedofficeauthority.','Addressedperson/claimedsource/authorisedact remainfurtherrelation.'),
39:('Ratio/arithmos/harmony haveverifiedcommonancestry.','Reor/ratus andcalculationusescomparefiniteformalmeasure.','SelectedLatinsemanticrange with no falsecrossrootproof.'),
41:('Aristotle’sexchangeaccountverifiesfirstcoinarchaeology.','Builder/shoemaker/conventionalmoney claimsintroduceorigin-likeaccount.','PhilosophicaldistinctionsinV3–5, directq002V5warrant.'),
43:('Exchangepricefitsallgoodsquestions; countcriterionlegitimatebyexactness; triadappropriatesperson’simmediacy.','Price/modelscore/agentjudgingoperationarecompared.','Criterionauthority/localfunctionaloffice/personcontainingmeans/distincthistoricalwarrant and properdepthcorrectionorretention.'),
45:('LatinlexiconderivesQLarithmetic;everyreturnrequiresmeasurechange;retentionprovesprocessingchanged.','Finiteratio/QL/preference arejoined.','Native mathwarrant and broadanswerability versus stricteractualchangedprocessingproof.'),
52:('Aristotle’smoneychronologyverified orhierarchicalhousehold=egalitariancommons.','Provision/exchange/money/master-slave sequence opensmoderncomparison.','Source’sownhierarchy and origin narrative arehistoricallyscoped.'),
54:('Everydelegationisloan andCatoprimarytext newlycollated.','Credolending/protection/confidence/beliefplacedbesidedelegatedcapacity.','Lexicalsense differentiation and dictionary-mediatedCato.'),
56:('Productscorealreadyaccountsforlabourcostsandoutputprovescurrentcosts.','Commissionseparatesbenefitandunoriginatedconditions.','Work/constraints/depletionmustreachproperauthority; particularactualcostevidencestillneeded.'),
58:('Ostromcriteria rigidlytransplant everywhere oruniversallysucceedoikonomia.','Affectedparticipation/localrights/nestedgovernment relateancienthouse.','Institution-specificsocial/ecologicalconditions and sourcewarnagainstrigidtransplantation.'),
60:('Federationrequiresonecompletedaccount andlocalcommunities surrenderground.','Widercommons/localBimbarelationispositive.','Actual local reference and refusal/source-answerability coexist.'),
62:('Training/delegation/commonsreport equals executedresult.','Threetechnical/institutionalpowers arelinked.','Performers/benefits/cost and reportversusobservationdistinct.'),
66:('Ephesiansproves everyeconomyreturnstoplenitude orfulltranslation/receptionverified.','Fullnesstime/gatheringinChristusedbesideeconomy.','Christologicalpurpose and selectedGreekscope.'),
68:('HostileValentinianreport=Irenaeusownrulefaith andallparticipantsrestoreidentically.','I10.3dispensation andI7unequalends arejoined.','Differentvoices/doctrines/destinations retain temporaloffices.'),
70:('Commonfullnesswordprovesone doctrine andidenticalreturnforeverything.','JointSoter/unequaldestinationsreceivenativecomparison.','Distinctreportedparticipantsandfates.'),
72:('Ephesians/IrenaeuscertifyQLinstitutionor modernlocalauthoritychangesancienttext.','Answerablecommonscomparearrangementconsequence.','Independent theologicalwarrant and contemporaryinstitutionalclaim.'),
76:('PlanetaryvocationupdatesancientEgyptian/theologicalsourceattribution.','Whole/aperturedevotion andparticularotherfollowhistoricalfullness.','Taylor’svocation receivesotherswhileancientwitnesseskeepownoffice.'),
78:('Deliveryofproductalreadychangescommission orinterfaceexhaustsdependencies.','NamePower/labour/planetaryaccountcompletefiveoperations.','Specific product/governingcommission and material/institutionalconditions.'),
80:('Allrelatedetymologies,print/reception,supplychains,currentlabour verified.','Final historicalscope listsmanynamedthreads.','Particularacceptedwitnesses versus genuineindependenthistorical/empiricalevidence.'),
82:('Sharedartifacttransferssourceownership orhistoricalsixconstructorchecksprovewiderarchitecture.','Artifactconditionlocalfield/rights remain effective.','Actualrecordbehaviour bounded to historicalchecks; architectureexecutionseparate.'),
}
manifest=json.loads((D/'E4-E6-HISTORICAL-CANDIDATES.json').read_text())
for row,reasons in zip(manifest['records'],[E4,E6]):
 k=row['key'];a=Path(row['preimage']);p=Path(row['candidate']);before=a.read_text();after=p.read_text();lines=after.splitlines();findings=[dataclasses.asdict(x)for x in m.audit_file(R,p.resolve())];save(D/(k+'-DETECTOR.json'),findings)
 assert all(x['severity']!='hard'for x in findings)
 assert all(x['line']in reasons for x in findings)
 codes={}
 for x in findings:codes.setdefault(x['line'],[]).append(x['code'])
 qualifications=[{'line':ln,'exact_unit':lines[ln-1],'detector_codes':codes.get(ln,[]),'stronger_or_mistaken_inference':qs[0],'actual_feature_making_inference_live':qs[1],'necessary_information_lost_on_removal':qs[2],'disposition':'Retain exact source/formal/normative/implementation distinction; positive operation precedes limit.'}for ln,qs in reasons.items()]
 save(D/(k+'-QUALIFICATION-REVIEW.json'),{'candidate_sha256':h(p),'protocol_questions':'Recovery protocol200–204, three concrete answers per exact passage','detector_findings':len(findings),'individual_qualified_units':len(qualifications),'rows':qualifications})
 targetpattern=r'\[[^\]]*\]\(([^)]+)\)';oldtargets=re.findall(targetpattern,before);targets=re.findall(targetpattern,after);missing=[]
 for t in targets:
  if t.startswith(('http:','https:','mailto:','#')):continue
  q=Path(row['native']).parent/t.split('#')[0]
  if not q.exists():missing.append(t)
 fm=lambda t:t.split('---',2)[1]if t.startswith('---')else''
 curly=re.findall('“[^”]*”',before)
 anchors=lambda t:re.findall(r'<a id="([^"]+)"',t)
 checks={'preimage_sha256':h(a),'candidate_sha256':h(p),'live_native_sha256':h(Path(row['native'])),'live_native_preimage_exact':h(Path(row['native']))==h(a),'hard_count':0,'review_count':len(findings),'every_detector_unit_individually_disposed':True,'metadata_exact':fm(before)==fm(after),'original_curly_quoted_strings_missing':[x for x in curly if x not in after],'original_resolved_targets_lost':[t for t in oldtargets if t not in targets],'link_count':len(targets),'missing_files':missing,'explicit_anchor_ids_exact':anchors(before)==anchors(after),'six_position_headings_exact':[x for x in before.splitlines()if re.match(r'## #[0-5]',x)]==[x for x in after.splitlines()if re.match(r'## #[0-5]',x)],'honest_exceptions':'E4 lexical-table header/registercells and individual public paragraphs recovered; E6 subsection displayprefixes removed while anchorIDs exact. Not table/all-heading byteidentity.','scope':'No full builders/tests/freshness/globalprotected assertion; parent unchanged gates remain. No live writes.'}
 assert checks['live_native_preimage_exact']and checks['metadata_exact']and not checks['missing_files']and not checks['original_resolved_targets_lost']and not checks['original_curly_quoted_strings_missing']and checks['explicit_anchor_ids_exact']
 save(D/(k+'-LIGHTWEIGHT-CHECKS.json'),checks)
 row['status']='Complete source-first non-live whole operation and final self-read/check/individual qualification; independent source/public cold pending'
 row['checks']=str(D/(k+'-LIGHTWEIGHT-CHECKS.json')).replace(str(R)+'/', '')
 row['qualifications']=str(D/(k+'-QUALIFICATION-REVIEW.json')).replace(str(R)+'/', '')
 print(k,h(p),'0hard',len(findings),'reviews',len(qualifications),'qualifiedunits',len(targets),'links',len(missing),'missing')
 save(D/'E4-E6-HISTORICAL-CANDIDATES.json',manifest)
