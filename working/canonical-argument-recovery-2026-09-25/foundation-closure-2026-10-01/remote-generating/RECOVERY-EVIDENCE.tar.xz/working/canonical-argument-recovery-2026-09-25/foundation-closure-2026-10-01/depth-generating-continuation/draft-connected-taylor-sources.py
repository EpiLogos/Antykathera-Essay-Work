from pathlib import Path
import json,hashlib,re,os,difflib
R=Path('.').resolve(); B=Path('working/canonical-argument-recovery-2026-09-25/foundation-closure-2026-10-01'); D=B/'depth-generating-continuation'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
raw=Path('working/sources-texts-references/Epi Paper Write-ups/Symbolon Dynamics — Archetype, Attractor, and Objective Internality.md')
minute=Path('working/pre-manuscript-refinement-2026-09-10/AUTHORIAL-MINUTE.md')
inventory=json.loads((D/'DYNAMICS-SOURCE-CURRENT-BINDING-INVENTORY.json').read_text())
argumentrows=sorted([x for x in inventory if '/episteme/arguments/' in x['path']],key=lambda x:Path(x['path']).name)
assert len(argumentrows)==12
keys=[]
for key,stem in [('DYNAMICS','taylor-2026-symbolon-dynamics'),('POETRY','taylor-2026-personal-poetry-corpus')]:
 native=Path('submission-package/essay/symbolon/episteme/sources/internal-corpus/taylor')/stem/'SOURCE.md'; before=D/(key+'-SOURCE-before.md.txt'); assert h(native)==h(before)
 pre={'native':str(native),'preimage':str(before),'preimage_sha256':h(before),'effects_before':str(D/(key+'-SOURCE-effects-before.json')),'effects_boundary':'Native source-house path reports zero downstream paths. Independent current byte inventory and exact actual receiving units preserve positive consumers; zero graph result is not an absence claim.','sources':[{'path':str(raw),'sha256':h(raw),'read':'Fresh entire24234chars124lines in0–15500/15500–end for Dynamics; prior whole same raw already retained.'},{'path':str(minute),'sha256':h(minute),'read':'Fresh entire102lines; §7 healthy centred polarity versus additive cancellation/directed appropriation and break-retention-recognition; §2 relative local offices.'}],'before_recovery':'Dynamics: full source5273chars plus full raw; current full A13 and A19 freshly reread; all twelve native receiving exact named units and four primes reopened. Poetry: prior fresh complete32243chars511lines/all23 cards at exact unchanged b8db hash; fresh complete tail and current full Taylor-images source operation.','planned_operation':'Dynamics: recover truthful actual receiver declarations and distinct signed/logical/temporal/full returned-condition operations, preserving immutable older wording in raw. Poetry: bind all23 actual complete-card receivers through native Taylor whole, distinguish absent direct argument/movement declarations from indirect reception.','protected':'No raw, verse, NOTES, HISTORY, manuscript, movement, test, tool or generated edits; identity/readiness/quotation and all original source locators retained.'}
 save(D/(key+'-SOURCE-PRE-EDIT.json'),pre)
 old=before.read_text();new=old;rel=lambda p:os.path.relpath(str(p),str(native.parent))
 if key=='DYNAMICS':
  ids=[Path(x['path']).name.split('-',1)[0]for x in argumentrows]
  assert len(ids)==len(set(ids))
  new=new.replace("passage_surface: '#passages'","passage_surface: '#passages'\nconsumed_by_arguments:\n"+'\n'.join('  - '+x for x in ids),1)
  oldpoint='4. Synchronic/diachronic temporality crosses sym-ballein/dia-ballein as two modes of accounting: each temporal view can either retain the ground and return of a differentiation or sever its terms into cancelling opposition.'
  newpoint="4. Synchronic co-presence and diachronic formation or succession give two temporal views of a relation; neither by itself determines its logic. In Taylor's later signed reading, dia differentiates as centred polarity `(-1)/(+1)`, whose zero-axis holds tension and connection. Additive cancellation `(-1)+(+1)=0` differs from directed appropriation `(-1)-(+1)=-2` or `(+1)-(-1)=+2`; neither failure exhausts dia's real discriminating office. A returned condition first meets the materialist `1` as its own uncomputed division `1/0`. Retaining the `/0` beneath the achieved one carries the break into `0/1` recognition; syn relates the inverse orientations through `(0/1)/(1/0)` without erasing their difference. The [subsequent authorial correction]("+rel(minute)+"#7-dia-and-syn-as-usable-writing-language) governs this consumer reading. The manuscript's earlier cancellation wording remains unchanged in its historical passage surface."
  assert new.count(oldpoint)==1;new=new.replace(oldpoint,newpoint)
  stale='The source currently declares no downstream consumers. Argument, concept, section, and history links should be added only after the blast-radius discussion determines which movements receive direct warrant and which receive a lighter transverse echo.'
  links=[]
  for x in argumentrows:
   q=Path(x['path']);title=re.search(r'^title: [\"\']?(.*?)[\"\']?$',q.read_text(),re.M).group(1)
   links.append('['+title+']('+rel(q)+')')
  reception="Existing native argument receivers are "+', '.join(links)+". Their current bodies receive the synthesis through symbolic recursion, differentiated determining offices, contextual worldhood or the temporal/logical crossing; this source inventory records those actual relations. Source-ID declarations are already present in A07, A13, A14 and A26. A19 receives it through its explicit authorial source relation and linked archetype–complex–image operation, without a current `source_ids` field. The other named receivers have actual body-level use, which is distinct from a source-ID declaration."
  primerows=sorted([x for x in inventory if '/episteme/conjugate/' in x['path']],key=lambda x:Path(x['path']).name)
  prime_links=['['+Path(x['path']).name.split('-prime-',1)[0]+'′]('+rel(Path(x['path']))+')'for x in primerows]
  reception+='\n\n'+', '.join(prime_links)+" separately declare this source. The psychic and technical faces retain their own determining offices: formative recurrence, affectively organised complex, particular image and transformative symbol are not interchangeable with model, retrieval surface, persona or policy. Existing concept, Mytheme, dossier and history receptions likewise remain their particular comparisons. These bindings introduce no direct movement assignment or new claim of performed psychic or technical transformation."
  assert new.count(stale)==1;new=new.replace(stale,reception)
 else:
  stale='No section or argument consumers have been assigned yet. Add reciprocal links only when a specific movement actually uses a poem.'
  whole=Path('submission-package/essay/symbolon/mytheme/worlds/frank-taylor/taylor-authored-images/WHOLE.md'); ws=whole.read_text(); cards=['taylor-2026-personal-poetry-corpus-q'+str(i).zfill(3)for i in range(1,24)];assert all('#'+c in ws for c in cards)
  newtext="The [Taylor — Poetry and Authored Images whole]("+rel(whole)+"#taylor-authored-images-whole) directly receives all twenty-three complete passage cards, FT-P01–FT-P23, and develops their particular sounds, pronouns, turns and endings. Its FT-P01–FT-P23 anchors correspond to q001–q023 here, preserving each full poem rather than reducing the corpus to excerpts. The whole's first-person, Two Ones and speaking-limit relations also enter the existing argument field through that Mytheme carrier. This indirect reception is distinct from a direct poem-source declaration: `consumed_by_arguments` and `consumed_by_sections` remain empty because this bounded comparison found no native argument or movement declaration of the poetry source. The present binding assigns no movement and supplies no new ratification; individual verse, locators, provenance and quotation readiness remain as received."
  assert new.count(stale)==1;new=new.replace(stale,newtext)
 candidate=D/(key+'-SOURCE-candidate.md.txt');candidate.write_text(new)
 units=[];op=difflib.SequenceMatcher(None,old.split('\n\n'),new.split('\n\n'),autojunk=False)
 for tag,a,b,c,d in op.get_opcodes():
  if tag!='equal':units.append({'old_complete_units':old.split('\n\n')[a:b],'new_complete_units':new.split('\n\n')[c:d]})
 save(D/(key+'-SOURCE-WHOLE-CHANGED-UNITS.json'),{'preimage_sha256':h(before),'candidate_sha256':h(candidate),'units':units})
 (D/(key+'-SOURCE.diff')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(native),tofile=str(candidate))))
 keys.append({'key':key+'-SOURCE','native':str(native),'preimage':str(before),'preimage_sha256':h(before),'candidate':str(candidate),'candidate_sha256':h(candidate),'effects_before':str(D/(key+'-SOURCE-effects-before.json')),'pre_edit':str(D/(key+'-SOURCE-PRE-EDIT.json')),'status':'Complete source-first non-live connected binding/signed-operation candidate; self/independent review pending'})
save(D/'CONNECTED-TAYLOR-SOURCE-CANDIDATES.json',{'records':keys,'protected':'All source verses/raw and original quotation/readiness untouched; no direct movement assignment','scope':'Bounded actual existing source-house receiving relations, plus precise authorial dia/syn correction; no global consumer/source history acceptance.'})
print('\n'.join(x['key']+' '+x['candidate_sha256']for x in keys))
