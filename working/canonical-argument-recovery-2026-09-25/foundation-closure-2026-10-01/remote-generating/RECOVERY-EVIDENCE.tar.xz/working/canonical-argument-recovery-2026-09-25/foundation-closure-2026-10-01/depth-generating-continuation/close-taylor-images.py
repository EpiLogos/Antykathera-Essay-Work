from pathlib import Path
import json, re, hashlib, difflib, dataclasses, importlib.util, sys
R=Path('.').resolve(); B=Path('working/canonical-argument-recovery-2026-09-25/foundation-closure-2026-10-01'); D=B/'depth-generating-continuation'
def h(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
p=D/'TAYLOR-IMAGES-candidate.md.txt'; a=D/'TAYLOR-IMAGES-before.md.txt'; after=p.read_text(); before=a.read_text(); lines=after.splitlines()
native=Path('submission-package/essay/symbolon/mytheme/worlds/frank-taylor/taylor-authored-images/WHOLE.md')
spec=importlib.util.spec_from_file_location('audit',R/'tools/audit-canonical-argument-recovery.py'); m=importlib.util.module_from_spec(spec); sys.modules[spec.name]=m; spec.loader.exec_module(m)
findings=[dataclasses.asdict(x) for x in m.audit_file(R,p.resolve())]; save(D/'TAYLOR-IMAGES-DETECTOR.json',findings)
reasons={
20:('Compilation order is composition chronology and bracketed first lines are authorial titles.','June sequence precedes March poems in the retained compilation.','Order, dates and supplied titles keep distinct offices; all verse remains unchanged.'),
22:('File location proves birthplace; common morphology supplies universal cultural chronology.','Geography and Neumann structuration are compared with dated works.','Actual English/journal occasions and distinct geography, chronology and morphology warrants.'),
24:('Poems or Neumann retrospectively derive the entire mathematical field.','Full eight determinations and complementary harmonics precede particular poems.','Native authorial notation and two complementary harmonic readings retain their independent basis.'),
26:('Repeated bird or divine name has one fixed identity in all works.','The same names recur across poems and images.','Particular words, action and ending determine changing offices.'),
83:('The Zero/One verse independently proves arithmetic.','Numeric symbols and Two Ones occur in one poetic breath.','Poetic utterance and the native mathematical derivation remain distinct.'),
187:('The polemical release from defence constitutes verified elimination of every actual war or injury.','Poem speaks of no wars and unsullied sense.','Actual sound and argument of this particular utterance; no empirical universal result.'),
191:('Return generates a seventh poem or P4 rejects all productive difference.','Ordered P0–P5 has a return through the loop.','Six-work composition and complementary productive/severing offices stay complete.'),
204:('P1 is a public workflow address or a verified computing benchmark.','Authorial title includes P1 and binary limitation.','Exact inherited title names the individual work; no heading alteration or runtime inference.'),
206:('The line is an agent disclaimer to delete.','What binary cannot compute is the first verse line.','Protected authorial verse and its exact wording; interpreted by the complete poem.'),
207:('The line is a generic consciousness restriction.','What thinking cannot know precedes common root and growing powers.','Exact protected line participates in the poem’s positive shared-root movement.'),
237:('Never falling into enmity is an automatic historical outcome.','P3 develops two through Two Ones and 4+2.','Protected complete productive-distinction verse; no implemented institutional result.'),
253:('The negated title is an editorial non-inference guard.','God is not a thing to argue over is the work’s actual first line.','Authorial title and complete verse must remain exact.'),
255:('The quoted poem proves its entire 2000-year history or mathematical universal.','Full P5 contains historical polemic and symbolic number.','Entire protected utterance remains available; history/math receive separate warrants.'),
259:('The compilation quotation upgrades P5 historical polemic to established history.','Commentary discusses number and historical duration.','The actual speaking-limit operation and its attributed historical utterance.'),
275:('Love cancels the speaker’s hatred/fear or permits abandonment of people.','P17 joins love, hatred and their fear after paradox of change.','Particular pronouns and actual journal pressure keep their uncomfortable implication.'),
285:('The negative line is commentary to remove.','I could never live it down is within P18’s complete verse.','Protected aftermath and speaker’s lived relation; wording remains exact.'),
316:('Understanding manufactured desire already escapes capture or reconciliation means eradication.','P18 returns to soothing, stagnation and brothers after the kiln.','Full final aftermath and actual failed knowledge/choice/entrainment relation.'),
326:('Atman or witness is the poem’s supplied referent.','P19 withholds the term while seven clauses disclose dependencies.','Direct authorial refusal to name the referent and necessary self-negating journey.'),
328:('Later context/silence instruction silently revises the canonical verse or positions are imposed slots.','Current verse and corrected reading differ in clause order.','Exact unchanged verse, specific order instruction and positive dependency-derived movement.'),
351:('Inverse reading replaces multiplied, collapses both returns, or validates indeterminate calculus.','P21 opens multiplication and then full divisional inverse.','Two complete 4+2 passages/returns and exact verse versus mathematical-domain distinction.'),
372:('The one in the boots is principally the brother.','A prior conversational gloss diverted the emotional relation.','Direct authorial self-emotion/feeler correction and quaking-in-my-boots image.'),
374:('Venus/Sophia/martian prove the separate Venus–Lucifer–Christ genealogy.','Several named figures complete feeling’s tonal movement.','Their actual offices in this poem and separate unmined reception route.'),
401:('Naming Blake licenses an additional invented Blake quotation.','P23 names Blake and fleeting joy.','Complete particular allusion without fabricated text or source attribution.'),
405:('Historical emblem, institutional diagnosis and psychic operator share identical evidence.','Fourteen prose images gather within one authorial field.','Actual material conditions and aftermath of each different image.'),
410:('An independent outside view can encompass the condition sustaining the fish’s life.','Fish describes water from within.','Life/description condition returns to the describing subject’s actual act.'),
426:('Cymatic frequency proves philosophical truth; pun proves lexical history; local centre becomes absolute.','Orbital centre, mandala, frequency and buoyancy play are adjacent.','Real local centring/decentring and distinct physical/lexical warrants.'),
435:('Necker experiment proves simultaneous incompatible depth percepts or context is another victorious face.','Unchanged lines support reversible readings.','Authorial I/you/it/context/recognition operation and actual perceptual experiment boundary.'),
440:('Another centre is only a representation in mine, or reality needs a final spectator.','Nested internalities follow situated experience.','Effective other centres and non-exhaustion by one model.'),
442:('Historical sphere formula is attributed without a witness; local centre displaces lived knowing.','Centre-everywhere joins interpreting agent, representation and instruments.','Positive relative knower/known/means within containing person, further inspection and separate historical attribution.'),
447:('The token break is only damage and physical fit already performs the intervening trust.','Separated halves refer across absence before reunion.','Kept fracture, particular fit, time and unmanufacturable counterpart.'),
449:('Authored scene supplies an invented ancient tale or unrelated duplicate mathematical proof.','Broken counterpart receives copula/slash formal comparison.','Material recognition and source-specific native formal office retain different warrants.'),
451:('The account can manufacture the future counterpart.','Undertaking precedes availability of physical reunion.','Genuine exposed interval and recognisable possible reunion.'),
458:('Erased-dot QL imagery is ancient Taoist exegesis or every polarity is cancellation.','Two-dot/one-dot/no-dot constructions have different offices.','Healthy signed orientation, cancellation, appropriation and retained-break return remain distinct.'),
462:('Exact Bohr emblem provenance, motto or reproduction has been collated.','Reported armorial emblem is compared with authored dot alteration.','Separate historical witness debt and no invented motto/image.'),
465:('Across-arrangement complementarity equals selection within one measurement.','Two experimentally different offices are compared.','Arrangement versus selecting orientation, neither generic cut nor emblem identity.'),
467:('Physics emblem derives native eight.','Eight determinations retain disclosed and withheld conditions.','Independent experimental/formal physics warrants and native authorial derivation.'),
469:('Every disclosed dependency forces criterion revision.','Competent criterion can expose selecting arrangement.','Correct result under fitting condition, failed arrangement and warranted retention differ.'),
478:('Astronomy proves four institutional rings or this diagnosis verifies all power history.','Neptune/Jupiter/Mercury/corona organise visibility and proximity.','All four particular social offices retained; astronomical image and historical evidence remain distinct.'),
480:('Permitted identity exhausts lived reality, or widening recognition erases the person.','Ledger excludes unenterable interior experience.','Actual suffering/love/understanding and source of identity remain effective.'),
484:('Image establishes particular crimes, universal political history or psychiatric equivalences.','Complete adopted political diagnosis surrounds delegated labour and usurped measure.','Positive costs/source/decision return; precise criminal, historical, clinical and separate telling warrants.'),
489:('Surviving buildings and activity prove free constitutive relation.','Bomb destroys while surveillance maintains city appearance.','Distinct material destruction versus capture in continuing habitat.'),
491:('Counterfeited source-image is identical to monitoring a real person or destroying a city.','Deepfake enters technoscientific capacity.','Three distinct failures retain originating-witness office.'),
495:('Correction necessarily changes the highest evaluator or retained condition proves processing changed.','Reflective encounter receives corrected source/condition.','Proper depth or adequate retained warrant; stricter actual later-inherited change proof remains separate.'),
502:('Finite image-maker may claim divine Self’s office.','God-as-Other receives finite and divine-mind readings.','Distinct registers and source exceeding finite possession.'),
507:('Actual other person is only a disowned ego projection.','Shadow acts within psychic life.','Inner difference and effective interpersonal other keep separate sources.'),
512:('A friend is exhausted by my image or reducible to an inner figure.','Friend’s response changes a shared world.','Actual interlocutor/source and excess beyond my possession.'),
517:('All actual danger is imaginary or every adversary an inner figure.','Denied uncertainty becomes external negative pole.','Specific projection operation differs from an independently actual threat.'),
519:('Four Other offices are fixed determinations or universal person types.','God/Shadow/Friend/Alien are gathered after separate developments.','Distinct ground, psychic, interpersonal and projected-uncertainty offices and source attribution.'),
524:('Return is generic theme and all endings equivalent.','Checkmate, loop, brothers and shoe complete different works.','Work-specific achieved ending and actual kept/erased counterpart and receiving centre.'),
526:('All poems are interchangeable illustrations or brother/figure identity ratified across myths.','Two Ones, faithful definition and Vāk connect particular works.','Complete particular movements and a separate authored relation for cross-story identities.'),
528:('Local functional knowing equals whole lived immediacy, or every reply requires criterion change.','Technical image enters nested Bimba/local triad and containing person.','Real relative offices, present first-person knowing, proper-depth correction or reasoned retention inherited next act.'),
530:('Later corrections authorise unrecorded alteration of verse.','Compilation and journal instructions coexist.','Twenty-three exact utterances and separate interpretive correction office.'),
534:('Unlocated separate raw-site copy means the retained complete compilation is absent or later instructions are substituted verse.','Source-standing locates existing compilation and protected corrections.','Exact received witness, genuine separate missing-site debt, unchanged verse and named correction routes.'),
551:('Further cross-story extrapolations have acquired human ratification.','Source-standing table retains yes/no scopes.','Exact inherited approval boundary without a new human decision.'),
553:('Symbolic affinity certifies books, genealogy, clinical or implemented results.','Final source standing names Singh, Bohr, Giegerich, Venus and technoscience.','Specific historical/passage/experiential/clinical/implementation limits with all positive images intact.'),
}
# Every source witness line is disposed individually against its own complete poem.
for n,line in enumerate(lines,1):
 if line.startswith('[Complete source witness]'):
  title=next(x for x in reversed(lines[:n]) if x.startswith('### FT-P'))
  card=re.search(r'#(taylor-2026-personal-poetry-corpus-q\d+)',line).group(1)
  reasons[n]=(f'{title} is a substituted agent summary or independently upgraded external quotation.',f'Its exact complete verse is followed by its particular source locator {card}.',f'Authorial extraction and direct complete-poem provenance for {title}; this attribution does not stand in for the following operation.')
assert all(x['severity']!='hard' for x in findings)
assert all(x['line'] in reasons for x in findings)
codes={}
for x in findings: codes.setdefault(x['line'],[]).append(x['code'])
save(D/'TAYLOR-IMAGES-QUALIFICATION-REVIEW.json',{'candidate_sha256':h(p),'detector_findings':len(findings),'qualified_exact_units':len(reasons),'protocol':'Three concrete answers for each complete exact passage; quoted sovereign verse is not editorial prose.','rows':[{'line':n,'exact_unit':lines[n-1],'detector_codes':codes.get(n,[]),'stronger_or_mistaken_inference':q[0],'actual_feature_making_inference_live':q[1],'necessary_information_lost_on_removal':q[2],'disposition':'Retain actual source/formal/normative office and specific limit; no blanket guard.'}for n,q in sorted(reasons.items())]})
blocks=lambda s:re.findall(r'(?m)^>.*(?:\n>.*)*',s)
anchors=lambda s:re.findall(r'<a id="[^"]+">',s)
quotes=lambda s:re.findall(r'“[^”]*”',s)
inline=lambda s:re.findall(r'(?<!`)`[^`\n]+`(?!`)',s)
linkpattern=r'\[[^\]]*\]\(([^)]+)\)'; oldtargets=re.findall(linkpattern,before); targets=re.findall(linkpattern,after); missing=[]
for t in targets:
 if t.startswith(('http:','https:','mailto:','#')):continue
 if not (native.parent/t.split('#')[0]).resolve().exists():missing.append(t)
checks={'candidate_sha256':h(p),'native_preimage_still_exact':h(native)==h(a),'frontmatter_exact':before.split('---',2)[1]==after.split('---',2)[1],'all_23_complete_poem_blocks_exact':len(blocks(before))==23 and blocks(before)==blocks(after),'original_curly_quote_strings_retained':all(x in quotes(after)for x in quotes(before)),'anchor_ids_exact':anchors(before)==anchors(after),'six_position_headings_exact':re.findall(r'^## #[^\n]*',before,re.M)==re.findall(r'^## #[^\n]*',after,re.M),'original_inline_notation_retained':all(x in inline(after)for x in inline(before)),'original_link_targets_retained':all(x in targets for x in oldtargets),'links':len(targets),'missing_link_files':missing,'detector_hard':0,'detector_reviews':len(findings),'individual_qualification_units':len(reasons)}
assert all(checks[k]for k in ['native_preimage_still_exact','frontmatter_exact','all_23_complete_poem_blocks_exact','original_curly_quote_strings_retained','anchor_ids_exact','six_position_headings_exact','original_inline_notation_retained','original_link_targets_retained']);assert not missing
save(D/'TAYLOR-IMAGES-LIGHTWEIGHT-CHECKS.json',checks)
u=json.loads((D/'TAYLOR-IMAGES-WHOLE-CHANGED-UNITS.json').read_text()); oldreview=(D/'TAYLOR-IMAGES-before-final-self-public.md.txt').read_text(); oldparagraphs=oldreview.split('\n\n'); newparagraphs=after.split('\n\n'); sm=difflib.SequenceMatcher(None,oldparagraphs,newparagraphs,autojunk=False); returned=[]
for tag,i,j,k,l in sm.get_opcodes():
 if tag!='equal':returned.append({'earlier_complete_paragraphs':oldparagraphs[i:j],'final_complete_paragraphs':newparagraphs[k:l]})
u['candidate_sha256']=h(p);u['final_peer_return']['complete_changed_adjoining_units']=returned
for row in u['units']:
 val=row['new_complete_paragraph']
 if val in oldreview and val not in after:
  for q in returned:
   if val.strip() in q['earlier_complete_paragraphs'] and len(q['final_complete_paragraphs'])==1:row['new_complete_paragraph']=q['final_complete_paragraphs'][0]
save(D/'TAYLOR-IMAGES-WHOLE-CHANGED-UNITS.json',u)
ledgerpath=D/'TAYLOR-IMAGES-SOURCE-READINGS.json'; ledger=json.loads(ledgerpath.read_text()); coverage=B/'argument-local-regime-return/CURRENT-TAYLOR-IMAGE-RECEIVING-COVERAGE.json';ledger['current_argument_receiving_versions']={'file':str(coverage),'sha256':h(coverage),'scope':'Fourteen exact named-reader whole versions; fresh A04/A18/A19 reads and eleven retained prior complete versions. Version equality does not create new whole-book or public closure.'};ledger['final_self_read']={'whole_candidate_before_final_return':'Fresh complete d88-adjacent candidate in0–15500/15500–31000/31000–46500/46500–end. All final differing P19 and three black-sun adjoining units replayed separately.','raw_return':'Protected P19 entire selected authorial turns4/5/65/326/442 reread before positive dependency succession.'};save(ledgerpath,ledger)
manifest={'key':'TAYLOR-IMAGES','native':str(native),'preimage':str(a),'preimage_sha256':h(a),'candidate':str(p),'candidate_sha256':h(p),'pre_edit':str(D/'TAYLOR-IMAGES-PRE-EDIT.json'),'effects_before':str(D/'TAYLOR-IMAGES-effects-before.json'),'source_ledger':str(ledgerpath),'whole_changed_units':str(D/'TAYLOR-IMAGES-WHOLE-CHANGED-UNITS.json'),'checks':str(D/'TAYLOR-IMAGES-LIGHTWEIGHT-CHECKS.json'),'qualifications':str(D/'TAYLOR-IMAGES-QUALIFICATION-REVIEW.json'),'status':'Stable complete non-live source/public operation; final independent adjoining replay pending','protected':'All23 verse blocks exact; raw authorial text/NOTES/HISTORY/manuscript/48movements/tools/tests/generated untouched','limits':'No new human ratification or historical/clinical/optical/implemented-result verification; source-specific boundaries individually retained.'}
save(D/'TAYLOR-IMAGES-CANDIDATE.json',manifest)
print(json.dumps(checks,indent=2))
