# Execution ledger — Subject and bounded horizon

Two complete non-live source-first drafts at exact hashes in CANDIDATES.json follow retained preimages, native effects4 and actual whole generating/receiving source reentry described in PRE-EDIT-RECOVERY.md. Effects181/174paths were reopened as bytes, not accepted en masse.

C01: Presentact/definedasymmetry→situatedselfing→intrinsiclivingreflexivity→completeeight/personedworld→recognition keeping correction/source relation active. Positive recursive local knower/means/known within person/Life joins the unobjectifiable immediacy condition rather than replacing it. A/C/schema/status/page duties become actual cut, identification, answeringOther, dependence and subject-return operations.

C15: Positiveboundedcapacity→fivecontractedpowers→universalI-this versus localappropriation/primordialrecognition→memory/recomposition/goals→actualhorizon/authority→boundedbody/sourceopening/situatedtopos commitment with warrantedcorrection orreasonedretention inheritednextact. Historical Saiva, Neumann transmitted image and native uroboric relation remain distinct.

Both complete final drafts were selfread. All32 links resolve with unchanged native reader rules and preserve exact original resolved target sets. Metadata/headings/curlydouble quotations/inline notation remain exact. Native source/history/clinical/quotation/runtime bounds remain individually stated in the pre-edit record; no missing source is manufactured. Independent complete cold review remains; parent owns unchanged native checks and publication.

Independent complete old/new source/public cold review accepted C01 `7f5ef2bc…` and C15 `5c300d08…`, with exact peer receipt `working/canonical-argument-recovery-2026-09-25/foundation-closure-2026-10-01/argument-first-person-return/INDEPENDENT-CONCEPT-SUBJECT-HORIZON-TWO-REVIEW.json` SHA-256 `198aed80c8e387baea1883c9f6a8f50cf3d8cb114f1a8a21c31fdedbf149d654`. Both final candidates remain frozen and NON-LIVE for parent unchanged validation, inclusion and publication. No new historical quotation, external book, clinical or runtime standing follows from this acceptance.
