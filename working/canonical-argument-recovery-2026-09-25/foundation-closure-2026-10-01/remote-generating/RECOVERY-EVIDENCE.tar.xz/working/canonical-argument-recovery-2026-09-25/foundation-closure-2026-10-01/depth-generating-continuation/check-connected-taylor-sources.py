from pathlib import Path
import json,hashlib,re,importlib.util,sys,dataclasses,difflib
R=Path('.').resolve();B=Path('working/canonical-argument-recovery-2026-09-25/foundation-closure-2026-10-01');D=B/'depth-generating-continuation'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
p=D/'POETRY-SOURCE-candidate.md.txt';s=p.read_text();s=s.replace('Its FT-P01–FT-P23 anchors correspond to q001–q023 here','Its `taylor-ft-p01`–`taylor-ft-p23` anchors correspond to q001–q023 here');p.write_text(s)
m=json.loads((D/'CONNECTED-TAYLOR-SOURCE-CANDIDATES.json').read_text());spec=importlib.util.spec_from_file_location('audit',R/'tools/audit-canonical-argument-recovery.py');a=importlib.util.module_from_spec(spec);sys.modules[spec.name]=a;spec.loader.exec_module(a)
for row in m['records']:
 key=row['key'];p=Path(row['candidate']);before=Path(row['preimage']).read_text();after=p.read_text();f=[dataclasses.asdict(x)for x in a.audit_file(R,p.resolve())];save(D/(key+'-DETECTOR.json'),f);print(key,h(p),'findings',len(f));lines=after.splitlines()
 for q in f:print(q['line'],q['severity'],q['code'],lines[q['line']-1])
 missing=[];targets=re.findall(r'\[[^\]]*\]\(([^)]+)\)',after)
 for t in targets:
  if t.startswith(('http:','https:','mailto:','#')):continue
  if not (Path(row['native']).parent/t.split('#')[0]).resolve().exists():missing.append(t)
 wiki=re.findall(r'\[\[([^]|]+)(?:\|[^]]+)?\]\]',after)
 for t in wiki:
  q=Path('submission-package/essay')/(t.split('#')[0]+'.md')
  if not q.exists():missing.append(t)
 blocks=lambda z:re.findall(r'(?m)^>.*(?:\n>.*)*',z)
 oldfm=before.split('---',2)[1];newfm=after.split('---',2)[1]
 if key=='DYNAMICS-SOURCE':newfm=re.sub(r'consumed_by_arguments:\n(?:  - [^\n]+\n)+','',newfm)
 cardfields=lambda z:[x for x in z.splitlines()if x.startswith(('- **Locator:','- **Status:','- **Verification:','- **Source relation:','- **Use boundary:'))]
 checks={'candidate_sha256':h(p),'native_preimage_still_exact':h(Path(row['native']))==row['preimage_sha256'],'original_identity_readiness_frontmatter_exact_except_actual_dynamic_consumer_list':oldfm==newfm,'all_original_complete_blockquotes_exact':blocks(before)==blocks(after),'poetry23_blocks':len(blocks(after)) if key=='POETRY-SOURCE' else None,'original_locator_status_verification_lines_exact':cardfields(before)==cardfields(after),'original_source_link_targets_retained':all(t in targets for t in re.findall(r'\[[^\]]*\]\(([^)]+)\)',before)) and all(t in wiki for t in re.findall(r'\[\[([^]|]+)(?:\|[^]]+)?\]\]',before)),'links':len(targets)+len(wiki),'missing_files':missing,'detector_hard':sum(q['severity']=='hard'for q in f),'detector_review':sum(q['severity']!='hard'for q in f),'raw_dynamics_sha256':h(Path('working/sources-texts-references/Epi Paper Write-ups/Symbolon Dynamics — Archetype, Attractor, and Objective Internality.md')),'no_heavy_jobs':'Only unchanged per-file audit, link/byte/source identity and exact card-preservation checks; parent global checks pending.'}
 assert all(checks[x]for x in ['native_preimage_still_exact','original_identity_readiness_frontmatter_exact_except_actual_dynamic_consumer_list','all_original_complete_blockquotes_exact','original_locator_status_verification_lines_exact','original_source_link_targets_retained']);assert not missing and checks['detector_hard']==0
 save(D/(key+'-LIGHTWEIGHT-CHECKS.json'),checks)
 op=difflib.SequenceMatcher(None,before.split('\n\n'),after.split('\n\n'),autojunk=False);units=[]
 for tag,i,j,k,l in op.get_opcodes():
  if tag!='equal':units.append({'old_complete_units':before.split('\n\n')[i:j],'new_complete_units':after.split('\n\n')[k:l]})
 save(D/(key+'-WHOLE-CHANGED-UNITS.json'),{'preimage_sha256':row['preimage_sha256'],'candidate_sha256':h(p),'units':units});(D/(key+'.diff')).write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=row['native'],tofile=str(p))))
 row.update(candidate_sha256=h(p),checks=str(D/(key+'-LIGHTWEIGHT-CHECKS.json')),status='Whole source-first non-live operation self-read and exact identity/verse/locator/link checks passed; individual qualification and independent cold pending')
 print(json.dumps(checks,indent=2))
save(D/'CONNECTED-TAYLOR-SOURCE-CANDIDATES.json',m)
mp=D/'TAYLOR-IMAGES-CANDIDATE.json';j=json.loads(mp.read_text());rev=B/'concept-aphorism-return/INDEPENDENT-TAYLOR-IMAGES-REVIEW.json';assert h(rev)=='cca55f96341d4db5bb45632e13ca955203629fd0211d0c4f244b4be3710a0342';assert h(Path(j['candidate']))==j['candidate_sha256'];j.update(independent_review=str(rev),independent_review_sha256=h(rev),status='Independent complete bounded source/public operation accepted; frozen non-live parent inclusion pending');save(mp,j)
