from pathlib import Path
import json, hashlib, re, sys, dataclasses, importlib.util

D = Path(__file__).parent
R = Path.cwd()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
spec = importlib.util.spec_from_file_location('canonical_lightweight_audit', R / 'tools/audit-canonical-argument-recovery.py')
m = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = m
spec.loader.exec_module(m)

reasons = {
'AVATAR': [
('Finite form gives', 'A person is complete before any relational presentation or exhausted by the presentation.', 'Finite address makes encounter possible while the named person can answer differently.', 'Constitutive mediation and person continuity beyond an image both remain effective.'),
('Taylor\'s [avatar–image', 'Four offices are four universal historical doctrines or one transmitted story.', 'Four different names meet in a single authored ecology.', 'The attributed local synthesis is distinct from a historical genealogy.'),
('The complete relation articulated', 'Four names or six narrative passages replace the native eight.', 'The ecology receives the full parent and eightfold relation.', 'Full native generation retains its own counted offices.'),
('That occasion preserves', 'The earliest written instruction exhausts intention or situated authority is unreal.', 'Delegation gives a finite representative actual authority.', 'Exact effective office remains answerable to its commission and wider source.'),
('The avatar\'s body', 'The authored avatar relation is established ancient Sanskrit/theological doctrine.', 'The term descent is put to structural work in the local authored account.', 'Primary doctrine/passage warrant remains necessary for that particular historical attribution.'),
('An image makes', 'Causal or epistemic precedence makes the image ontologically self-originating.', 'A reference image occupies a real local Bimba office.', 'Local authority, wider dependence and returned correction retain their distinct respects.'),
('The interpreting agent', 'The person\'s whole knowing relation is exhausted by one local agent or the agent has no relative knower office.', 'A comparing agent discriminates readings through reference, rules and instruments.', 'Knower/means/known recur locally; the complete apparatus is means in the containing person\'s Life.'),
('In [Taylor’s reading of symbolic transformation]', 'A particular portrait is the whole archetypal capacity or libido/desire are interchangeable measured energies.', 'Image, organising complex, archetype and valuation are compared.', 'Their distinct causal/psychic offices and physical measurement criteria survive.'),
('Taylor\'s encounter with [Neumann]', 'Every culture is assigned one ego-development stage or primordial appearance is caused by the later ego.', 'Neumann differentiation is received through the full native operation.', 'Psychological chronology and native first-person ground retain their different offices.'),
('The image\'s efficacy reaches', 'Libido, prāṇa and Śakti name one physical magnitude.', 'Embodied efficacy crosses investment, rhythm and manifestation.', 'The synthesis preserves each operation rather than borrowing another tradition\'s measurement warrant.'),
('[Image, Valuation and Possession]', 'Every vivid beloved image is an idol and every abstract account is immune.', 'The relation tests a successful image\'s acquired authority.', 'Idolisation is source closure; intensity or visual style alone does not establish it.'),
('The image becomes a mask', 'Personhood requires total public exposure.', 'Masks make social participation and protected intimacy possible.', 'Privacy and real participation coexist; mediation is not automatically deception.'),
('The pressure appears when access', 'The authored mechanism is a diagnosis of every bearer or social role.', 'The mask can become an internal governing measure.', 'Specific clinical/general empirical claims require the actual person and situation.'),
('The mask/chameleon seam', 'A general self-administration analogy replaces Fanonian racial/colonial history.', 'Adaptive access can reproduce the measure which excludes the bearer.', 'Specific language, body, coercion and institutional sources remain indispensable.'),
('The series\' concluding', 'Six\'s face proves captivity imaginary, a timecoded finale is newly verified, or numbers Two/Six derive native4+2.', 'The finale joins a sovereign mask with the continuing institutional circuit.', 'Written-witness standing, coercive apparatus and counted dramatic versus native offices remain distinct.'),
('Ovid\'s [Apollo', 'Laurel transformation and nod settle uncomplicated consent.', 'Apollo claims an emblem after the body withdraws.', 'Recoil, apparent assent, prior refusal and their full literary tension are all preserved.'),
('The [biblical Job witness]', 'The friends were always hostile, the whirlwind explains the councils, or later children resurrect the first ones.', 'The councils, accompaniment, arguments, Elihu, whirlwind, rebuke and intercession form one complete telling.', 'Actual sequencing and irreversible deaths retain the ethical pressure of the account.'),
('The defence of the account', 'Sophia is a biblicalJob28 actor or Jung\'s interpretation is the native derivation.', 'The God-image crisis is attributed to Jung§614–617.', 'Biblical telling, Jungian psychological interpretation and Taylor\'s relational reading remain distinct.'),
('The subordinate **deepfake', 'A disclosed fictional image claims the same provenance as a fabricated witness.', 'Counterfeit body/voice/event recording solicits reliance on a false seam.', 'The source claim, not mere synthetic manufacture, determines the counterfeit operation.'),
('The next turn reaches', 'A conceptual second-order dismissal mechanism establishes prevalence, magnitude or a documented media case.', 'The possibility of fabrication becomes grounds to reject a genuine record.', 'The positive mechanism remains while particular empirical claims keep their own evidence requirement.'),
('The [Arbitration', 'The six operations prove common lexical ancestry or Regard replaces the prior operations.', 'Six generated relations carry a consequential settlement and its history.', 'Operational conjunction and different word histories retain their distinct warrants.'),
('The [Symbol / Account', 'A report owns a person\'s standing or credentials alone discharge responsibility.', 'Symbol, account, trust and sourceward consequence are joined.', 'Persons/institutions retain the undertaking and actual returned answer.'),
('An entrusted avatar', 'Every return must revise its criterion or a bearer must endure injury to complete fidelity.', 'Correction, renewed reliance and withdrawal are actual possible answers.', 'A fitting condition can be retained with reasons; refusal remains an effective return.'),
('Taylor\'s four-office ecology places', 'Ancient divine descent is established as a software persona identity.', 'One four-office ecology receives different mythic and media tellings.', 'The comparison develops mediation without inventing that particular historical/technical identity.'),
('Geography and time follow', 'A comparative arrangement establishes historical transmission or one geographical origin.', 'Ovid, Job, television and Neumann meet in a2026 authored comparison.', 'Literary/dramatic places, source objects and reception chronologies keep separate identities.'),
('[Parātrīśikā-Vivaraṇa]', 'The notebook/selected Aion passages certify precise avatāra/icon history, persona doctrine or fully collated historical quotations.', 'Word/subjectivity and Self/symbolic totality do actual neighbouring work.', 'Introduction versus commentary and the specific unsupported doctrines/quotation acquisitions stay bounded.'),
],
'JIGSAW': [
('Frank Taylor’s travelling image', 'Illustrative traveller actions are reported events or a newly recovered ancient myth.', 'An authored travelling image reconstructs its existing puzzle.', 'Authorship and the continuity of the same puzzle remain explicit.'),
('[Manifold charts]', 'Several opinions automatically constitute a smooth manifold atlas.', 'Charts/transitions give an exact mathematical neighbour.', 'Specified domains, inverse maps and regularity are actual conditions of the mathematical claim.'),
('A circle makes', 'Equal numerical velocities in different coordinates necessarily describe the same motion.', 'u3/v1third and2/negative2ninth preserve one height rate through inverse transition.', 'Both coordinate transformation and transformed derivative are retained.'),
('This exactness is the positive', 'A missing inverse is harmless or a coordinate singularity proves the native formal limit.', 'Views can differ numerically yet refer to one point under the transition.', 'Exact transition conditions and the independently sourced act/content formal distinction survive.'),
('The compact circle', 'A drawing is a global chart or a disk cannot have any returning motion.', 'Compactness and contractibility sharpen the flat-puzzle diagnosis.', 'Global chart into an open same-dimensional Euclidean domain differs from drawing; ordinary loops differ from winding classes.'),
('One surface address', 'Winding numbers record the entire journey or timing.', 'A torus loop closes downstairs and ends2,negative1 upstairs.', 'Homotopy class, travelled path and temporal enactment preserve different information.'),
('The finite presentation', 'Four sides/two generators are the cell count or embedded-doughnut metric is the flat quotient metric.', 'Finite quotient and infinite cover are compared through actual counted objects.', 'The cell/edge/winding/metric distinctions keep the construction exact.'),
('The frame first makes', 'Reopening the rule of fit abolishes local judgment.', 'The native questioning relation reaches an encountered mismatch.', 'Valid and invalid transitions remain distinguishable under a warranted rule.'),
('`X/x` carries', 'All infinities, derivatives and journeys are identical through the native symbolic relation.', 'The fullnative field gives a torus lift one precise witness office.', 'Specific mathematical object and wider authorial horizon remain different.'),
('At `1/0`, the achieved', 'Six narrative passages replace or generate the eight theorem determinations.', 'An achieved account returns through inverse parents and distinct chains.', 'Counted native offices and distinct Definition/Quilt/Process/Music returns remain intact.'),
('A [context frame]', 'An agent is only an inert tool at every grain or all stored facts enclose the whole condition of appearing.', 'Local agent discriminates views through maps, memory and rules.', 'Relative functional knower, mediating means, known field and containing person\'s Life preserve their nested offices.'),
('In [Neumann’s', 'Primordial appearing is made by the later ego assembling a standpoint.', 'Differentiation and centroversion give the image an archetypal neighbour.', 'Taylor\'s corrected recognition ground and Neumann\'s psychological sequence remain distinct.'),
('This common archetypal field', 'A shared comparison assigns every culture the same cartographic history.', 'Historical and contemporary accounts are joined in an authored field.', 'Actual geographical setting, historical date and source object remain individually answerable.'),
('The Blue Marble gathers', 'The familiar name selects one NASA frame automatically.', 'The planetary picture has a box-lid/diaphanous hinge.', 'The authored image unit retains a genuine conceptual office without invented mission/asset identity.'),
('As a box-lid', 'A planetary scope gives a view automatic universal authority.', 'The image can settle the scale of count before affected lives answer.', 'Maker, measure and actual situated participant stay available to challenge the frame.'),
('The same image can', 'A specific photograph\'s date/mission/credit/rights are newly verified.', 'Diaphaneity makes a view\'s production and use available.', 'Actual image acquisition remains necessary before attaching an asset; source conditions retain their force.'),
('[Gebser’s aperspectivity]', 'Aperspectivity is merely a synthesis or technically active context is directly Gebser\'s implementation.', 'Perspectival articulation is preserved while exclusive authority changes.', 'Selected historical concept and Taylor\'s constructive contextual participation are separately attributed.'),
('An [image’s authority]', 'A local Bimba is unreal because reflected or becomes self-originating because authoritative.', 'The made atlas gives situated readings a genuine reference.', 'Effective local original and wider source dependence remain active together.'),
('The [Encounter / Region', 'Four generated relations establish one lexical descent of sixterms.', 'Naming/counting/participant reply/account make a planetary claim inspectable.', 'Operational relations do real work while each term keeps its historical warrant.'),
('The reconstructive technical proposal', 'Twelve labels on unchanged outputs perform twelve lenses or one face monopolises Name/Power.', 'A full rotated constellation changes inquiry through its chosen gauge.', 'Lens consequence and both-face whole constellation remain required.'),
('Taylor’s proposed Mapper', 'A nerve is automatically a manifold atlas; a gluing obstruction proves no computation possible or entails an ethical pledge.', 'Five Mapper operations and sheaf data/restriction/compatibility are preserved.', 'Coordinate invertibility, precise gluing hypotheses, actual technical experiment and distinct surety comparison retain their own offices.'),
('The [Homologia / Analogia', 'Common shape proves ancestry/cause or a coordinate system proves the ontology.', 'A specified transformation can preserve local determination and return.', 'Exact operation, analogous respect, genealogy, cause and positive idealist dependence keep separate warrants.'),
('[Bratton’s Agentworld]', 'The brief endorses this particular atlas or proves its deployed success.', 'Divergent models need procedural grammar, representation and a harness.', 'Source scenario and the authored constructive response remain distinct from an implemented comparison.'),
('[Deferential intelligence]', 'Every return requires criterion change or generic retention proves a claimed processing change.', 'Returned evidence reaches the actual condition involved.', 'Warranted relevant correction or reasoned fitting retention enters the next act; the stronger changed-processing claim needs its asserted change.'),
('The box-lid diagnosis', 'Five movement bodies have been newly composed or implementation completed.', 'Map connections retain all five protected routes with positive distinct operations.', 'Only foundational generating map relations are recovered; protected movement bodies and empirical experiments remain deferred.'),
('**Source and implementation standing.**', 'Mathematical validity, authored image, reported event and deployed result exchange their evidence.', 'Exact constructions are received by an illustrative reconstruction and technical proposal.', 'Print/locator/quotation/asset/implementation standing remains precise without source-status labels replacing the operation.'),
]
}

manifest = []
for key in ['AVATAR', 'JIGSAW']:
    p = D / f'{key}-candidate.md.txt'
    s = p.read_text()
    old = (D / f'{key}-before.md.txt').read_text()
    pre = json.loads((D / f'{key}-PRE-EDIT.json').read_text())
    findings = [dataclasses.asdict(x) for x in m.audit_file(R, p.resolve())]
    inline = lambda t: re.findall(r'`([^`\n]+)`', t)
    targets = lambda t: sorted(re.findall(r'\]\(([^\n]+?)\)', t))
    old_math = [x for x in inline(old) if x not in ['human-amplified: yes', 'human-amplified: no']]
    ck = {
        'candidate_sha256': sha(p),
        'native_remains_preimage': sha(R / pre['path']) == pre['preimage_sha256'],
        'frontmatter_exact': s.split('---', 2)[1] == old.split('---', 2)[1],
        'link_targets_exact': targets(s) == targets(old),
        'html_anchors_exact': re.findall(r'<a id="([^"]+)"', s) == re.findall(r'<a id="([^"]+)"', old),
        'mathematical_inline_exact': inline(s) == old_math,
        'curly_quoted_strings_exact': re.findall('“[^”]*”', s) == re.findall('“[^”]*”', old),
        'hard_errors': sum(x['severity'] == 'error' for x in findings),
        'individual_detector_review_candidates': findings,
        'semantic_review': 'Entire old and new whole personally source-compared; all last returned/self-public joins read in complete adjoining paragraphs. Detector counts do not establish source acceptance.',
    }
    for k in ['native_remains_preimage', 'frontmatter_exact', 'link_targets_exact', 'html_anchors_exact', 'mathematical_inline_exact', 'curly_quoted_strings_exact']:
        assert ck[k], (key, k)
    assert ck['hard_errors'] == 0
    (D / f'{key}-LIGHTWEIGHT-CHECKS.json').write_text(json.dumps(ck, ensure_ascii=False, indent=2) + '\n')
    qs = []
    for prefix, stronger, live, loss in reasons[key]:
        ps = [x for x in s.split('\n\n') if re.sub(r'^<a id="[^\"]+"></a>\n', '', x).startswith(prefix)]
        assert len(ps) == 1, (key, prefix)
        qs.append({'candidate_sha256': sha(p), 'exact_paragraph': ps[0], 'mistaken_stronger_proposition_prevented': stronger, 'textual_reason_inference_is_live': live, 'necessary_information_lost_if_removed': loss, 'disposition': 'Retain this source-specific historical/formal/causal/operative condition; no generic standing disqualification of native knowing.'})
    (D / f'{key}-QUALIFICATION-REASONS.json').write_text(json.dumps(qs, ensure_ascii=False, indent=2) + '\n')
    manifest.append({'key': key, 'path': pre['path'], 'candidate': str(p.resolve()), 'preimage': str((D / f'{key}-before.md.txt').resolve()), 'preimage_sha256': pre['preimage_sha256'], 'sha256': sha(p), 'effects_depth': 4, 'effects_before': f'{key}-effects-before.json', 'whole_operation': pre['whole_operation'], 'status': 'Complete NON-LIVE whole source/public operation; self-read/unchanged detector zero hard errors; independent cold review pending.', 'source_ledger': 'AVATAR-JIGSAW-SOURCE-READINGS.json', 'consumer_ledger': 'AVATAR-JIGSAW-DIRECT-CONSUMERS.json', 'qualification_ledger': f'{key}-QUALIFICATION-REASONS.json'})

(D / 'AVATAR-JIGSAW-CANDIDATES.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
(D / 'AVATAR-JIGSAW-MOVED-GOVERNANCE.json').write_text(json.dumps({
    'AVATAR': {'received_amplification': 'yes: quilt four-office ecology, Daphne/Job/NumberSix appointments, category-before-encounter relation and subordinate counterfeit-provenance operation', 'unratified_new_identity': 'no: new Fanonian/biographical amplification or ancient divine descent identified with software persona', 'claim_status': 'Argued remains exact in native frontmatter'},
    'JIGSAW': {'received_amplification': 'yes: travelling reconstruction, BlueMarble hinge, native/Neumann structuration, correctedBimba relation and programme returns', 'new_illustrative_narration': 'no: newly written traveller actions/explanatory phrasing are not reported events or newly ratified symbolic identities', 'claim_status': 'Exact constructions retain their own mathematical proof; relation Argued, technical witness/application Offered as retained frontmatter; independent implementation unperformed'},
    'public_change': 'Administrative approval/evidence-register/carrier duty labels are retained here while complete positive operations act in the public bodies. No new symbolic identity, historical doctrine, quotation or deployed result promoted.',
}, ensure_ascii=False, indent=2) + '\n')
with (D / 'EXECUTION-LEDGER.md').open('a') as f:
    f.write('\nAvatar and travelling jigsaw complete NON-LIVE source/public recovery prepared after retained exact preimages, effects depth4, complete current native and 23 direct argument/concept body re-entries, three earlier actual complete byte-equal transverse carriers and five explicitly deferred protected movement receivers. Actual Native020§8/§9, complete Q27lateJob/deepfake and technical addendum, full relevant myth tellings/houses and exact atlas/core/minute sources govern the operation. Full four-office ecology, all mythic actors/aftermaths, native eight/parents/folds and exact circle/torus/counting equations survive. Relative local judging-knower/means/known and apparatus-in-person\'s-Life are explicit; warranted correction or justified fitting-condition retention enters the next act. Full old/new self-read and adjoining final units completed; source/formal/causal qualifications individually disposed; untouched canonical preimages and zero hard detector errors verified. Independent peer review pending.\n')
    for row in manifest:
        f.write(f"- {row['key']}: `{row['sha256']}`; exact frontmatter, link targets, anchors, mathematical expressions and curly-quoted strings retained.\n")
print(json.dumps([{'key': x['key'], 'sha256': x['sha256'], 'qualifications': len(reasons[x['key']])} for x in manifest]))
