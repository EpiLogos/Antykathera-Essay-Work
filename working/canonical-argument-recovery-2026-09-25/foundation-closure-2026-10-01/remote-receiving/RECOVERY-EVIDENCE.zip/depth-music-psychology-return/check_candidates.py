from pathlib import Path
import hashlib
import importlib.util
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[4]
PACKET = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("depth_native_audit", ROOT / "tools/audit-canonical-argument-recovery.py")
audit = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = audit
spec.loader.exec_module(audit)
manifest = json.loads((PACKET / "MANIFEST.json").read_text())
records, findings = [], []

for row in manifest["records"]:
    before = (ROOT / row["preimage"]).read_text()
    path = ROOT / row["candidate"]
    after = path.read_text()
    local_findings = audit.audit_file(ROOT, path)
    findings.extend(dict(vars(item), key=row["key"]) for item in local_findings)
    frontmatter = lambda text: text.split("---", 2)[1] if text.startswith("---\n") else ""
    formulae = lambda text: re.findall(r"(?s)\$\$.*?\$\$", text)
    quotes = lambda text: re.findall(r"(?m)^>.*$", text)
    missing = []
    for target in re.findall(r"\[[^\]]*\]\(([^\s)]+)\)", after):
        target = target.strip("<>")
        if target.startswith(("https:", "http:", "#", "mailto:")):
            continue
        local = target.split("#")[0]
        if local and not (ROOT / row["path"]).parent.joinpath(local).resolve().exists():
            missing.append(target)
    venue = re.findall(r"(?m)^- \*\*Venue claim — extracted:\*\*.*$", before) if row["key"] == "MATRIX-R22" else []
    navigation = re.findall(r"(?s)<!--[^>]*navigation.*?<!-- /[^>]*navigation -->", before)
    records.append({
        "key": row["key"],
        "frontmatter_exact": frontmatter(before) == frontmatter(after),
        "display_formulas_exact": formulae(before) == formulae(after),
        "blockquoted_source_lines_exact": quotes(before) == quotes(after),
        "venue_quote_exact": all(line in after for line in venue),
        "navigation_exact": all(block in after for block in navigation),
        "missing_markdown_targets": missing,
        "live_preimage_at_check": hashlib.sha256((ROOT / row["path"]).read_bytes()).hexdigest() == row["preimage_sha256"],
        "candidate_sha256": hashlib.sha256(after.encode()).hexdigest(),
        "errors": sum(item.severity == "error" for item in local_findings),
        "reviews": sum(item.severity == "review" for item in local_findings),
    })

(PACKET / "LIGHTWEIGHT-CHECKS.json").write_text(json.dumps({
    "scope": "Eight unchanged native single-file audit_file calls and exact metadata, formula, quote, navigation and target comparisons. No full tests, builders, browser, installation or live producer. Global protected comparison belongs to parent.",
    "records": records,
}, indent=2) + "\n")
(PACKET / "NATIVE-FINDINGS.json").write_text(json.dumps(findings, indent=2) + "\n")
print(json.dumps({"candidates": len(records), "errors": sum(row["errors"] for row in records), "reviews": sum(row["reviews"] for row in records), "missing_targets": sum(len(row["missing_markdown_targets"]) for row in records)}, indent=2))
