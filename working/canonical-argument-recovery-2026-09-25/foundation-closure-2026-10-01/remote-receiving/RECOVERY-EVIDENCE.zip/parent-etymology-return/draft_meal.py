from pathlib import Path
import json,hashlib,difflib
p=Path('working/canonical-argument-recovery-2026-09-25/foundation-closure-2026-10-01/parent-etymology-return');s=(p/'MEAL-before.md.txt').read_text();before=s
old='**Human-amplified: yes** applies to this existing authored relation. Its Argued force concerns the life of knowing; the outline\'s biological and clinical language retains a separate evidential burden.'
new='Knowing becomes formative when received material enters the conditions from which the person judges and acts. The outline’s biological and clinical language retains its separate evidential burden.'
assert s.count(old)==1;s=s.replace(old,new)
old='A29 requires resistance, cost and correction to reach the office that can change the next action. A30 requires contributors to remain more than context for one another.'
new='Resistance, cost and correction reach the office able to change the next action. Contributors remain locally grounded persons whose response can change the shared undertaking.'
assert s.count(old)==1;s=s.replace(old,new)
old='**Human-amplified: yes** applies to that ratified authored operation and its prescribed returns to A29, A30 and A35. It remains strong in its native register.'
new='Delegated work becomes answerable through its returning consequences; shared contributions affect one another’s worlds; the achieved capacity remains sensitive to the origins and lives that sustain it.'
assert s.count(old)==1;s=s.replace(old,new)
old='[A18](../../../../episteme/arguments/A18-Primordial-Symbolon-and-Its-Eight-Determinations.md) and the [eight-determination Matheme](../../../../matheme/ql/eight-determinations.md) retain their sequence, inversions and distinct address systems.'
new='The [primordial Symbolon](../../../../episteme/arguments/A18-Primordial-Symbolon-and-Its-Eight-Determinations.md) and [eight determinations](../../../../matheme/ql/eight-determinations.md) retain the complete sequence and inversions through their respective philosophical and formal articulation.'
assert s.count(old)==1;s=s.replace(old,new)
old='The Meal **returns-to** [A29](../../../../episteme/arguments/A29-Power-Delegated-Labour-Return.md) when received work can change the authority that receives it; **returns-to** [A30](../../../../episteme/arguments/A30-Objective-Co-Internality.md) when shared contributions alter locally grounded worlds without consuming their participants; and **returns-to** [A35](../../../../episteme/arguments/A35-Compassion-Sensitivity-to-Origins-Epi-Logos-as-Vocation.md) when the resulting capacity remains sensitive to the origins and lives that sustain it.'
new='Received work becomes [answerable delegated power](../../../../episteme/arguments/A29-Power-Delegated-Labour-Return.md) when its consequence can change the authority receiving it. Contributions enter [reciprocal world-constitution](../../../../episteme/arguments/A30-Objective-Co-Internality.md) when their participants retain locally grounded worlds and can contest the shared account. The achieved capacity becomes [compassionate sensitivity to origins](../../../../episteme/arguments/A35-Compassion-Sensitivity-to-Origins-Epi-Logos-as-Vocation.md) through its continuing relation to the lives and conditions that sustain it.'
assert s.count(old)==1;s=s.replace(old,new)
assert before.split('---',2)[:2]==s.split('---',2)[:2]
(p/'MEAL-candidate.md.txt').write_text(s);m=json.loads((p/'MEAL-PRE-EDIT-RECOVERY.json').read_text());m['candidate_path']=str(p/'MEAL-candidate.md.txt');m['candidate_sha256']=hashlib.sha256(s.encode()).hexdigest();m['status']='Complete non-live candidate; independent source/whole cold review pending';(p/'MEAL-CANDIDATE.json').write_text(json.dumps(m,indent=2)+'\n');(p/'MEAL-candidate.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='before',tofile='candidate')));print(m['candidate_sha256'])
