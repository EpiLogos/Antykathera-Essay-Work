# Independent formal-neighbour review

Five complete final candidates are accepted at the hashes in the JSON companion. Whole proofs and complete changed old paragraph units were read; this does not claim fresh whole old-preimage, whole external-book or historical quotation/reception closure.

The quaternion opening first failed because source-admission language displaced the native operation. The retained before-draft and parent return preserve that finding. Its final whole body now develops the two qualitative poles, four ordered relations and obverse orientation, with the algebra/native mapping condition explicit. The formal tables, groups, residue operation and divisor proof keep their distinct domains.

The JSON records each positive operation and exact source/formal limit. Local heavy checks remain held; parent owns integration, unchanged remote checks and publication.
