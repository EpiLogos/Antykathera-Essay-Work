---
title: "A21 — Individuation / Recognition"
record_id: A21
record_type: argument
register: episteme
claim_status: Argued
source_relation: "Argued psychological and recognitive homology; source traditions distinct"
---

# A21 — Individuation / Recognition

<!-- paired-field-navigation -->
[Argument field](README.md) · [Other face: A21′ — Individuation with Recognition](../conjugate/A21-prime-Individuation-with-Recognition.md) · [Shared A/C root](../conjugate/AC.md)
<!-- /paired-field-navigation -->

## #0

Individuation makes a local subject-position capable of bearing the relations through which it is itself. The person becomes more specifically this life and less defensively separate at once. Recognition is the return by which an achieved determination becomes known in relation to its source and history. Their meeting is necessary because [[A19-Complex-as-Local-Arbitration-Regime|A19]] has shown a local complex claiming whole-field jurisdiction and [[A20-Image-Valuation-Possession|A20]] has shown the image replacing its living source. Their histories cannot simply be discarded; the office through which they act must change.

Q27 §6 develops becoming undivided within a psyche already differentiated among agencies. Its wording of indivisibility is developmental recovery, not an independently verified Jung quotation. [[symbolon/episteme/sources/psychology/jung/jung-1978-aion-cw9-2/SOURCE|Aion’s source house]] sources the Self/shadow and symbolic-totality context through consulted-carrier paragraph locations; selected-printing collation and quotation readiness remain Open. The argument retains its force without assigning an unverified sentence to Jung.

## #1

Ego, complexes, archetypal powers, collective inheritance and Self have different scopes. Their plurality does not require that every agency be interchangeable. The Self's whole-forming office is not the largest complex, a stronger persona or a chief executive presiding over lesser workers. A local centre relates to the whole without containing it; its individuation cannot therefore consist in conquering every other agency.

[[symbolon/episteme/sources/internal-corpus/taylor/taylor-2026-symbolon-dynamics/SOURCE|Symbolon Dynamics]] sources the developmental mechanism. A complex supplies recurrent channels of attention and affect. An image gives a particular appearance. A living symbol can alter the organisation through which these channels and appearances are received. Individuation changes their relation, including the relation of the conscious interpreter to what it had excluded. [[symbolon/episteme/concepts/C34-Individuation|C34 Individuation]] defines this reusable movement; [[symbolon/episteme/concepts/C35-Selfing-Self-Subjectivity-Self-Thing|C35 Selfing / Self / Subjectivity / Self-Thing]] qualifies the attempt to make its subject a completed possession.

## #2

The energetic middle is a passage through uncertainty that changes what can count as knowledge on return. Frank's protected encounter with [[symbolon/episteme/sources/psychology/van-eenwyk/van-eenwyk-1997-archetypes-strange-attractors/SOURCE|Van Eenwyk]] sources the authorial known→unknown→known and `x→X→x` movement at pp69–73. The notes' copied quotations remain leads; the QL notation is native authorial language, not Jung's notation.

The returning `x` has not ceased to be particular. A determinate encounter opens it to a capacity it could not exhaust, and that enlargement returns into a life with a history, body, commitments and further acts. Merely replacing a personal name by a universal name would omit the movement. So would repeating a theory of recognition while leaving one's criterion untouched. The `IS→AM` return requires the identifying act itself to be at stake: the account concerns the one who is giving it.

A basin can preserve enough organisation for a trajectory to continue, while its boundary allows a new regime to become possible. The psychic model therefore holds continuity and transformation together. It supplies no clinical rule that destabilisation is always beneficial. Its argument is that restoring the former organisation cannot be the sole criterion when that organisation was the very closure the encounter exposed.

## #3

Recognition changes possession into participation. An excluded affect can become intelligible as part of a history; a projected image can be recognised as one's image without denying the Other; a local competence can be retained while its sovereignty ends. Integration names increased ability to bear these differentiated relations. Reconciliation names a changed relation between what had been estranged. Recognition makes the relation to source and history active. A synthesis names an achieved composition; it does not guarantee that any of these changes has occurred.

[[symbolon/episteme/concepts/C36-Complexio-Oppositorum|C36 Complexio Oppositorum]] defines the capacity through which opposed determinations transform their containing field. [[symbolon/episteme/concepts/C64-Paradox-Transforming-the-Containing-Field|C64 Paradox]] extends that change beyond choosing one existing pole. The result is not a final agreement that abolishes all further difference: the containing relation can become more capable precisely because neither term has been deleted or made absolute.

## #4

[[A09-Tattvic-Differential-Field|A09]] grounds the separately recovered Śaiva field in which recognition returns through differentiated manifestation. The present comparison is operational: an achieved determination can return without erasing its determinate history. It does not turn Śaiva pratyabhijñā into a psychological treatment, nor make Jung's Self a historical synonym for Śiva. [[symbolon/episteme/concepts/C19-Pratyabhijna-Recognition|C19 Recognition]] keeps that source-sensitive return available for reuse.

The [[symbolon/episteme/etymologies/arbitration-hybris-regard-anamnesis/WHOLE-FIELD|Arbitration whole field]] derives **Resolution-in-Reconciliation → Anamnesis / Recognition / Return**. A resolution can be retained, narrowed or resituated by remembering how it arose. The previous cycle remains consequential. Greek anamnesis, Sanskrit recognition and Jungian individuation retain separate genealogies; their relation here is register 3 operational homology.

## #5→0


The [zero–subject history](../histories/traditions-and-disciplines/zero-subject-advent/DEVELOPMENT.md#3--psychic-fact-changes-the-investigators-relation) **compares** this return. The selected Jung CW11 §§755–757 place the God-image with the archetype of the Self while distinguishing it from the whole unconscious. These bounded psychological claims keep ego, complex, image and Self apart; they do not verify a theological event or identify all unconscious processes with native Subject. The current Aion return retains its separate selected source and symbolic office.

[Māyā — eye, veil, frame and horizon](../../mytheme/worlds/frank-taylor/maya-eye-veil-frame-horizon/WHOLE.md#maya-recognition-return): Recognition through the veil **figures** a differentiated life becoming capable of a changed relation. The knower still selects, remembers and acts, while the achieved position ceases to claim that it originates the whole. This resituation returns into the next encounter, where an affect or another person’s answer can matter differently. The authored individuation operation preserves its particular history and does not identify Śaiva recognition with a psychological treatment.

The [Apollo–Dionysus–Daphne whole](../../mytheme/worlds/frank-taylor/apollo-dionysus-daphne/WHOLE.md#apollo-diaphaneity-return) **figures** recognition through a differentiated person whose form can receive participation and another centre’s response. History, body and responsibility remain effective within the changed relation. Daphne’s alterity requires this particular aperture to survive the opening through which integration becomes possible.

The [Meal whole](../../mytheme/worlds/frank-taylor/meal-epistemic-metabolism/WHOLE.md#meal-logos-health-return) **figures** integration through the difference between carrying information and having its encounter change attention, judgment and response. Satiety marks enough assimilation to act; renewed hunger begins from the capacity that act has changed. The receiver’s history remains operative in recognition, with no therapeutic outcome inferred from the food-image.

The [Mother, Assumption and chiasm whole](../../mytheme/worlds/frank-taylor/mother-assumption-chiasm/WHOLE.md#mother-image-recognition-return) **figures** recognition as a transformed relation to embodied dependence. The body that bears differentiation remains present when the whole receives it; recognition increases the capacity to sustain that relation without possessing its source. The nourishing/devouring–need/Desire identity stays a candidate beyond this established chiasm.

[Job’s intercession and return](../../mytheme/worlds/biblical/job/WHOLE.md#job-intercession-return) **figures** recognition through a changed relation among speakers. The witness acquires a consequential mediating office while remaining distinct from its source; the renewed household retains the earlier losses within the account. The whole returns a differentiated life to the encounter which altered it.

Neumann's sequence carries separation through both parental powers, liberation and transformation into centroversion. The differentiated centre returns able to receive what changes it while retaining its capacity to respond. The relation **returns-to** [the complete Neumann whole](../../mytheme/archetypal-ground/neumann-images/WHOLE.md#neumann-hero-centroversion). The creature returns differentiated and receptive to another encounter; recognition changes what its achieved coherence can receive. This **returns-to** [the uroboros whole](../../mytheme/archetypal-ground/uroboros-trickster/WHOLE.md#uroboros-return).

Q27 §9 extends the test into cultural individuation. A culture individuates where its images can be recognised as images, its measures as measures and its institutions as instituted — real forms whose authority can become answerable to the relations that produced them. State, Church, Humanity or Platform repeats inflation when one determinate centre claims to be the Subject of the whole culture. Cultural individuation therefore means increased capacity to carry internal difference and return, not installation of a larger ego.

The agentic extension asks the same operational question at a different grain: does a local formation become more legible in its histories, tools, exclusions, collaborators and purposes, and can encountered difference alter that organisation? Greater persona consistency can preserve a contraction. Individuation is present where the relation to constitutive dependence becomes more explicit and more capable of transformation.

The agentic extension similarly asks whether a local formation becomes more legible in its histories, tools, exclusions, collaborators and purposes. [[symbolon/episteme/sources/media-technology-philosophy/bratton/bratton-2026-agentworld-brief/SOURCE|Agentworld]] compares constituted agency and interaction surfaces, whose multiplication does not settle the number or presence of phenomenal subjects. Greater persona consistency can preserve a contraction; encountered difference must be able to alter its organisation for the proposed functional analogy to carry weight.

[[A27-Self-and-Other-Unity-without-Possession|A27]] returns the interpersonal consequence: recognising the model's conditions also makes room for the Other to answer beyond it. The particular subject comes back capable of a wider relation, not relieved of its particular responsibilities.

[the Prisoner whole](../../mytheme/worlds/british-television/the-prisoner/WHOLE.md#prisoner-degree-absolute-return) **figures** recognition through the encounter with Number One's mask and Six's own face after the ordeal of *Once Upon a Time*. The demand for an external sovereign returns upon the demander without making the Village's coercion imaginary. The ensuing escape and return home leave a relation still to be lived. Recognition changes participation in the governing image; it does not enthrone the ego as the recovered owner of the whole.

The [complete Aion telling](../../mytheme/worlds/analytical-psychology/jung-aion-fishes-christ-antichrist-alchemy/WHOLE.md#aion-differentiated-return) **figures** differentiated return through the initial ego/Self inflation problem and the final quaternio circulation: Jung’s A/B/C/D process changes an unconscious totality into a conscious one (CW9ii §§43–49, 408–413). His explicit modern reconstruction of the Shadow Quaternio keeps historical reception visible. The native x→X→x and IS→AM derivations remain Taylor’s; the “becoming indivisible” attribution remains separately unresolved.

The [Psychology development](../histories/traditions-and-disciplines/psychology/DEVELOPMENT.md) **historicises** differentiated recognition through ego/Self inflation, autonomous dialogical positions and the changing interpreter. Aion’s sixteen consulted passage maps now distinguish symbolic and historical operations; selected-printing and quotation debts remain separate from the Argued return.


The [Indian philosophy companion](../histories/traditions-and-disciplines/indian-philosophy/DEVELOPMENT.md#4--recognition-returns-through-the-life-that-has-become-finite) **compares** Śaiva recognition and psychic individuation through their distinct source carriers. The return preserves this particular life and native X/x while quotation and edition work remain separately owed.
