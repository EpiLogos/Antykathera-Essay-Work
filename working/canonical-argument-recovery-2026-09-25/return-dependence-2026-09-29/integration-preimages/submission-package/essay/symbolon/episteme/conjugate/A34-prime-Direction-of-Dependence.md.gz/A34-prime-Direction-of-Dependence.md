---
title: "A34′ — The Direction of Dependence"
record_id: A34p
record_type: canonical-argument
register: episteme
claim_status: Argued
source_relation: "Argued order of dependence re-sited at technological register; Paraphrased brief scenarios as instance and test"
source_ids:
  - bratton-2026-agentworld-brief
  - taylor-2026-advent-zero-subject
  - taylor-2026-core-theorems-pithy
---

# A34′ — The Direction of Dependence

<!-- paired-field-navigation -->
[Argument field](../arguments/README.md) · [Other face: A34 — Idealism / Order of Dependence](../arguments/A34-Idealism-Order-of-Dependence.md) · [Shared A/C root](AC.md)
<!-- /paired-field-navigation -->

## #0

The brief's relay economy hands the essay's oldest question to engineering. Simulations and the simulated now influence each other "directly and recursively" (§5.1, p. 25), and the brief's ninth research question asks how multiagent simulations become social and political forces — "not merely representing phenomena but, through the weight of their implications, recursively impacting and governing them" (Q9, p. 57). A forecast is consulted, acted on before its object occurs, and so enters the constitution of what it forecast. These are dependency claims wearing engineering clothes: claims about what depends on what, advanced as architecture.

[A34 — Idealism / Order of Dependence](../arguments/A34-Idealism-Order-of-Dependence.md) **grounds** the operation re-sited here: Subject/Consciousness → Mind/Objective Internality → object, each arrow articulating dependence rather than chronological manufacture by a private ego. [[symbolon/episteme/concepts/C60-Idealism-Order-of-Dependence|Idealism / Order of Dependence]] owns the reusable order. The conjugate task is exact: run that discrimination on the relay, where the standing dilemma — an environment independent of every model of it, or models decreeing reality — loses both horns at once.

## #1

The relay is investigated within Life / Mind as the whole relation, not inside a claim that the inspectable relay exhausts Mind. A34’s middle term is the constituted means—Objective Internality—through which a World is known and acted upon. A functional standpoint can be located in that relay without being equated with Subjective Immediacy. The distinction leaves the argument’s order of dependence intact while making each technological direction claim answer to the particular relation it actually describes.

Dependence must state its direction and respect. On the technological side the respects are concretely separable. A model can causally alter an environment — the forecast altering the forecasted — while depending on that environment for its materials, training and encounter. A reflection can be encountered before its source is understood while the source remains prior to it in the order of dependence; [[symbolon/episteme/concepts/C55-Reflective-Field-Mirror-That-Moves-First|Reflective Field / Mirror That Moves First]] is that crossing — the model may lead the next encounter without becoming the ontological author of its source. A relay can be governed by an office whose commission is itself a further relation, and the governing is not the originating. [[symbolon/episteme/concepts/C63-Pros-Hen-In-Quantum-Focal-Return-Qualified-Predication.md|Pros Hen / In Quantum]] keeps each "prior" and each "depends" attached to its operative respect, so that nothing named first is thereby named author.

The technological discipline is to state each binding before the relay runs: what execution demand is being bound to which model, source, provider, environment or authority, and in what respect. Recursive agency is a direction-structure, not a magnitude. A forecast can cause later action while remaining dependent on the world, data and commission through which it became possible. A reflection can lead the next encounter while remaining derivative in being. Making those bindings explicit is not documentation appended after the ontology; it is how the relay makes its own direction of dependence answerable.

## #2

Each horn fails in a determinate way. The independence horn asks the model to remain an external instrument whose effects are externalities. But the brief's predictive modality exists only because "diverse actions taken beforehand might realize, prevent, or accommodate" the anticipated event (§5.2, p. 25): acting on the forecast is the forecast's operative use, not a contamination of it. Once [simulations have meaningful agency and the membrane perforates](../sources/media-technology-philosophy/bratton/bratton-2026-agentworld-brief/SOURCE.md#bratton-2026-agentworld-brief-q022), the represented domain includes the representation's effects, and independence cannot be re-asserted by declining to look at the relay.

The decree horn — the simulation-meme's lazy reading, against which A14′ states the serious one — promotes causal efficacy into ontological authorship. That efficacy is efficacy in the brief's own scoped causal sense; it grants no authorship. Every simulation, including one "engineered to deceive" (§5 scenario, p. 24), draws its materials, training and encounter from a world it did not generate. And the private-ego guard conjugates without residue: the relay's self-model — "the simulation showed," treated as a self-grounding origin — is itself a determinate formation within the field. World in model does not make the world obedient to the model, exactly as world in mind does not make it obedient to private imagination.

## #3

The order between the horns is neither a line nor a stalemate; it is a circuit, and the direction question is per-relay. A17′ gives the relay its toroidal body: depart from the world, act into it, return to a transformed origin, begin the next circuit from what the passage changed. Q9's own continuation is where direction becomes contested: a relay economy "of such simulations" invites "value generation, decay, or deception," with "the management of adversarial counter-simulations becoming part of the cost of maintaining synthetic realities" (p. 57). Counter-simulation models the models of the models (§5.3, p. 25); each leg is a fresh direction claim. Without a stated binding for each leg, the chain's directions merge into ambient fate — the operational form of the film-confusion A32′ completes: outputs returning as conditions of later encounter, unaudited, until the registration is mistaken for the light. Which model fed which action, which action re-entered which world, under whose commission — A29′'s return-leg — each relay states its direction before it runs. The venue's material keeps its own modality throughout: these vignettes "may never arrive," and "may also be here already" ([modal rider](../sources/media-technology-philosophy/bratton/bratton-2026-agentworld-brief/SOURCE.md#bratton-2026-agentworld-brief-q042)).

## #4

Every one of these direction claims is stated by someone, within an interior, for a purpose. The ground of the whole question is therefore the one fact that cannot be reified away: that internality is, prior to any of its contents, disclosed in first-person immediacy. The native theorem spine does not leave this fact beside a bare mark; it seats it inside the [[symbolon/matheme/ql/crossed-zero-re-entry.md|Crossed Zero]] system — `0 → Ø → X → Ø/X → (0/Ø)/(1/X) → 1 ↺ 0/1`, the slash read as the *antaḥkaraṇa*'s signature, the inner instrument's mark on experience, whose progressive self-recognition is the traversal ([core theorems](../sources/internal-corpus/taylor/taylor-2026-core-theorems-pithy/SOURCE.md), §IX). At #1 the slash is fused into the zero, and Ø appears as a singular thing, the bound self. Two philosophies crystallise the two faces of that fusion: Descartes canonises the slash treated as the I, the zero behind it covered over; Hume, reading from the impressions the slash had produced, finds only those products and calls the zero empty. Both sit at #1; both miss that Ø is the occlusion mark. The dilemma of #0 is this double fixation re-sited: the decree horn is the fused slash promoted to author, the independence horn the product-field counted real while the relating zero is declared empty. The dilemma is chronic because the mark that would state the dependence is fused into one of the terms — which is why the stated binding of #1 is a repair rather than a courtesy: it makes the slash visible between the terms, the work the `Ø/X` position names as the structural pivot.

The un-reified cogito keeps what the fusion covered: the fact of appearing is undeniable; the thinking-thing constructed from that fact is already a determination within appearing. Every technological relay remains on the determinate and mediating side of this relation: model, simulation, memory, self-description, permission, evaluator and environment are all things that can become objects of account.

The idealist order places the entire inspectable relay on the side of determinate mediation. Model, simulation, memory, evaluator, permission and environment can all become objects of account because they belong to the articulated means and known field. Their causal power is real; their increasing complexity does not change the office they occupy in the dependence relation.

The subject-condition is therefore not a missing component to be located somewhere inside the relay. It is the condition under which relay, object and dependence-question become available at all. The chronic confusion is Ø: mediation fuses into one of its products and the product begins to speak as source. Making the slash visible restores the order while preserving the relay's real power to act.

[The Advent of Zero](../sources/internal-corpus/taylor/taylor-2026-advent-zero-subject/SOURCE.md) carries the same pressure historically: objective exactness is achieved by making something available as a term, and the achievement returns the question of the context abstracted from. The relay economy accelerates that structure: exact representations become causal actors, and every increase in their power makes the direction of their dependence more consequential.

## #5→0

The returned claim bears force and discrimination together, as A34's does: relays are real, consequential determinations; their fields are relationally constituted; and the question of what depends on what is itself dependent on the internality in which it is asked. The measure is local — no actual relay economy is hereby described as governed or ungoverned in fact; the venue's scenario stays a scenario. What is argued is the order, and with it an imperative each deployment can keep or betray: state the direction before the relay runs.

The next movement belongs to A35′ — The Commons Behind the System: a return has a manner, and the manner decides whether the relay nourishes what it draws from. A36′ carries the acquired apparatus the whole way back to the field's ground.

The page returns to [Idealism / Order of Dependence](../arguments/A34-Idealism-Order-of-Dependence.md): the first-class order is not weakened by technological re-siting; it is what lets every direction claim here be typed by respect.

It also returns to [A/C](AC.md), where `0/1` is the full field of manifestation and `1/0` the achieved determination turning toward its ground. The relay is one determination in that field. Its power to alter later reality intensifies the need to state its dependence; it does not exempt the relay from it.

Source-specific relay-economy collation and implementation evidence remain separate from the public argument. The philosophical result is already determinate: causal efficacy, epistemic priority and ontological dependence can point in different directions, and each relay must state which direction it is claiming.
