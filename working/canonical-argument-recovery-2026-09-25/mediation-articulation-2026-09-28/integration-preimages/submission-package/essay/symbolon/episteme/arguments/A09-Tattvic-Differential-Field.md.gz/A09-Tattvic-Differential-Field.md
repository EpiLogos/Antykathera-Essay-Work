---
aliases:
  - "Tattvic Differential Field"
  - "Tattvas as Differential Field"
  - "36 Tattvas"
record_id: A09
register: "episteme"
claim_status: "Argued"
source_relation: "Argued from native sixfold contraction; Paraphrased source-specific tattvic exposition; Offered/Argued gnomonic cross-reading"
---
# A09 — Tattvic Differential Field

<!-- paired-field-navigation -->
[Argument field](README.md) · [Other face: A09′ — The Stack as Descent](../conjugate/A09-prime-The-Stack-as-Descent.md) · [Shared A/C root](../conjugate/AC.md)
<!-- /paired-field-navigation -->

## #0

The tattvas give differentiation a genealogy: a luminous field becomes a subject/object seam, a bounded horizon, an inner instrument and a material world without creating a second reality outside itself. Anuttara names the field for which no external measuring object stands outside. This beginning matters to every subsequent contraction: what becomes limited is a power of the field, and the limit remains effective within it.

This makes A09 one of the essay's deepest accounts of **paradigmatic existence before explicit paradigm**. A Life does not first stand outside a complete world and then adopt a worldview about it. Its powers, limits, means of discrimination, inner instrument, temporal order and material situation participate in the very form in which a world becomes available. [C41 — Objective Internality](../concepts/C41-Objective-Internality.md) develops the authorial generalisation as lived/enacted paradigm; the tattvic account remains a specific Śaiva genealogy, not the historical source of the modern term.

## #1

Śiva–Śakti distinguishes luminosity and its self-articulating power. Prakāśa makes appearing possible; vimarśa is the awareness through which appearing can be known, distinguished, joined and withdrawn. [A05](A05-Prakasa-Vimarsa.md) restores Dyczkowski's mirror contrast: the reflected display of an inert crystal does not know its display. The tattvic descent depends on active self-articulation, not a succession of objects deposited before an unchanged spectator.

[Dyczkowski](../sources/indian-philosophy/dyczkowski/dyczkowski-2000-doctrine-vibration/SOURCE.md) p.75 distinguishes two axes of this activity. Vertically, manifestation and withdrawal articulate the movement between unity and diversity. Horizontally, awareness goes towards and returns from its object in each perception. Will, knowledge and action generate, sustain and annul dimensions of experience; they are phases of the living movement through which the levels operate. Frank's preserved source-note request for nested co-internality and causal interrelation belongs here: an effect remains within the power that differentiates it, and an act of perception recapitulates the relation rather than merely looking at a finished cosmological inventory.

## #2

Sadāśiva and Īśvara give the field inverse universal readings: “I am this” and “This am I”, `0/1 ↔ 1/0`. The reversal changes the direction of apprehension within one field. Ahaṃkāra can later say “I am this” while appropriating a particular local form. The grammar repeats, but its scope has contracted: a universal orientation and identification with a finite body, role or thought do different work. Keeping the scope explicit explains how the whole becomes locally inhabitable and how local identity can forget its provenance.

## #3

Sadvidyā–Māyā makes the orientation a workable distinction. Māyā is the horizon at which this appears while that is withheld; the withholding lets an agent discriminate and act. Mahāmāyā remains Śakti: revealing and concealing are powers of the same field. The horizon is therefore neither the unobjectifiable Subject nor the hole of a topological picture. In Dyczkowski's source-matched pp.78–79, inner/outer separation is produced through consciousness's creative activity, and external manifestation preserves its internal nature. The experienced world has efficacy.

The [Q27 correction](../../../quilt/27-07-26-QUILTING-FOR-FULL-ARGUMENT.md) gives the lived operation through the sleeper who forgets sleeping: that forgetting lets a dream count as immediately real. Dream shows why objective need not mean externally material; the example does not make every waking distinction fictitious. Recognition changes the relation to the horizon through which experience occurs.

## #4

The kañcukas contract efficacy, knowledge, desire, time and order into the finite parameters of a context. Puruṣa is the point for which this field is mine; antaḥkaraṇa determines, appropriates and coordinates within it. Buddhi, ahaṃkāra and manas retain their distinct functions. The [Sāṅkhya source](../sources/indian-philosophy/isvarakrishna/isvarakrishna-colebrooke-wilson-1837-sankhya-karika/SOURCE.md), kārikās XXIII, XXIV, XXVII and XXIX, supplies the functional triad; XIX qualifies it with the passive witness. Those are Sāṅkhya determinations, not a substitute primary Trika inventory.

The recovered gnomon makes the comparison precise:

```text
36 − 25 = 6² − 5² = (6 − 5)(6 + 5) = 11 = 5 + 1 + 5.
```

A row of five and a column of five meet at one corner to complete the larger square. The cross-reading places five pure powers and five contracted powers around the Māyā hinge, above the twenty-fivefold Sāṅkhya apparatus. Its yield is a relation between the differentiated apparatus and its genesis through contraction. The arithmetic is exact; the mapping is Offered/Argued. It neither attributes square arithmetic to Abhinavagupta nor assigns every tattva a proved coordinate in a six-by-six table. The six-turn derivation does not depend on that stronger identification.

## #5→0

[Māyā — eye, veil, frame and horizon](../../mytheme/worlds/frank-taylor/maya-eye-veil-frame-horizon/WHOLE.md#maya-native-archetypal-field): The complete Māyā whole **figures** the order in which manifestation becomes inhabitable and returns. Anuttara/Paramaśiva retains the unobjectifiable opening; Māyā is the measure-field wound around it. Limited agency, knowledge, desire, time and order give the bounded position effective capacities, within which the inner instrument acts. Recognition precedes ego appropriation in the author’s Neumann correction and returns through the full native eightfold with its inverse parents intact. The Śaiva, archetypal and native appointments retain their different provenance.

The [Mother, Assumption and chiasm whole](../../mytheme/worlds/frank-taylor/mother-assumption-chiasm/WHOLE.md#mother-native-return) **compares** manifestation and changed recognition through a maternal body retained in its return. This crosses into tattvic differentiation at the point where locally determinate life keeps its source relation. Mary receives no fixed tattva assignment, and the Christian, Śaiva and native sequences retain their own provenance.

Taylor's correction of Neumann's ego-first reading locates recognition before appropriation. The finite knower and inner instrument arise within the field whose recognition they cannot retrospectively originate. The relation **returns-to** [the complete Neumann whole](../../mytheme/archetypal-ground/neumann-images/WHOLE.md#neumann-world-parent-separation). The retained opening and the measure wound around it distinguish Anuttara from Māyā through the complete authored relation. This **returns-to** [the uroboros whole](../../mytheme/archetypal-ground/uroboros-trickster/WHOLE.md#uroboros-interposition).

Pratyabhijñā returns the contracted field to recognition of its provenance while preserving the distinctions through which it lives. The movement runs back through an effective world, an inspectable instrument, a measuring horizon and inverse orientations to the power already active within them. It reverses amnesia rather than differentiation.

This is the pressure passed to Objective Internality and the computational register: memory, prompt, model, tools, policy and judgment can constitute an operative interior whose determining activities are inspectable. Their significance is precisely that they make **pramāṇa**, the mediating means, technically tractable. A09 supplies the genealogy of contraction; A26 develops context-world constitution; A14 follows the repeatable processes through which those conditions become consequential. The technical field does not need to be inflated into the knower-pole to carry this philosophical force.

The restored S field now receives this genealogy without converting products into tattvas. **S0–S5 are not a six-item substitute for the thirty-sixfold field.** They are six whole aspects through which a finite Objective Internality can be articulated once worldhood has become operative: [Central](../products/S0-Central.md) carries meaningful continuity within the contracted history; [Actuation](../products/S1-Actuation.md) carries the living events by which differentiation becomes consequential; [AIKit](../products/S2-AIKit.md) carries the apportioned horizon of powers; [Software Factory](../products/S3-Software-Factory.md) carries transformation from possibility into changed form; [Workcell](../products/S4-Workcell.md) carries concrete being-there, resistance and availability; [Quaternal Logic](../products/S5-Quaternal-Logic.md) carries the relation of these finite distinctions to containing wholes. Their composition is one engineered paradigm within the general lived pattern C41 names.

The relation is exact at the level of office and bounded at the level of doctrine. Kalā is not “AIKit,” Māyā is not “Workcell,” and antaḥkaraṇa is not a software harness. The tattvic field shows why **finite capacity, knowledge, desire, time, order, instrument and world belong to the constitution of lived worldhood rather than being accessories around it**. The product field asks how an artificial agent's constructed world can make analogous constituting relations inspectable and revisable. The cross-reading is Argued/Offered; the source-specific metaphysics and the implemented architecture retain separate warrants.

### Declared field

**Concept dependencies:** C13 Prakāśa–Vimarśa, C14 Māyā / Operative Measure, C15 Paśu, C16 Antaḥkaraṇa, C17 Vikalpa–Saṃkalpa, C18 Apoha, C19 Recognition, C41 Objective Internality.

**Consequences:** A14, A16, A19, A21, A26 and A35; S0–S5 receive the finite-world genealogy at the Objective Internality culmination.

**Etymology whole field:** *Apportionment / Economy*. **Consumed operation:** finite capacities are understood as an **apportionment** of powers within a locally workable order, rather than evidence that the whole field has vanished. **Evidence register:** 3, Operational homology; no historical derivation of Sanskrit tattva terminology from this field is claimed. **What changes:** contraction becomes a positive distribution of operative capacities whose limit can later be recognised. **Return route:** A09 → C14–C16 → A26/C41 → S0–S5 → A21/C19 → A09.

**Matheme:** `0/1 ↔ 1/0` into signed local orientation and return; **Mytheme:** descent, contraction, veil and recognition; **Episteme:** Kashmir Śaivism, Sāṃkhya neighbours, Buddhist exclusion and modern process comparison kept source-distinct.

### Provenance and remaining depth

The source field matters where it gives this contraction specific philosophical content. Dyczkowski and the Para-Trīśikā materials articulate manifestation, limitation and the inner instrument within their own Śaiva contexts; the Buddhist exclusion field supplies a distinct account of determination through difference. The essay's later paradigm development takes their pressure into a more general account of lived mediation without making that later concept a historical attribution to either tradition.

What A09 carries forward is the operation itself: a finite world becomes inhabitable through structured limitation, and recognition can return those limiting conditions into the field of awareness and revision.

The genealogy of effective contraction **returns-to** [Apportionment / Economy whole — Power becomes finite by apportionment](../etymologies/apportionment-and-economy/WHOLE-FIELD.md#power-becomes-finite-by-apportionment) at evidence register 3. This operation follows the positive distribution of capacities through the descent and their recognition on return. Its Sanskrit doctrinal sources and the Greek/Latin lexical history retain separate warrants.

The [Indian philosophy dossier](../dossiers/indian-philosophy.md#3--effective-contraction-makes-the-comparative-judgment-exact) **compares** the source-specific inner instrument and the native criterion of wholeness, with the offered gnomon and doctrinal collation kept distinct.

The [Indian philosophy companion](../histories/traditions-and-disciplines/indian-philosophy/DEVELOPMENT.md#3--manifestation-gives-contraction-a-positive-anatomy) **historicises** the two axes of manifestation and the differentiated powers of contraction; it keeps the native six-turn unit and the offered 25→36 gnomon distinct from category-by-category doctrinal collation.
