---
title: "A14 — Computational Process Ontology"
aliases:
  - "Computational Process Ontology"
  - "QL Process Epistemology"
  - "MEF Runtime"
record_id: A14
record_type: argument
register: episteme
claim_status: Derived
source_relation: "Extracted internal derivation; Argued from process philosophy and Agentworld"
---

# A14 — Computational Process Ontology

<!-- paired-field-navigation -->
[Argument field](README.md) · [Other face: A14′ — Code as the Age's Logos](../conjugate/A14-prime-Code-as-the-Ages-Logos.md) · [Shared A/C root](../conjugate/AC.md)
<!-- /paired-field-navigation -->

## #0

An achieved thing inherits a process and changes what can happen next. A judgment, institution, image or agent does not enter an empty field: prior relations supply its capacities, exclusions and means of continuation. **Process is ontologically prior to the finished thing; computation names its exact, repeatable transformations; epistemology is that process becoming able to inspect its own determinations.** [[symbolon/episteme/sources/internal-corpus/taylor/taylor-2026-core-theorems-pithy/SOURCE|Taylor's core theorem spine]] sources this definition in XI, after the complete eight-determination traversal has made question, force, recurrence, personed context and return distinct.

“Computational” therefore specifies an operative grammar. The claim that reality is literally a digital computer, or that executable syntax exhausts a subject, would require further arguments. The three offices remain legible: ontology accounts for how something achieves stability; epistemology accounts for the situated making of a claim; computation makes repeatable transitions available for execution. Their relation lets a technical run disclose the formation of its outputs without promoting its implementation into the whole of being.

## #1

The process lineage supplies distinct movements. Whitehead's inherited many concresce into a new one: their relations become one determinate satisfaction; that achieved occasion perishes as subject and becomes available as data for further becoming. The crucial return is that the product changes the next field. [[symbolon/episteme/sources/process-systems-theory/whitehead/whitehead-1978-process-reality/SOURCE|Whitehead's source house]] sources the philosophical lineage; this computational reformulation is Argued from it. The selected 1978 edition is citation-ready, while exact concrescence, satisfaction and perishing passages remain locator-needed.

Bohm gives the movement of enfolding and unfolding. A useful analytic cut makes relatively autonomous forms available; fragmentation begins when those divisions are attributed to the whole as its final structure. [[symbolon/episteme/sources/process-systems-theory/bohm/bohm-1980-wholeness-implicate-order/SOURCE|Wholeness and the Implicate Order]] sources that distinction. [[symbolon/episteme/sources/process-systems-theory/bohm/bohm-1996-on-dialogue/SOURCE|On Dialogue]] extends its lived practice through the suspension and shared examination of tacit assumptions: a common inquiry can change what its participants mean without requiring identical opinions. Both houses remain citation-ready and locator-needed. The QL grammar and its technical continuation belong to this essay.

The resulting claim is exact: stability is an achievement which retains a history and produces consequences. To treat the achieved one as final severs it from both directions of its life.

## #2

[[A13-Two-Logics-of-Two-Dia-Syn|A13]] derives the conjugate operations. Dia makes this branch actual by distinguishing, excluding, comparing, classifying, ranking and choosing. Syn retains its sources, inverse reading, affected contexts and means of recomposition. Recursive division succeeds through the composition of its results; a selected answer acquires intelligence through the field it continues to carry and the field it changes.

The six process tests in historical carrier 14 are practical demands on a result, rather than six headings to paste onto every record:

1. Recover the field and history inherited before the distinction.
2. Identify the operation which selected this branch and the alternatives it excluded.
3. State the rule, ratio or identity which stabilised it.
4. Retain the source relation, counter-reading and affected context which can contest it.
5. Trace what the achieved form changes for the next act.
6. Return it as revisable common data, with the authority to reopen its own conditions.

A technical evaluation can answer each demand concretely. A selected claim has retrieved sources and an active task; a classifier or evaluator supplies a criterion; permissions determine which action can follow; memory records an encounter and thereby alters later retrieval or choice. An unchanged list of explanatory metadata would fail the fifth test if it could never modify subsequent action. These are implementation criteria, not a claim that a deployed system already satisfies them.

## #3

[[symbolon/episteme/concepts/C11-Quaternal-Logic|C11 QL]] defines the positions and transformations; [[symbolon/episteme/concepts/C39-Meta-Epistemic-Framework|C39 MEF]] defines their lens- and evidence-explicit epistemic movement. A lens must disclose which evidence it admits, what transformation it performs, what it excludes and how another lens can differ without becoming meaningless. Name and Power remain co-present: the relation a lens can state and the force, value or commitment through which it acts belong to the same inquiry.

[[symbolon/episteme/concepts/C40-Model-Internality-Judgment-Field|C40]] defines the technical judgment field. A governed reference map can serve as a local original for readings nested within one inquiry, but it is itself a pratibimba relative to a wider source field. Ontological Bimba is not that technical map. The distinction preserves `world ≠ world-model` while letting a map carry real local authority. Returned evidence can revise the situated judgment, its criterion, or the reference map itself.

The harness instruments memory, tools, permissions, evaluation and action. Its receipt covers the transactions it can record; the material and institutional conditions which make those transactions possible exceed that record. [[A26-Objective-Internality-Mind-as-Worldhood|A26]] grounds this wider context-world. [[symbolon/episteme/concepts/C43-Computational-Vimarsa|C43]] extends reflection into the capacity to change the operative field after reading it, and [[symbolon/episteme/concepts/C61-Symbolon-Disclosure-Architecture|C61]] defines the architecture through which these relations become available to another participant.

## #4

Q27 restores the consequential shared world as the first design object. An action alters conditions another agent inherits. Context changes permission, memory, attention or action; it does not survive merely as text beside an otherwise unaffected pipeline. Agents arise as local contractions of broader capacities for a role, relation or duration. Memory belongs also to relations, places, sources, commitments and unresolved conflicts. Humans, models, institutions and affected worlds retain different powers and answerabilities.

A hierarchy can allocate authority and scope while lateral relations supply correction and mutual constraint. Neither a solitary master evaluator nor an undifferentiated network can perform every office. The proposed ecology distinguishes philosophical horizon, explicit ontology, language model, predictive model, evaluator, planner, harness and commons by what each does. These are architecture roles, not interchangeable names for one intelligent entity and not a compulsory serial pipeline.

Taylor's [[symbolon/episteme/sources/internal-corpus/taylor/taylor-2026-symbolon-dynamics/SOURCE|Symbolon Dynamics]] embodies the recursive change in a symbolic encounter. An image alters its interpreter; the changed interpreter alters what later images can disclose; the response changes the original symbol's subsequent efficacy. The product re-enters its own conditions. This carries the missing middle between generating an output and beginning a new call: the intervening world has changed, including the capacity to receive what comes next.

[[symbolon/episteme/etymologies/apportionment-and-economy/WHOLE-FIELD|Apportionment / Economy]] grounds the resource consequence at operational-homology register 3. Finite power, time, attention, labour and energy are distributed before a process acts. [[A29-Power-Delegated-Labour-Return|A29]] extends that distribution into the obligation to return evidence, consequence and value. The developmental token-economy question supplies one specific Open test: how a metered language run's demand for completion affects whether it preserves an unresolved remainder or forces a false closure. Executed succession does not, by itself, prove an identity between mathematical counting and physical time.

## #5→0

The process grammar returns to [the Process dossier](../dossiers/process.md) through an achieved determination becoming available to another act. Whitehead’s corrected 1978 carrier distinguishes an occasion’s becoming, its determinate satisfaction and its function in another occasion; completion therefore contributes a new condition without requiring perpetual indecision. A14 retains cut, exclusion and return as its own derivation. The [Process-science companion](../histories/traditions-and-disciplines/process-systems-science/DEVELOPMENT.md) keeps Whitehead's novel singularity distinct from the integral number one and Bergson's lived duration distinct from a sequence of recorded states. A technical record can alter the next process; whether the state is lived is not what gives that returned condition its processual efficacy.

The process argument **returns-to** [the developed Bohm dossier](../dossiers/bohm.md) through the difference between useful analysis and fragmentation. The Peat interview’s dye and hologram illustrations preserve organised implication when a visible form disappears; the separate postmodern-science essay proposes discrete objects as derivative stabilities of enfolding and unfolding. The native process grammar retains the cut, its inherited field and its next consequence. The undated dialogue handout adds suspension of the assumptions governing that cut. These consulted carriers supply bounded passage access while the 1980 and 1996 books keep their own uncollated passage debts; none supplies Taylor’s notation or a universal reversibility theorem.

[Agentworld](../sources/media-technology-philosophy/bratton/bratton-2026-agentworld-brief/SOURCE.md) tests the whole movement through its questions about human learning of machine process, machine adaptation to human legibility, shared procedural grammar across divergent world-models, and capability accumulated across harness, ensemble and commons. The essay extends these pressures into a circulation protocol through which participants can expose cuts, criteria, consequences and returns. What matters is whether the process becomes more answerable to the world it helps change.

[[symbolon/episteme/concepts/C57-Agentworld|C57]] defines this problem-field, while [[A33-Epistemic-Cultivation-Operational-Parity|A33]] tests whether the common grammar can be operated across distinct participants and [[symbolon/episteme/concepts/C45-Operational-Parity|C45]] qualifies what parity establishes. Functional repeatability supplies no inference either for or against an unobjectifiable artificial subject. It supplies an inspectable process whose architecture and consequences matter in their own right.

The achieved `1` returns into the next `0` as changed availability: a retained source, revised permission, acknowledged conflict, altered criterion, or commitment another participant can inherit. The result's ability to perish into common data is the final process test.

This is what lets the process argument travel into later technical and institutional fields. A completed act matters because it becomes part of what another act can begin from. The ontology of process is therefore not perpetual flux but consequential inheritance: becoming reaches a form, the form becomes objective for what follows, and the relation can begin again from a changed ground.